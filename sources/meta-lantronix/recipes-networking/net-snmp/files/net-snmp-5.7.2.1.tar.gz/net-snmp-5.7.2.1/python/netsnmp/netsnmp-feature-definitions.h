#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-features.h>

netsnmp_feature_require(snprint_value)
netsnmp_feature_require(enable_stderrlog)

