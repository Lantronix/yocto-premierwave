extern pgpcert_t* pluto_add_pgpcert(pgpcert_t *cert);

