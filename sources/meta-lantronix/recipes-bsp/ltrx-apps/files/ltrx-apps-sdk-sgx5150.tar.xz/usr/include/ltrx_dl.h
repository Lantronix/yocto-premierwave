
/*
** Support for dynamic loading of Lantronix shared libraries
**
*/

#pragma once


#include <dlfcn.h>

/*
** General macros. These can be used directly, but are really 
** intended to be used by more specific wrapper macros for
** specific libraries and functions (see IPC wrappers below).
*/
#define LTRX_DL_LIB_INIT(_h, _l)        \
    do {                                \
        if (_h == NULL)                 \
        {                               \
            _h = dlopen(_l, RTLD_LAZY); \
        }                               \
    } while (0)

#define LTRX_DL_LIB_TERM(_h)            dlclose(_h)

#define LTRX_DL_FCN_INIT(_h, _f, _n)    \
    do {                                \
        if (_h != NULL && _f == NULL)   \
        {                               \
            _f = dlsym(_h, _n);         \
        }                               \
    } while (0)

/*
** IPC (mpnipc, zipc, etc) wrappers
**
*/
#define LTRX_DL_IPC_INIT(_h)            LTRX_DL_LIB_INIT(_h, "libltrxipc.so")
#define LTRX_DL_IPC_TERM(_h)            LTRX_DL_LIB_TERM(_h)

#define LTRX_DL_IPC_INIT_FCN(_h, _f, _n)        \
    do {                                        \
        LTRX_DL_IPC_INIT(_h);                   \
        LTRX_DL_FCN_INIT(_h, _f, _n);           \
    } while (0)

#define LTRX_DL_IPC_FCN_CALL(_h, _n, ...)       \
    do {                                        \
        dlft_ ## _n ## _t _fp = NULL;           \
        LTRX_DL_IPC_INIT_FCN(_h, _fp, #_n);     \
        if (_fp)                                \
        {                                       \
            (_fp)(__VA_ARGS__);                 \
        }                                       \
    } while (0)
