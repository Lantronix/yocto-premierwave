#ifndef __LTRX_CELLULAR_H__
#define __LTRX_CELLULAR_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* FIXME */
#if defined(PWAVE_XC)
#define IWOW
#elif defined(PWAVE_XC_HSPA)
#define CINTERION
#endif

#define CELLREG_UNKNOWN                     0
#define CELLREG_TECHNICAL_PROBLEM           1
#define CELLREG_ON_HOME_NETWORK             2
#define CELLREG_SEARCHING                   3
#define CELLREG_DENIED                      4
#define CELLREG_ON_FOREIGN_NETWORK          5
#define CELLREG_UNREGISTERED                6

#define CELLSIM_UNKNOWN                     0
#define CELLSIM_CONNECTION_ERROR            1
#define CELLSIM_INSERTED                    2
#define CELLSIM_DEACTIVATED                 3
#define CELLSIM_TECHNICAL_PROBLEM           4

#define CELL_TECH_2G                        1
#define CELL_TECH_3G                        2

#define SMS_ENCODE_7BIT                     0
#define SMS_ENCODE_8BIT                     4
#define SMS_ENCODE_UCS2                     8

#define CELL_PHONE_NUMBER_MAX               24

#define CELL_DEFAULT_PORT       			"ttyACM0"
#define CELL_DEFAULT_MRU       				2000
#define CELL_DEFAULT_MTU       				2000

#if defined(CINTERION)

#define CELL_TEMP_CRITICAL_HI               85 /* up to 85 normal, 95 restricted */
#define CELL_TEMP_CRITICAL_LOW             -30 /* up to -30 normal, -40 restricted */

#define CELL_PACKET_RATE_UP_7_2_MBPS        1
#define CELL_PACKET_RATE_UP_14_4_MBPS       0

#define CELL_PACKET_RATE_DN_2_0_MBPS        1
#define CELL_PACKET_RATE_DN_5_76_MBPS       0

#endif

const char *cell_strerror(int);

struct cell_status_network /* radio network, not ip network */
{
    bool cns_network_registered;
    uint32_t cns_network_regstatus;
    uint32_t cns_packet_regstatus;
    char cns_operator[64];
};

struct cell_status_id
{
    char cid_imsi[24];
    char cid_imei[24];
    char cid_scid[24];
};

struct cell_status_sim
{
    uint32_t csim_state;
};

struct cell_status_module
{
    int32_t cs_supply_voltage;     /* in millivolts */
    int32_t cs_temperature;        /* in celsius */
};

struct cell_status_site
{
    char css_access_tech[16];
    union
    {
        int32_t css_bcch_level;    /* for 3G: in dBm */
        int32_t css_sn_ratio;      /* for 2G: in dB */
    } css_level;
    /* TODO: more stuff */
};

struct cell_status_signal
{
    uint32_t csig_rssi;
};

struct cell_status_packetnet
{
    uint32_t csp_up_speed;
    uint32_t csp_down_speed;
};

#ifdef IWOW
int cell_reset_mux(void);//switch to AT command mode
#endif
int cell_mgmt_version_get(char*, size_t);
int cell_get_network_status(struct cell_status_network *net_stat);
int cell_get_id(struct cell_status_id *id);
int cell_get_module_status(struct cell_status_module *mod_stat);
int cell_get_sim_status(struct cell_status_sim *sim_stat);
int cell_get_serving_site_status(struct cell_status_site *site_stat);
int cell_get_signal_status(struct cell_status_signal *sig_stat);
int cell_get_packetnet_status(struct cell_status_packetnet *pnet_stat);

const char *cell_registration_desc(uint32_t regstat);
const char *cell_simstate_desc(uint32_t simstate);

bool cell_get_complete_da(const char* number,char* completed,size_t size);
bool cell_is_valid_da(const char *da);

#define SMS_PACKETSW_ONLY           0
#define SMS_CIRCUITSW_ONLY          1
#define SMS_PACKETSW_PREFERRED      2
#define SMS_CIRCUITSW_PREFERRED     3

#ifdef PWAVE_XC_HSPA
int cell_get_antenna_diversity(bool* diversity);
int cell_set_antenna_diversity(bool  diversity);
#endif

int cell_get_sms_transport(uint32_t *transport);
int cell_set_sms_transport(uint32_t transport);

#define CELL_RBAND_GSM900           1
#define CELL_RBAND_GSM1800          2
#define CELL_RBAND_GSM850           4
#define CELL_RBAND_GSM1900          8
#ifdef CINTERION
#define CELL_RBAND_WCDMA2100        16
#define CELL_RBAND_WCDMA1900        32
#define CELL_RBAND_WCDMA850         64
#define CELL_RBAND_WCDMA900         128
#define CELL_RBAND_WCDMA800         256
#define CELL_RBAND_ALL              0x1FF

#else
    #define CELL_RBAND_ALL              0xF
#endif
int cell_get_radio_bands(uint32_t *bands);
int cell_set_radio_bands(uint32_t bands);

#define CELL_OPER_AUTOMATIC         1
#define CELL_OPER_MANUAL            2

struct cell_operator
{
    char cc_longname[28];
    uint32_t cc_id;
};

int cell_get_operator_list(
    struct cell_operator *operator_array,
    size_t *noperators
);

int cell_get_operator(uint32_t *mode, struct cell_operator *op);
int cell_set_operator(uint32_t mode, uint32_t oper_id);

int cell_gettime(uint32_t *epoch_seconds, int32_t *utc_offset_seconds,int32_t *dst_seconds);

/*
 * Security API
 *
 * Currently we support SIM card locking only. SIM card locking/unlocking
 * may be better thought of as enabling/disabling network authentication
 * (the carrier network, not IP network).
 * So, once the SIM card lock is set, authentication must be provided on
 * subsequent restarts.
 */
#define CLCKID_SIMCARD                      1

#define CELLAUTH_UNKNOWN                    0
#define CELLAUTH_READY                      1
#define CELLAUTH_PIN_REQ                    2
#define CELLAUTH_PUK_REQ                    3

struct cell_status_auth
{
    uint32_t cauth_state;
};

int cell_get_lock_state(uint32_t lockid, bool *locked);
int cell_set_lock_state(uint32_t lockid, bool lock, const char *pin);
#ifdef USE_CELLULAR_ADVANCEDMODE
int cell_set_autoanswer(bool enabled);
#endif
int cell_get_auth_status(struct cell_status_auth *auth_stat);
int cell_authenticate(const char *pin1, const char *pin2);


/*
 * Short message API
 */
#define CELL_STATS_SMS_MAX          16

struct cell_short_message
{
    union
    {
        uint32_t inbound_index;
        struct
        {
            uint16_t rcode;
            uint16_t tries;
        } outbound;
    } sm_direction;
#define sm_index sm_direction.inbound_index
#define sm_tries sm_direction.outbound.tries
#define sm_rcode sm_direction.outbound.rcode
    char sm_addr[24];
    char sm_timestamp[18];
    uint32_t sm_ref;
    uint32_t sm_part;
    uint32_t sm_total;
    uint32_t sm_datalen;
    char sm_data[160+1];
    uint32_t sm_encoding;
};

int sms_send(
    const char *destination_address,
    size_t da_len,
    const char *service_center_address,
    const char *message,
    size_t msg_len,
    uint32_t encoding,
    bool block
);

int sms_list_inbound(
    struct cell_short_message *sm,
    size_t *nsm,
    uint32_t *start
);

int sms_list_outbound(
    struct cell_short_message *sm,
    size_t *nsm,
    uint32_t *start
);

/* Reads a short message from a specified index */
int sms_read(uint32_t index, struct cell_short_message *sm);

/* Receives the next incoming short message for the specified whitelist */
int sms_recv(uint32_t whitelist, struct cell_short_message *sm);

/* Short message service center address */
int sms_sca_get(char *buf, size_t len);
int sms_sca_set(const char *sca);


/*
 * Whitelist API
 */
#define CELL_WL_SHOULDERTAP     1
#define CELL_WL_RELAYCTRL       2
#define CELL_WL_SMSTUNNEL       3

#define CELL_WL_NONE            0
#define CELL_WL_MIN             1
#define CELL_WL_MAX             3

#define CELL_WL_NUMBER_LEN      CELL_PHONE_NUMBER_MAX

int whitelist_add(uint32_t wlist, const char *number);
int whitelist_rem(uint32_t wlist, const char *number);
int whitelist_id(const char *number, uint32_t *wlists, size_t nlists);
int whitelist_get_count(uint32_t wlists, size_t *count);
int whitelist_get(
    uint32_t wlist,
    char** numbers,
    size_t nnumbers
);


#endif /* __LTRX_CELLULAR_H__ */
