#ifndef __LTRX_MACH10_H__
#define __LTRX_MACH10_H__

/* vim :set tabstop=4:set expandtab */
/* Copyright 2016 Lantronix, Inc. All Rights Reserved */
#ifdef USE_FIPS 
#include <openssl/evp.h>
#include <openssl/ssl.h>
#endif
#include "stdio.h"
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <libjson/libjson.h>
#include <curl/curl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <errno.h>
#include <ctype.h>
#include <netinet/in.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <libgen.h>
#include <signal.h>
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#if defined(USE_WS_MQTT)
#include <mqtt-ws-client.h>
#endif

#ifndef STANDALONE_DEVICE_SIMULATOR
#include "cfgvar.h"
#include "varid.h"
#include "evolution.h"
#include "evolution_stdio.h"
#include "ltrx.h"
#include "ltrx_log.h"
#endif

#include <termios.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <poll.h>

#ifdef STANDALONE_DEVICE_SIMULATOR

#include <stdbool.h>

#define LOG_PASS  5
#define LOG_INFO    4
#define LOG_WARN    3
#define LOG_NOTICE  2
#define LOG_ERR     1
#define LOG_DEBUG   0
extern void LOG(const int severity, const char* fmt,...);
extern void LOGV1(const char* fmt,...);

static char *sprintf_malloc(const char *fmt, ...)
{
    char *allocatedString = NULL;
    int count;
    va_list args;
    va_start(args, fmt);
    count = vsnprintf(NULL, 0, fmt, args);
    va_end(args);
    if(count >= 0)
    {
        size_t allocLength = count + 1;
        allocatedString = malloc(allocLength);
        if(allocatedString)
        {
            va_start(args, fmt);
            vsnprintf(allocatedString, allocLength, fmt, args);
            va_end(args);
        }
    }
    return allocatedString;
}

#if defined(MYSTIQUE_SUPPORT_DEVICECERT) && defined(USE_SSL)
struct vardef_values_percepxion_connection__ssl {
    uint32_t zeroBasedIndex;
    bool hasBeenLoadedByXmlUpload;
    bool hasBeenChangedButNotYetApplied;
    char secure_credentials[30 + 1];
};
#endif
struct vardef_values_percepxion_connection {
    uint32_t zeroBasedIndex;
    bool hasBeenLoadedByXmlUpload;
    bool hasBeenChangedButNotYetApplied;
#if defined(MYSTIQUE_SUPPORT_PROXY)
    bool use_proxy;
#define VARDEF_ENUM_PERCEPXION_CONNECTION_PROXY_TYPE_SOCKS5 0
#define VARDEF_ENUM_PERCEPXION_CONNECTION_PROXY_TYPE_HTTP 1
    uint8_t proxy_type;
    char proxy_host[255 + 1];
    uint16_t proxy_port;
    char proxy_username[255 + 1];
    char proxy_password[255 + 1];
#endif
    char host[255 + 1];
    uint8_t connect_to;
    uint16_t port;
    bool secure_port;
    bool validate_certificates;
#if defined(MYSTIQUE_SUPPORT_DEVICECERT) && defined(USE_SSL)
    struct vardef_values_percepxion_connection__ssl _ssl;
#endif
    uint16_t local_port;
    bool mqtt_state;
    bool mqtt_security;
    uint16_t mqtt_local_port;
};

struct vardef_values_percepxion {
    uint32_t zeroBasedIndex;
    bool hasBeenLoadedByXmlUpload;
    bool hasBeenChangedButNotYetApplied;
    bool state;
    char device_id[255 + 1];
    char device_key[255 + 1];
    char device_name[255 + 1];
    char device_description[255 + 1];
    char project_tag[255 + 1];
    uint16_t status_update_interval;
    uint16_t content_check_interval;
    bool apply_firmware_updates;
    uint8_t apply_configuration_updates;
    bool reboot_after_update;
    uint8_t active_connection;
    struct vardef_values_percepxion_connection connection[ 2 ];

};

#endif

#ifdef USE_WS_MQTT

#define SESSION_TYPE_STATUS     0
#define SESSION_TYPE_TELEMETRY  1

struct user_data
{
    char* auth_token;
    char* entry_id;
    char* tenant_id;
    char* project_id;
    char* mqtt_topic;
    char* mqtt_subscribe;
    char* username;
    bool  mqtt_security;
    int   mqtt_qos;
    int   session_type;
    ws_mqtt_context_t* mqtt_ctx;
};

struct mqttSession
{
    struct mqttSession* next;
    struct user_data*   client_data;
};

#endif

#define MAX_TENANT_ID_LENGTH 64
struct tenant_ids
{
    char tenant_id[MAX_TENANT_ID_LENGTH];
    struct tenant_ids* next;
};

int register_device(const char* postData,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
    char** auth_token,
    char** entry_id,
    char** response);

typedef enum publish_channel {
    PUBLISHED_NONE=-1,
#ifdef USE_WS_MQTT
    PUBLISHED_MQTT=0,
#endif
    PUBLISHED_REST=1
} published_via;

int publish_status(const char* auth_token,
    const char* postData,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
#ifdef USE_WS_MQTT
    const bool mqtt,
    const struct mqttSession* sessions,
#endif
    char** response);
int check_for_updates(const char* auth_token,
    const char* postData,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
    char** response);
int download_content(const char* auth_token,
    const char* url,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
    void* userData,
    size_t (*callback)(char* ptr, size_t size, size_t nmemb, void* userData),
    char** response);
int capability_exchange(const char* postData,
    const char*  telemetry_host,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
    const char* auth_token,
    char** response);
int capability_selection(const char* postData,
    const char*  telemetry_host,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
    const char* auth_token,
    char** response);
int publish_telemetry(const char* auth_token,
    const char* postData,
    const char*  telemetry_host,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
#ifdef USE_WS_MQTT
    const bool mqtt,
    const struct mqttSession* sessions,
#endif
    char** response);

/*helper function to parse register and status REST API response*/
int parse_auth_token(const char* response, char** auth_token, char** project_id, struct tenant_ids* tenants,char** entry_id, char** telemetry_mqtt_host);
void FreeTenants(struct tenant_ids* tenants);

#ifdef USE_WS_MQTT

void MQTTInit(struct mqttSession** mqttSessions);

void MQTTConnect(const char* register_response,
    const struct vardef_values_percepxion* current,
    const char* caCertPath,
    const char* auth_token,
    const int qos,
    char* (*lwtt_callback)(const char* entry_id, char** lwtt),
    void (*log_callback)(void *mqtt_ctx, int level, const char *str),
    int (*msg_callback)(void* mqtt_ctx, char* topic,unsigned char* msg),
    /*void (*connect_callback)(void*, int),
    void (*disconnect_callback)(void*),*/
    struct mqttSession* mqttSessions);

void MQTTDisconnect(struct mqttSession* sessions,
    char* (*lwtt_callback)(const char* entry_id, char** lwttMessage)
    );

bool HasDeviceAssignmentChanged(const char* response,
    struct mqttSession* sessions);

#endif

#endif
