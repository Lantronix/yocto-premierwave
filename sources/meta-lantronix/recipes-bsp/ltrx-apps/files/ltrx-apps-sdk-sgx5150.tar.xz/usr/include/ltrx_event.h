
#ifndef _LXEVENT_H_
#define _LXEVENT_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include <netinet/in.h>

#ifdef USE_CELLULAR
#include "ltrx_cellular.h"
#endif

#ifndef _ztypes_defined
typedef void *zcontext_t;
typedef void *zsocket_t;
#define _ztypes_defined
#endif


/*
** Message domains. These are pretty much defined by separate processes
** which generate messages.
*/
#define LTRX_EV_DOM_DEVICE              1
#define LTRX_EV_DOM_NETWORK             2
#define LTRX_EV_DOM_CELLULAR            3
#define LTRX_EV_DOM_WLAN                4
#define LTRX_EV_DOM_SYSTEM              5
#define LTRX_EV_DOM_BLUETOOTH           6

#define LTRX_EV_DOM_MAX                 7

/*
** Message IDs
*/
#define LTRX_EV_MSG_DEV_POWER           100

#define LTRX_EV_MSG_DEV_TEMP            200

#define LTRX_EV_MSG_DEV_USB_HOST        300

#define LTRX_EV_MSG_DEV_DIG_INPUT       400

#define LTRX_EV_MSG_DEV_CELL            500

#define LTRX_EV_MSG_DEV_BUTTON_WPS      601
#define LTRX_EV_MSG_DEV_BUTTON_DEFAULTS 602

#define LTRX_EV_MSG_DEV_AP_TRIGGER      700


#define LTRX_EV_MSG_NET_LINKSTATE       1001
#define LTRX_EV_MSG_NET_ADDRESS         1002
#define LTRX_EV_MSG_NET_DUPLEX          1003
#define LTRX_EV_MSG_NET_IFLIST          1004

#define LTRX_EV_MSG_CELL_STATE          2001
#define LTRX_EV_MSG_CELL_SIGNAL         2002
#define LTRX_EV_MSG_CELL_SMS_DELIVER    2003
#define LTRX_EV_MSG_CELL_RESTART        2004
#define LTRX_EV_MSG_CELL_TEMPERATURE    2005
#define LTRX_EV_MSG_CELL_NITZ           2006

#define LTRX_EV_MSG_WLAN_SIGNAL         3001
#define LTRX_EV_MSG_WLAN_WPS_STATUS     3002

#define LTRX_EV_MSG_SYSTEM_REBOOT       4001
#define LTRX_EV_MSG_SYSTEM_DEFAULTS     4002
#define LTRX_EV_MSG_SYSTEM_LOCATE       4003
#define LTRX_EV_MSG_SYSTEM_CLOCKUPDATE  4004

#define LTRX_EV_MSG_BLUETOOTH_PAIRING      5001
#define LTRX_EV_MSG_BLUETOOTH_DISCONNECT   5002

/*
** Actions, values, other event message parameters
*/
#define TEMP_OVER                       1
#define TEMP_UNDER                      2
#define TEMP_NORMAL                     3

#define NETADDR_REM                     0
#define NETADDR_ADD                     1


/*
** Device / peripheral event messages
*/
struct ltrx_evmsg_dev_power
{
    uint32_t emp_source;
    bool emp_undervolt;
};

struct ltrx_evmsg_dev_temp
{
    uint32_t emt_action;
    uint32_t emt_value;
};

struct ltrx_evmsg_dev_usb_host
{
    uint32_t emuh_portnum;
    bool emuh_dev_inserted;
};

struct ltrx_evmsg_dev_dig_input
{
    uint32_t emdi_index;
    uint32_t emdi_value;
};

struct ltrx_evmsg_dev_cell
{
    bool emdc_ring;
    bool emdc_wakeup;
};

struct ltrx_evmsg_dev_wps
{
    bool emdw_value;
};

struct ltrx_evmsg_dev_ap_trigger
{
    bool emdat_onoff;
};

union ltrx_evmsg_dev
{
    struct ltrx_evmsg_dev_power emd_power;
    struct ltrx_evmsg_dev_temp emd_temp;
    struct ltrx_evmsg_dev_usb_host emd_usbhost;
    struct ltrx_evmsg_dev_dig_input emd_diginput;
    struct ltrx_evmsg_dev_cell emd_cell;
    struct ltrx_evmsg_dev_wps emd_wps;
    struct ltrx_evmsg_dev_ap_trigger emd_ap_trigger;
};

/*
** Network event messages
*/
struct ltrx_evmsg_net_linkstate
{
    char emls_ifname[32];
    bool emls_state;
};

struct ltrx_evmsg_net_address
{
    char emna_ifname[32];
    uint32_t emna_action;
    uint16_t emna_family;
    union
    {
        struct in_addr v4;
        struct in6_addr v6;
    } emna_addr;
    uint8_t emna_mask;
};

struct ltrx_evmsg_net_duplex
{
    char emnd_ifname[32];
    uint32_t emnd_duplex;
};

struct ltrx_evmsg_if
{
    char emif_name[32];
    bool emif_state;
    uint32_t emif_address_count;
};

struct ltrx_evmsg_net_iflist
{
    uint32_t emni_count;
    struct ltrx_evmsg_if emni_list[1];
};

union ltrx_evmsg_net
{
    struct ltrx_evmsg_net_linkstate emn_linkstate;
    struct ltrx_evmsg_net_address emn_addr;
    struct ltrx_evmsg_net_duplex emn_duplex;
    struct ltrx_evmsg_net_iflist emn_iflist;
};

#ifdef USE_CELLULAR
/*
** Cellular event messages
*/
enum cell_regstat
{
    CELL_REGSTAT_NONE,
    CELL_REGSTAT_HOME,
    CELL_REGSTAT_ROAM
};

struct ltrx_evmsg_cell_state
{
    enum cell_regstat emcs_regstat;
    bool emcs_radionet_regstat;
    bool emcs_packetnet_regstat;
    bool emcs_sim_present;
};

struct ltrx_evmsg_cell_signal
{
    uint32_t emcsig_rssi;
};

struct ltrx_evmsg_cell_sms_deliver
{
    uint32_t emsd_whitelists[CELL_WL_MAX];
    struct cell_short_message emsd_message;
};

struct ltrx_evmsg_cell_temperature
{
    uint32_t emct_action;
    uint32_t emct_value;
};

union ltrx_evmsg_cell
{
    struct ltrx_evmsg_cell_state lemc_state;
    struct ltrx_evmsg_cell_sms_deliver lemc_smsd;
    struct ltrx_evmsg_cell_signal lemc_signal;
    struct ltrx_evmsg_cell_temperature lemc_temperature;
};

#endif /* USE_CELLULAR */

#if (MAX_NETS_WLAN > 0)
/*
** WLAN event messages
*/
struct ltrx_evmsg_wlan_signal
{
    uint32_t emwsig_rssi;
    int      emwsig_rssi_dbm;
};

enum wps_status
{
    WPS_NONE,
    WPS_ENABLED,
    WPS_SUCCESS,
    WPS_PROFILE_ERROR,
    WPS_TIMEOUT
};

struct ltrx_evmsg_wlan_wps_status
{
    enum wps_status emwwps_status;
};

#endif /* MAX_NETS_WLAN > 0 */

/*
** System event messages
*/
enum system_reboot_reason
{
    SYSTEM_REBOOT_USER_REQUEST,
    SYSTEM_REBOOT_SCHEDULED
};

struct ltrx_evmsg_system_reboot
{
    uint32_t emsys_delay;
    enum system_reboot_reason emsys_reason;
};

struct ltrx_evmsg_system_locate
{
    bool ems_state;
};

struct ltrx_evmsg_bluetooth_disconnect
{
    bool connect_status; 
    char macAddr[18];
};

struct ltrx_evmsg_system_user
{
    char username[32];
    char ip_addr[48];
};

union ltrx_evmsg_system
{
    struct ltrx_evmsg_system_reboot ems_reboot;
    struct ltrx_evmsg_system_locate ems_locate;
    struct ltrx_evmsg_system_user ems_user;
};


/*
** Event publish/subscribe API
** Functions with return value return 0 on success, errno value on failure.
*/
typedef int (*ltrx_subscriber_cb_t)(
    void *user_arg,
    uint32_t domain,
    uint32_t msgid,
    uint32_t seqno,
    uint8_t *msg,
    size_t msglen
);


int ltrx_ev_publisher_create(
    zcontext_t ipc,
    uint32_t domain,
    zsocket_t *publisher
);

int ltrx_ev_publisher_add(
    zsocket_t publisher,
    uint32_t domain
);

int ltrx_ev_publisher_destroy(zsocket_t *publisher);

int ltrx_evmsg_publish(
    zsocket_t publisher,
    uint32_t domain,
    uint32_t msgid,
    void *msgdata,
    size_t datalen
);

int ltrx_ev_subscriber_create(
    zcontext_t ipc,
    zsocket_t *subscriber
);

int ltrx_ev_subscribe(
    zsocket_t subscriber,
    uint32_t domain
);

/*
 * This function can be passed a pointer to a pre-allocated buffer
 * (in which case the caller may need an intermediate variable), or
 * can be passed a pointer to a null pointer, in which case the
 * function will allocate necessary memory from the heap.
 */
int ltrx_evmsg_read(
    zsocket_t subscriber,
    uint32_t *domain,
    uint32_t *msgid,
    uint32_t *seqno,
    void **msgdata,
    size_t *datalen
);


/*
 * A threaded API; the caller only needs to implement a callback to
 * handle specific messages.
 */

typedef void *ltrx_event_thread_t;

int ltrx_ev_subscriber_thread_launch(
    zcontext_t ipc,
    uint32_t *domainlist,
    size_t ndomains,
    ltrx_subscriber_cb_t callback,
    void *cbarg,
    ltrx_event_thread_t *handle
);

int ltrx_ev_subscriber_thread_term(ltrx_event_thread_t handle);


/*
 * Dynamic loading function type definitions
 */
typedef int (*dlft_ltrx_ev_publisher_create_t)(
    zcontext_t ipc,
    uint32_t domain,
    zsocket_t *publisher
);

typedef int (*dlft_ltrx_ev_publisher_add_t)(
    zsocket_t publisher,
    uint32_t domain
);

typedef int (*dlft_ltrx_ev_publisher_destroy_t)(zsocket_t *publisher);

typedef int (*dlft_ltrx_evmsg_publish_t)(
    zsocket_t publisher,
    uint32_t domain,
    uint32_t msgid,
    void *msgdata,
    size_t datalen
);

typedef int (*dlft_ltrx_ev_subscriber_create_t)(
    zcontext_t ipc,
    zsocket_t *subscriber
);

typedef int (*dlft_ltrx_ev_subscriber_thread_launch_t)(
    zcontext_t ipc,
    uint32_t *domainlist,
    size_t ndomains,
    ltrx_subscriber_cb_t callback,
    void *cbarg,
    ltrx_event_thread_t *handle
);

typedef int (*dlft_ltrx_ev_subscriber_thread_term_t)(ltrx_event_thread_t handle);

#endif /* _LXEVENT_H_ */
