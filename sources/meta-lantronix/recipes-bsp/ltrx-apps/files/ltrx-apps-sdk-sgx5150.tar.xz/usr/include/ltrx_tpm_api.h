/*
 * Copyright (C) 2016 Lantronix, Inc. All Rights Reserved.
 *
 * ltrx_tpm_api.h
 * ltrx tpm API
 */

/**
* @file ltrx_tpm_api.h
*/

#ifndef __LTRX_TPM_H
#define __LTRX_TPM_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stdbool.h"
#include "stdlib.h"
#include "stdio.h"

/**
* @brief Error codes
*
* List of possible error codes.
*/
typedef enum ltrx_status
{
    LTRX_SUCCESS                = 0x00, /**< The function was successful. */
    LTRX_GEN_FAIL               = 0xE1, /**< The function failed. */
    LTRX_INVALID_ID             = 0xE2, /**< The specified id is invalid */
    LTRX_ID_IN_USE              = 0xE3, /**< The specified id is in use */
    LTRX_ID_IS_LOCKED           = 0xE4, /**< The specified id is locked */
    LTRX_NO_MEMORY              = 0xE5, /**< A memory allocation failure occured */
    LTRX_INVALID_PARAMETER      = 0xE6, /**< One or more parameters are not valid */
    LTRX_NOT_SUPPORTED          = 0xE7, /**< Not supported */
    LTRX_VERIFY_FAILED          = 0xE8, /**< Signature verification failed */
    LTRX_EXECUTION_ERROR        = 0xF4, /**< execution error. */
}LTRX_STATUS;

/**
* @brief Private key indices.
*
* private key indices.
*/
typedef enum private_key_storage_index
{
    LTRX_PRIVATE_KEY_1=0,/**< Private Key storage index 1. */
    LTRX_PRIVATE_KEY_2,  /**< Private Key storage index 2. */
    LTRX_PRIVATE_KEY_3,  /**< Private Key storage index 3. */
    LTRX_PRIVATE_KEY_4,  /**< Private Key storage index 4. */
}PRIVATE_KEY_STORAGE_INDEX;

/**
* @brief Public key indices.
*
* public key indices.
*/
typedef enum public_key_storage_index
{
    LTRX_PUBLIC_KEY_1=0,/**< Private Key storage index 1. */
    LTRX_PUBLIC_KEY_2,  /**< Private Key storage index 2. */
}PUBLIC_KEY_STORAGE_INDEX;

/**
* @brief Public private key pair.
*
* public private key pair indices.
*/
typedef enum key_pair_storage_index
{
    LTRX_PUBLIC_PRIVATE_KEY_1=0,/**< Public-Private Key storage index 1. */
    LTRX_PUBLIC_PRIVATE_KEY_2,  /**< Public-Private Key storage index 2. */
}KEY_PAIR_STORAGE_INDEX;
#if 0
/**
* @brief Certificate indices.
*
* certificate indices.
*/
typedef enum certificate_storage_index
{
    LTRX_CERTIFICATE_1=0,/**< Certificate storage index 1. */
    LTRX_CERTIFICATE_2,  /**< Certificate storage index 2. */
}CERTIFICATE_STORAGE_INDEX;

/**
* @brief Certificate private key pair.
*
* certificate private key pair indices.
*/
typedef enum credential_storage_index
{
    LTRX_CREDENTIAL_1=0,/**< Certificate-Private Key storage index 1. */
    LTRX_CREDENTIAL_2,  /**< Certificate-Private Key storage index 2. */
}CREDENTIAL_STORAGE_INDEX;
#endif
/**
 * @brief Operation flags
 *
 */
#define LTRX_TPM_FLAGS_NOOP       0x0 /**< No operation. */
#define LTRX_TPM_FLAGS_LOCK       0x1 /**< Lock. */
#define LTRX_TPM_FLAGS_UNLOCK     0x2 /**< Unlock. */
#define LTRX_TPM_FLAGS_OVERWRITE  0x4 /**< Overwrite previous contents. */
#if 0
/**
* Returns certificate and private key index used by credential
*
* @param[in] idx          Credential storage index.
* @param[out] certificate  Storage index of the certificate.
* @param[out] private_key  Storage index of the private key.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_credential_to_storage(CREDENTIAL_STORAGE_INDEX idx, CERTIFICATE_STORAGE_INDEX* certificate, PRIVATE_KEY_STORAGE_INDEX* private_key);
#endif
/**
* Returns public and private key index used by the key pair
*
* @param[in] idx          Index of the key pair stored.
* @param[out] public_key   Index of the public key storage.
* @param[out] private_key  Index of the private key storage.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_keypair_to_storage(KEY_PAIR_STORAGE_INDEX idx, PUBLIC_KEY_STORAGE_INDEX* public_key, PRIVATE_KEY_STORAGE_INDEX* private_key);

/**
* Free memory buffer.
*
* @param buffer        Memory which needs to be free.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_free_buffer(uint8_t* buffer);

/**
* Generates random data
*
* @param[out] random      random data.
* @param[out] length      length of random data.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_get_random(uint8_t** random, size_t* length);

/**
* Generate and store public private key pair
*
* @param[in] idx           Storage index of public/private key pair.
* @param[out] flags         Operation flags.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_generate_public_private_key_pair(KEY_PAIR_STORAGE_INDEX idx, uint32_t flags);

/**
* Generate and store private key
*
* @param[in] idx           Storage index of private key.
* @param[in] flags         Operation flags.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_generate_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint32_t flags);

/**
* Store private key
*
* @param[in] idx           Storage index of private key.
* @param[in] flags         Operation flags.
* @param[in] key           Private key.
* @param[in] keyLength     Length of private key.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_store_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint32_t flags, const uint8_t *key, size_t keyLength);

/**
* Read private key
*
* @param[in] idx           Storage index of private key.
* @param[out] key           Private key.
* @param[out] keyLength     Length of private key.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_read_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint8_t **key, size_t* keyLength);

/**
* Store public key
*
* @param[in] idx           Storage index of public key.
* @param[in] flags         Operation flags.
* @param[in] key           Public key.
* @param[in] keyLength     Length of public key.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_store_public_key(PUBLIC_KEY_STORAGE_INDEX idx, uint32_t flags, const uint8_t *key, size_t keyLength);

/**
* Read public key
*
* @param[in] idx           Storage index of public key.
* @param[out] key           Public key.
* @param[out] keyLength     Length of public key.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_read_public_key(PUBLIC_KEY_STORAGE_INDEX idx, uint8_t **key, size_t* keyLength);

/**
* Delete private key
*
* @param[in] idx           Storage index of private key.
* @param[in] flags         Operation flags.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_delete_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint32_t flags);

/**
* Delete public key
*
* @param[in] idx           Storage index of public key.
* @param[in] flags         Operation flags.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_delete_public_key(PUBLIC_KEY_STORAGE_INDEX idx, uint32_t flags);

/**
* Delete public private key pair
*
* @param[in] idx           Storage index of public/private key pair.
* @param[in] flags         Operation flags.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_delete_public_private_key_pair(KEY_PAIR_STORAGE_INDEX idx, uint32_t flags);

/**
* Sign message using private key
*
* @param[in] idx             Storage index of private key.
* @param[in] message         message to be signed.
* @param[in] messageLength   Length of the message.
* @param[out] signature       Signature.
* @param[out] signatureLength Length of the signature.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_sign_message(PRIVATE_KEY_STORAGE_INDEX idx, const uint8_t *message, size_t messageLength, uint8_t **signature, size_t* signatureLength);

/**
* Verify signature using public key
*
* @param[in] idx             Storage index of public key.
* @param[in] message         signed message.
* @param[in] messageLength   Length of the message.
* @param[in] signature       Signature.
* @param[in] signatureLength Length of the signature.
* @param[out] is_verified    signature verification result.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_verify_signature(PUBLIC_KEY_STORAGE_INDEX idx, const uint8_t *message, size_t messageLength, const uint8_t *signature, size_t signatureLength, bool *is_verified);

#if 0
/**
* Store a TLS Credential private key and certificate
*
* @param[in] idx             Credential storage index.
* @param[in] flags           Operation flags.
* @param[in] key             Key which needs to be stored.
* @param[in] key_len         Size of the key.
* @param[in] cert            Certificate which needs to be stored.
* @param[in] cert_len        Size of the certificate.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_store_credential(CREDENTIAL_STORAGE_INDEX idx, uint32_t flags, const uint8_t *key, size_t key_len, uint8_t *cert, size_t cert_len);

/**
* Read TLS Credential private key and certificate
*
* @param[in] idx             Credential storage index.
* @param[out] key             Key which is read from storage index.
* @param[out] key_len         Size of the key.
* @param[out] cert            Certificate which is read from storage index.
* @param[out] cert_len        Size of the certificate.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_read_credential(CREDENTIAL_STORAGE_INDEX idx, uint8_t **key, size_t* key_len, uint8_t **cert, size_t* cert_len);

/**
* Delete TLS Credential private key and certificate
*
* @param[in] idx             Credential storage index.
* @param[in] flags           Operation flags.
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_delete_credential(CREDENTIAL_STORAGE_INDEX idx, uint32_t flags);
#endif

#ifdef __cplusplus
}
#endif

#endif //__LTRX_TPM_H
