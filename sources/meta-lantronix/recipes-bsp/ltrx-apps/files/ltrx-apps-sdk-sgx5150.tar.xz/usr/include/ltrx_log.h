
#ifndef __LTRX_LOG_H__
#define __LTRX_LOG_H__

/*
 * Log API which supercedes TLOG. TLOG macros are mapped into this API.
 * This API is basically a wrapper around syslog with some added features:
 *
 * Verbosity
 *      In addition to severity, there is a verbosity parameter.
 *      Macros including verbosity use LOG_INFO severity level.
 *
 * Parameters stored in shared memory
 *      The severity and verbosity are stored in a shared memory block.
 *      These parameters are per-process, and once registered, access
 *      to them is very fast.
 *
 *      The purpose is to allow changing both severity and verbosity at
 *      runtime from external processes.
 *
 *      A process may still log safely via this API even if it has not
 *      called log_register(); in these cases, a default parameter set is
 *      used.
 *
 *      A CLI program, logadm, is built with the library to allow dynamic
 *      severity/verbosity setting while programs are already running (for
 *      debugging; standard apps should use the API).
 *
 * Logging to files, stderr, and stdout
 *      By default logging is targeted to syslog, but a file (or descriptor)
 *      can be added so that logging is committed to that target as well.
 *      File logging uses advisory file locking so that multiple processes
 *      can safely log to the same file.
 *
 */

#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <syslog.h>
#include <sys/types.h>

#define LOG_NAME_MAX            32

#define LOG_VERBOSITY_MIN       0
#define LOG_VERBOSITY_MAX       3

#define LOG_TARGET_SYSLOG       0x1
#define LOG_TARGET_FILE         0x2

#define LOG_CRITICAL            LOG_CRIT
#define LOG_ERROR               LOG_ERR
#define LOG_WARN                LOG_WARNING

#define IMPORT_ERROR                 "ERROR: Failed importing XML configuration"
#define IMPORT_REPORT_FAILURE        "ERROR: Failed "
#define IMPORT_REPORT_WARNING        "WARNING: From "

#define LOG(__s, __f, __a...)   \
    logmsgf(__FILE__, __LINE__, 0, LOG_USER, __s, __f, ##__a)

#define LOGV1(__f, __a...)   \
    logmsgf(__FILE__, __LINE__, 1, LOG_USER, LOG_INFO, __f, ##__a)

#define LOGV2(__f, __a...)   \
    logmsgf(__FILE__, __LINE__, 2, LOG_USER, LOG_INFO, __f, ##__a)

#define LOGV3(__f, __a...)   \
    logmsgf(__FILE__, __LINE__, 3, LOG_USER, LOG_INFO, __f, ##__a)

/*
 * Function enter/exit trace macros. To use these, define TRACE_ENABLED
 * before including this file.
 */
#ifdef TRACE_ENABLED
#define DBG_ENTER(__f, __a...)  LOG(LOG_INFO, "--> %s(" __f ")", __func__, ##__a)
#define DBG_EXIT(__f, __a...)   LOG(LOG_INFO, "<-- %s " __f, __func__, ##__a)
#else
#define DBG_ENTER(__f, __a...)
#define DBG_EXIT(__f, __a...)
#endif

/* Register once at the start of a process, unregister at the end */

int log_register(const char *name);
void log_unregister(void);

/*
 * Logging functions. Use the macros above instead of calling these
 * directly.
 */
void vlogmsg(
    const char *file,
    int line,
    int verbosity,
    int facility,
    int severity,
    const char *format,
    va_list args
);

void logmsgf(
    const char *file,
    int line,
    int verbosity,
    int facility,
    int severity,
    const char *format,
    ...
);

void logmsg(
    const char *file,
    int line,
    int verbosity,
    int facility,
    int severity,
    const char *message
);

/*
 * Hexdump API
 */
void hexdump_offset(
    const uint8_t *buffer,
    size_t nbytes,
    uint32_t *start,
    uint8_t *hexbuffer,
    size_t hexbuf_len,
    uint32_t breakpoint
);

void hexdump(
    const void *buffer,
    size_t len,
    void (*print_fcn)(const char *, size_t, void *),
    void *
);

void hexdump_log(const void *buffer, size_t len);
void hexdump_fd(const void *buffer, size_t len, int fd);

/*
 * 'External' API; can be called either by the registered
 * program itself (pass NULL for name), or against separate
 * registered programs
 */
struct log_info
{
    char name[LOG_NAME_MAX];
    pid_t pid;
    int verbosity;
    int severity;
};

int log_iterate(uint32_t *pcontext, struct log_info *loginfo);

int log_verbosity_get(const char *name, int *verbosity);
int log_verbosity_set(const char *name, int verbosity);
int log_severity_get(const char *name, int *severity);
int log_severity_set(const char *name, int severity);

/*
 * log_targets_set() does not undo log_target_add_XXX(); it is
 * for temporarily turning off logging to a particular target
 * (and turning it back on).
 */
int log_targets_get(const char *name, uint32_t *targets);
int log_targets_set(const char *name, uint32_t targets);

int log_target_add_file(const char *name, const char *filepath);
int log_target_add_fd(const char *name, int fd);
int log_target_rem_file(const char *name);
int log_target_get_fd(const char *name, int *fd);
int log_target_get_file(const char *name, const char const **file);



#endif /* __LTRX_LOG_H__ */
