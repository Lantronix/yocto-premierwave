#ifndef __LTRX_WEBUI_API_
#define __LTRX_WEBUI_API_

#define MAX_LOCATION_LENGTH     64
#define MAX_URL_LENGTH          256
#define MAX_PROXY_URLS          64
#define MAX_EXTRA_PARAM_LENGTH  1024

enum error_values {
    E_OK         = 0,  /* Success */
    E_ARGS       = -1, /* Invalid Argments - NULL pointer */
    E_MEMSIZE    = -2, /* Invalid Size of Argument */
    E_IPC_ERROR  = -3, /* IPC Error */
    E_IPC_NOMEM  = -4, /* IPC Memory Allocation Error */
    E_SYNTAX     = -5, /* Error in syntax of URL registration */
    E_NO_LOC     = -6, /* Error Location not found */
    E_LIST_FULL  = -7, /* Error Proxy URL List FULL */
    E_LIST_EMPTY = -8, /* Error Proxy URL List Empty */
};

struct locationUrl
{
    char location[MAX_LOCATION_LENGTH+1];
    char url[MAX_URL_LENGTH+1];
    int  authentication;//1:inherited, 0:disabled
    char extra[MAX_EXTRA_PARAM_LENGTH+1];//additional NGINX parameters
};

/* Register a reverse proxy url with WEB server.

   Arguments:
       [location] location of proxy url. has to fit to "char[MAX_LOCATION_LENGTH]"
       [url] reverse proxy url. has to fit to "char [MAX_URL_LENGTH]"

   Return: E_OK on success and a negative error code otherwise.
   Note: Inherits authentication settings from http server configuration
*/
int webui_registerURL(const char *location, const char *url);

typedef enum {
    AuthenticationDisabled=0,
    AuthenticationInherited=1
} AuthenticationMethod;
/* Register a reverse proxy url with WEB server, override authentication and optional extra parameters.

   Arguments:
       [location] location of proxy url. has to fit to "char[MAX_LOCATION_LENGTH]"
       [url] reverse proxy url. has to fit to "char [MAX_URL_LENGTH]"
       [authentication] authentication for this location. AuthenticationInherited-inherited from HTTP server, AuthenticationDisabled-disabled

   Return: E_OK on success and a negative error code otherwise.
*/
int webui_registerURL_Ex(const char *location, const char *url, const AuthenticationMethod authentication);


/* Read all reverse proxy urls registered with webserver.

    Arguments:
       [list] on success, return all registed proxy urls.
       [count] on success, return the number of registered proxy URLS.

    Return: E_OK on success and a negative error code otherwise.
    On success, API will allocate memory to *list and User needs to free it after usage.
*/
int webui_listURL(struct locationUrl **list, unsigned int *count);

/* Delete a proxy url reqistered with web server per location.

   Arguments:
       [location] proxy url indicated by this location will be deleted

   Return: E_OK on success and a negative error code otherwise.
*/
int webui_deleteURL(const char *location);

#endif // __LTRX_WEBUI_API_
