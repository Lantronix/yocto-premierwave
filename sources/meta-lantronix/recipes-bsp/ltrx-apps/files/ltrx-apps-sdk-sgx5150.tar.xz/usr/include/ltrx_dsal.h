/*
 * Lantronix Device Server Abstraction Library
 *
 * Provides a general interface to device-related status and control.
 * The idea is to abstract things like PIO lines, driver ioctls, etc.
 * from the applications.
 *
 * Functions should be organized generally by device types, and should
 * work with IDs defined in here to avoid special code for different
 * platforms.
 *
 * While not all devices, and therefore either not all functions, or not
 * all device types or IDs will exist on all platforms, the interface
 * described here should not change. Those functions that are not
 * applicable to a particular platform should return ENXIO or ENOSYS.
 *
 * TODO: This still needs work, both to add functionality and possibly
 *       to refine the interface.
 */

#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define DSAL_INPUTS_MAX                 MAX_GPIO_INTERRUPT_SOURCES

#ifdef NUEVO_2
# if defined(TORO)
#  define DSAL_LED_STATE_DEFAULT        true
#  define DSAL_LED_COLOR_DEFAULT        DSAL_LED_COLOR_GREEN
#  define DSAL_LED_COLOR_ERROR          DSAL_LED_COLOR_ORANGE
# else
#  define DSAL_LED_STATE_DEFAULT        true
#  define DSAL_LED_COLOR_DEFAULT        DSAL_LED_COLOR_MONO
#  define DSAL_LED_COLOR_ERROR          DSAL_LED_COLOR_MONO
# endif
#else
# define DSAL_LED_STATE_DEFAULT         false
# define DSAL_LED_COLOR_DEFAULT         DSAL_LED_COLOR_MONO
# define DSAL_LED_COLOR_ERROR           DSAL_LED_COLOR_MONO
#endif


/*
** Inputs
*/

/* Internal inputs */
#define DSAL_TEMP                       2000
#define DSAL_TEMP1                      2001

#define DSAL_POWER                       400
#define DSAL_POWER_BARREL                401
#define DSAL_POWER_TERMINAL              402

#define DSAL_CELL                       1000
#define DSAL_CELL_WAKEUP                1001
#define DSAL_CELL_RING                  1002

#define DSAL_NFC_INTERRUPT              3001

#define DSAL_AP_TRIGGER                 4001

/* External inputs */
#define DSAL_DIG_INPUT                   200
#define DSAL_DIG_INPUT1                  201
#define DSAL_DIG_INPUT2                  202
#define DSAL_DIG_INPUT3                  203
#define DSAL_DIG_INPUT4                  204

/* NB: These values must match the key codes in the DTB */
#if defined(EDS3000PR) || defined(EDS3000PS)
#define DSAL_BUTTON_DEFAULTS             256
#else
#define DSAL_BUTTON_DEFAULTS             501
#endif
#define DSAL_BUTTON_WPS                  502

/*
** Output 
*/
#define DSAL_RELAY                          300
#define DSAL_RELAY1                         301
#define DSAL_RELAY2                         302

#define DSAL_LED_CELL_CONN_NONE             0
#define DSAL_LED_CELL_CONN_RADIONET         1
#define DSAL_LED_CELL_CONN_PACKETNET        2

/*
** LED colors. Ignored unless the the LEDs are driven from PWM.
*/
#define DSAL_LED_COLOR_MONO                 0
#define DSAL_LED_COLOR_ORANGE               1
#define DSAL_LED_COLOR_GREEN                2


#define DSAL_USB_MODE_HOST                  1
#define DSAL_USB_MODE_DEVICE                2


/*
** General Input API
*/
struct dsal_input_event
{
    bool dsie_change;
    uint32_t dsie_type;
    uint32_t dsie_value;
};

int dsal_input_read(uint32_t input);

int dsal_input_wait(
    uint32_t *inputs,
    struct dsal_input_event *events,
    size_t nevents
);

int dsal_usb_mode_set(uint32_t port, uint32_t mode);
#if defined(PLASTIC_PORTAL) || defined(EDS3000PR) || defined(EDS3000PS)
bool dsal_i2c_usb_device_init(const char *device);
int dsal_i2c_term(void);
int dsal_i2c_write(uint8_t regaddr, const uint8_t *buf, size_t bufsz);
#endif


/*
** Output API
*/
int dsal_ethphy_power_set(uint32_t ifnum, bool on);
int dsal_ethphy_power_get(uint32_t ifnum, bool *on);

int dsal_cellular_power_set(bool on);
int dsal_cellular_power_get(bool *on);

int dsal_cellular_reset(void);

/*
** LED API
*/
int dsal_led_status_set(bool on);
int dsal_led_status_set_color(uint32_t color);
int dsal_led_wlan_link_set(bool on);
#if (MAX_NETS_WLAN > 0)
int dsal_led_wps_status_set(bool on);
#endif
int dsal_led_usb_set(uint32_t portnum, bool device_inserted);
int dsal_led_cellular_set(uint32_t state);
int dsal_led_signal_set(uint32_t level);
int dsal_led_eth_duplex_set(bool full);

/*
** Relay API
*/
int dsal_relay_set(uint32_t index, bool close);
int dsal_relay_get(uint32_t index, bool *closed);

/*
** Sensor API
*/
int dsal_temp_get(
    uint32_t sensor_id,
    int32_t *degrees_celsius,
    uint32_t *tenth_degrees /* optional */
);

#ifdef USE_NFC
int dsal_nfc_reset(void);
#endif

