/******************************************************************************
 * Copyright (C) 2004 by Lantronix, Inc.
 *                       15353 Barranca Parkway
 *                       Irvine, CA 92618
 * This software is furnished under a license and may be used and copied only
 * in accordance with the terms of such license and with the inclusion of the
 * above copyright notice.  This software or any copies thereof may not be
 * provided or otherwise made available to any other person.  No title or
 * ownership of the software is hereby transferred.  The information in this
 * software is subject to change without notice and should not be construed
 * as a commitment by Lantronix, Inc.
 *
 * File     mpnipc.h
 *          Interfaces for MPN IPC functions
 *
 * Author   bchang
 *****************************************************************************/
#ifndef _MPNIPC_H_
#define _MPNIPC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <sys/types.h>

//static const char *mpnipc_msgf = "msg x%X id x%X from %ld.%ld (id x%X): ";
#define mpnipc_msgf "msg x%X id x%X from %ld.%ld (id x%X): "

#ifdef MPNIPC_DEBUG
#define MSGLOG(m, s, f, a...)   do {                            \
    printf(mpnipc_msgf f,                                       \
        (m)->msg_id, (m)->cfg_idx, (m)->sid.pid, (m)->sid.tid,  \
        (m)->sender_id, ##a);                                   \
                                } while (0)
#else
#include "tlog.h"
#define MSGLOG(m, s, f, a...)   do {                            \
    VTLOG(s, mpnipc_msgf f,                                     \
        (m)->msg_id, (m)->cfg_idx, (m)->sid.pid, (m)->sid.tid,  \
        (m)->sender_id, ##a);                                   \
                                } while (0)
#endif


enum mpnipc_task_id
{
    MPN_TASK_ID_CLI,
    MPN_TASK_ID_CFG,
    MPN_TASK_ID_AS,
    MPN_TASK_ID_SUPPLICANT,
    MPN_TASK_ID_EVO,
    MPN_TASK_ID_FUSEFS,
	MPN_TASK_ID_DIRESPONDER,
    MPN_TASK_ID_SNMP2CFG,
#ifdef ANALOG_DEVICE_SERVER
    MPN_TASK_ID_SNMP2ADS,
    MPN_TASK_ID_ADSPROTOCOL,
#endif
    MPN_TASK_ID_GETIFMETRIC,
    MPN_TASK_ID_CELLD,
    MPN_TASK_ID_NETMAN,
    MPN_TASK_ID_ALARMD,
    MPN_TASK_ID_SMSTUND,
    MPN_TASK_ID_BRMGR,
    MPN_TASK_ID_SER_COMMANDMODE,
    MPN_TASK_ID_SER_APPLYCFG,
    MPN_TASK_ID_SER_BREAK,
    MPN_TASK_ID_SER_CON,
#ifdef USE_MYSTIQUE
    MPN_TASK_ID_MACH10,
    MPN_TASK_ID_MACH10_LINE,
#if defined(USE_MYSTIQUE_REMOTE_ACCESS)
    MPN_TASK_ID_WEBCONTROL,
    MPN_TASK_ID_WEBTERMINAL,
#endif
#endif
    MPN_TASK_ID_L2NAT,
};

extern const enum mpnipc_task_id g_MpnIpcTaskId;

#define MPN_DEST_AS                     "/tmp/ipc/as.ipc"
#define MPN_DEST_CFG                    "/tmp/ipc/cfg.ipc"
#define MPN_DEST_EVO                    "/tmp/ipc/evo.ipc"
#define MPN_DEST_CMDPROXY               "/tmp/ipc/cmdproxy.ipc"
#define MPN_DEST_NETMAN                 "/tmp/ipc/nm.ipc"
#define MPN_DEST_CELLD                  "/tmp/ipc/celld.ipc"
#define MPN_DEST_ALARMD                  "/tmp/ipc/alarmd.ipc"
#define MPN_DEST_SMSTUND                "/tmp/ipc/smstund.ipc"
#define MPN_DEST_CFCLIENT               "/tmp/ipc/cfclient.ipc"
#define MPN_DEST_CFALCLIENT             "/tmp/ipc/cfalclient.ipc"

#define MPN_IPC_MAX_FILEPATH_LEN        256

//-----------------
// sender ID list
//-----------------
#define MPN_ID_BASE                     0x1000
#define MPN_ID_AS                       0x1001  // application server
#define MPN_ID_CFG                      0x1002  // configuration server
#define MPN_ID_SUPPLICANT               0x1003  // wpa supplicant
#define MPN_ID_PWAVE_FUSE_FS            0x1004  // fuse file system handler
#define MPN_ID_EVO                      0x1005  // Evo server
#define MPN_ID_CMDPROXY                 0x1006  // command proxy server
#define MPN_ID_DIRESPONDER              0x1007  // Device Installer Responder
#define MPN_ID_NETMAN                   0x1009

#define MPN_ID_CLI                      (MPN_ID_BASE + 0x10)
#define MPN_ID_WEB                      (MPN_ID_BASE + 0x11)

#define MPN_ID_CELLD                    (MPN_ID_BASE + 0x12)
#define MPN_ID_ALARMD                   (MPN_ID_BASE + 0x13)
#define MPN_ID_SMSTUND                  (MPN_ID_BASE + 0x14)
#define MPN_ID_L2NAT                    (MPN_ID_BASE + 0x15)

#define MPN_ID_SDKUSER                  (MPN_ID_BASE + 0x100)

//----------------
// GET messages
//----------------
#define MPN_MSG_GET_CFG                 0x2001
#define MPN_MSG_GET_FLASH_CFG           0x2002
#define MPN_MSG_GET_TUNNEL_CONTROL_DATA 0x2005
#define MPN_MSG_GET_LINE_COMMAND_MODE   0x2006
#define MPN_MSG_GET_FLASH_PACKED_CFG    0x2007
#define MPN_MSG_GET_CFG_STATUS          0x2008
#define MPN_MSG_GET_SERIAL_START_DELAY  0x2009
#define MPN_MSG_GET_SERIAL_SIGNON_MSG   0x200A
#define MPN_MSG_GET_SERIAL_START_STRING 0x200B
#define MPN_MSG_GET_SMS_TUNNEL_CONTROL_DATA 0x200C

//--------------------
// SET/UNSET messages
//--------------------

//CFGLOCK_MSG_REQUIRES_LOCK begin
#define MPN_MSG_SET_CFG                 0x3001
#define MPN_MSG_DELETE_CFG              0x3002
#define MPN_MSG_DELETE_FLASH_CFG        0x3003
#define MPN_MSG_SET_TRUSTED_CERT        0x3004
#define MPN_MSG_SET_INTERMEDIATE_CERT   0x3005
#define MPN_MSG_SET_LINE_COMMAND_MODE   0x3006
#define MPN_MSG_SET_FLASH_PACKED_CFG    0x3007
#define MPN_MSG_DELETE_FLASH_PACKED_CFG 0x3008
#define MPN_MSG_SET_FLASH_CFG           0x3009
#define MPN_MSG_SET_SERIAL_START_DELAY  0x300A
#define MPN_MSG_SET_SERIAL_SIGNON_MSG   0x300B
#define MPN_MSG_SET_SERIAL_START_STRING 0x300C
//CFGLOCK_MSG_REQUIRES_LOCK end
#define MPN_MSG_SET_CFG_STATUS          0x3500

//-----------------
// NOTIFY messages
//-----------------
#define MPN_MSG_NOTIFY_AS               0x4001
#define MPN_MSG_NOTIFY_WLAN_LINK_DOWN   0x4002
#define MPN_MSG_NOTIFY_WLAN_LINK_UP     0x4003
#define MPN_MSG_NOTIFY_EVO              0x4004
#define MPN_MSG_NOTIFY_AS_SSH_CLIENT_KNOWN_HOSTS_CHANGE 0x4005
#define MPN_MSG_NOTIFY_WLAN_WPS_DONE  		0x4006
#define MPN_MSG_NOTIFY_WLAN_WPS_TIMEOUT  	0x4007
#define MPN_MSG_NOTIFY_ALARMD           0x4008
#define MPN_MSG_NOTIFY_SMS_TUNNEL       0x4009
#define MPN_MSG_NOTIFY_NWSCRIPT_DONE    0x4010
#define MPN_MSG_NOTIFY_CLOCKUPDATE      0x4011
//---------------------
// Extra messages here
//---------------------
#define MPN_MSG_SAVE_CFG                0x5001
#define MPN_MSG_IMPORT_CFG              0x5002
#define MPN_MSG_EXPORT_CFG              0x5003
#define MPN_MSG_REBOOT                  0x5004
#define MPN_MSG_RELOAD_FACTORY_DEFAULTS 0x5005
#define MPN_MSG_APPLY_WLAN_PROFILE      0x5006
#define MPN_MSG_APPLY_WLAN_IFC_CFG      0x5007
#define MPN_MSG_GET_ACTIVE_IFC          0x5008
#define MPN_MSG_GET_LINK_STATE          0x5009
#define MPN_MSG_GET_XCR_LIST            0x500A
#define MPN_MSG_GET_XCR_GROUP_LIST      0x500B
#define MPN_MSG_STORE_OEM_DEFAULTS      0x500C
#define MPN_MSG_DELETE_OEM_DEFAULTS     0x500D
#define MPN_MSG_APPLY_SYSLOG_CFG        0x500E
#define MPN_MSG_SET_OEM_MAC_ADDR        0x500F
#define MPN_MSG_PROXY_COMMAND           0x5010
#define MPN_MSG_GET_BRIDGE_RUNTIME_ENABLE_STATE 0x5011
#define MPN_MSG_GET_BRIDGE_ACTIVE_STATE 0x5012
#define MPN_MSG_GET_BRIDGE_CURRENT_MAC  0x5013
#define MPN_MSG_GET_BRIDGE_STATS        0x5014
#define MPN_MSG_CLEAR_BRIDGE_STATS      0x5015
#define MPN_MSG_LOCK_EVO_SER_PORT_ACCESS     0x5016
#define MPN_MSG_UNLOCK_EVO_SER_PORT_ACCESS   0x5017
#define MPN_MSG_GET_SERIAL_CLI_SESSION_STATE 0x5018
#define MPN_MSG_KILL_SERIAL_CLI_SESSION      0x5019
#define MPN_MSG_GET_CLI_BACKDOOR_COMPLETION_STATE 0x501A
#define MPN_MSG_START_RADIO_TEST_MODE	0x501B
#define MPN_MSG_END_RADIO_TEST_MODE	    0x501C
#define MPN_MSG_IS_LINK_UP              0x501D
#define MPN_MSG_START_WPS_PBC			0x501E
#define MPN_MSG_CANCEL_WPS_PBC			0x501F
#define MPN_MSG_APPLY_WLAN_PROFILE_EX			0x5020
#define MPN_MSG_APPLY_ORIGINAL_WLAN_PROFILES	0x5021
#define MPN_MSG_WLANHASBEENCHANGEDBUTNOTYETAPPLIED  0x5022
#define MPN_MSG_LOCK_SMSTUNNEL_SER_PORT_ACCESS     0x5023
#define MPN_MSG_UNLOCK_SMSTUNNEL_SER_PORT_ACCESS   0x5024
#define MPN_MSG_AS_LOCK_ALL_SER_PORT_ACCESS        0x5025
#define MPN_MSG_AS_UNLOCK_ALL_SER_PORT_ACCESS      0x5026
#ifdef USE_AUTOREBOOT_TIMER
#define MPN_MSG_GET_SCHEDULED_REBOOT_TIME	0x5027
#endif
#define MPN_MSG_GET_WLAN_PROFILE_INSTANCE 0x5028
#define MPN_MSG_START_WPS_PIN			0x5029
#define MPN_MSG_GET_WPS_STATE           0x5030
#define MPN_MSG_STORE_MACH10_DEFAULTS   0x5040
#define MPN_MSG_APPLY_MACH10_DEFAULTS   0x5041
#define MPN_MSG_DELETE_MACH10_DEFAULTS   0x5042
#define MPN_MSG_EXIT                    0x5043
#define MPN_MSG_AUDITLOG_UPDATE         0x5044
#ifdef ANALOG_DEVICE_SERVER
#define MPN_MSG_EVO_CMD_ADSPROTOCOL		0x5100
#endif
#define MPN_MSG_GET_BRIDGE_RUNTIME_TRANSPARENT_STATE 0x5101
#ifdef USE_EXTERNAL_APPS
#define MPN_MSG_PROXY_COMMAND_PYTHON       0x5110
#endif
#ifdef USE_WLAN_LTRX_ROAMING
#define MPN_MSG_GET_SMART_ROAM_STATUS       0x5111
#endif
//---------------------
// Interprocess TestSet
//---------------------
#define MPN_MSG_CFG_TESTSET             0x6001

//---------------------
// Interprocess command
//---------------------
#define MPN_MSG_IPC_CMD_BASE            0x7000

// The following flags may be added to status_flags as needed
#define MPN_MSG_REPLY_FLAG              0x100
#define MPN_MSG_ACK_FLAG                0x200
#define MPN_MSG_ERROR_FLAG              0x400
#define MPN_MSG_BUSY_FLAG               0x800  // The process was too busy to handle the message

#ifdef EDS_MD
#define MAX_MSG_LEN                     (52 * 1024)
#else
#define MAX_MSG_LEN                     24576 /* 24KB  - The ManageLinx structure is really big */
#endif

#define MAX_XML_ERROR_MSG_LEN           8192  /* 8KB */
#define MPN_IPC_MAX_CONN                128    /* !!! Need to adjust this value after reworking max conn handling !!! */
#define MPN_INITYPE_SENDER              0
#define MPN_INITYPE_RECEIVER            0
#define MPN_IPC_DEFAULT_IP              "127.0.0.1"
#define MPN_IPC_DEFAULT_SELECT_WAIT     180
#define MPN_TIMEOUT_FOREVER             (-1)

// error and status code
#define MPN_MSG_SUCCESS                 0x00
#define MPN_MSG_FAILED                  0x01
#define MPN_MSG_CONTINUE                0x02
#define MPN_MSG_GOT_DATA                0x03

#define MPN_MSG_ERROR_NOINIT            0x04
#define MPN_MSG_ERROR_GETHOST           0x05
#define MPN_MSG_ERROR_SOCKET            0x06
#define MPN_MSG_ERROR_SOCKETOP          0x07
#define MPN_MSG_ERROR_SOCKETBIND        0x08
#define MPN_MSG_ERROR_SOCKETSETOP       0x09
#define MPN_MSG_ERROR_CONNECT           0x0a
#define MPN_MSG_ERROR_SOCKETLISTEN      0x0b
#define MPN_MSG_ERROR_SOCKETWAIT        0x0c
#define MPN_MSG_ERROR_TOOMANY_CONNS     0x0d
#define MPN_MSG_ERROR_ACCEPT_NEWCONN    0x0e
#define MPN_MSG_ERROR_NO_SUCH_CONN      0x0f
#define MPN_MSG_ERROR_SOCKET_IO         0x10
#define MPN_MSG_ERROR_BAD_PARAM         0x11
#define MPN_MSG_ERROR_OP_NOT_SUPPORTED  0x12
#define MPN_MSG_ERROR_FILTER            0x13
#define MPN_MSG_ERROR_CONN_CLOSED       0x14

#define MPN_CHAN_INVALID                (-1)
#define MPN_CHAN_CURRENT                (-2)

typedef struct _mpnipc_sender_id
{
    pid_t pid;
    pid_t tid;
} mpnipc_sender_id;

typedef struct _mpnipc_sender
{
    int  conn;                          // current connection
    int  status;                        // status of last call
    char dest[32];
} mpnipc_sender;

typedef struct _mpnipc_receiver
{
    int  conn_list[MPN_IPC_MAX_CONN];   // connection list
    int  root_conn;
    int  cur_chan;
    int  status;                        // status of last call
    int  max_conn;
    fd_set read_set;
    mpnipc_sender_id sid;
} mpnipc_receiver;

typedef struct _mpnipc_filter_data
{
    uint8_t opaque[16];
} mpnipc_filter_data;

typedef struct _mpnipc_msg
{
    int sender_id;                      // sender ID
    mpnipc_sender_id sid;
    mpnipc_filter_data fdata;
    int msg_id;                         // message id
    int senderEnvironment;              // enum cfgvar_testset_environment
    union
    {
        int cfg_idx;                    // config varid index, 0 if N/A
        struct
        {
            int     cmd_idx;            //command identifier
            char    cmd_response[MPN_IPC_MAX_FILEPATH_LEN]; //response
        }cmd;
    };
    int item_idx;                       // (zero-based) index of varid item
    int status_flags;                   // status flags
    char username[32];                  //username of configurator
    char ip_addr[48];                   //ip address of configurator
    int msgbody_len;                    // length (in bytes) of msgbody
    unsigned char msgbody[MAX_MSG_LEN]; // message data
} mpnipc_msg;

#define XSR_FORMAT_XML  0
#define XSR_FORMAT_JSON 1

typedef struct ipc_xml_req
{
    char filePath[MPN_IPC_MAX_FILEPATH_LEN];
    char groups[2048];
    int secrets;
    int userFile;
    int fromCapture;
    int privileged;
    int loggedIn;
    int recordFormat;
    int metadata;
    char excludedGroups[1024];//exclude these groups
    char user[64];//logged in username
} ipc_xml_req;

typedef struct ipc_xml_reply
{
    char filePath[MPN_IPC_MAX_FILEPATH_LEN];
    char errorMsg[MAX_XML_ERROR_MSG_LEN];
} ipc_xml_reply;

typedef struct ipc_cmdmode_set_req
{
    int port;
    int cmdMode;
    bool IsReq4rmModemEmulation;
    bool LineAuthEnable;
} ipc_cmdmode_set_req;

typedef struct ipc_serial_start_delay
{
    uint16_t port;
    uint32_t delayMs;
} ipc_serial_start_delay;

typedef struct ipc_serial_signon_msg
{
    uint16_t port;
    uint16_t msgLen;
    uint8_t  msg[16];
} ipc_serial_signon_msg;

typedef struct ipc_serial_string_msg
{
    uint16_t port;
    int      stringSet;
    uint16_t string[64];
} ipc_serial_string_msg;

typedef struct ipc_oem_macaddr_set_req
{
    int     netno;
    uint8_t macAddr[6];
} ipc_oem_macaddr_set_req;

typedef struct cmd_proxy_req
{
    char cmd[1024];
    char requestId[32];
} cmd_proxy_req;

typedef struct cmd_proxy_reply
{
    int  retVal;
    char outputFilePath[MPN_IPC_MAX_FILEPATH_LEN];
} cmd_proxy_reply;

#ifdef USE_EXTERNAL_APPS
#define ROOT_UID  0
#define ROOT_GID  0
#define ADMIN_UID 1001
#define ADMIN_GID 1001

typedef struct
{
    char filename[256];
    char output[256];
    char parameters[1024];
} cmd_proxy_req_py;

typedef struct
{
    int  retVal;
    char status[256];
} cmd_proxy_reply_py;

#endif

typedef struct _audit_log
{
    char timestamp[64];
    char username[64];
    char ip_address[48];
    char category[64];
    char action[32];
    char detail[256];
    char result[32];
} audit_log;

typedef int(*mpnipc_filter_fcn_t)(mpnipc_msg *);

struct mpnipc_filter_ops
{
    mpnipc_filter_fcn_t mpnipc_msg_presend;
    mpnipc_filter_fcn_t mpnipc_msg_postrecv;
    mpnipc_filter_fcn_t mpnipc_reply_presend;
    mpnipc_filter_fcn_t mpnipc_reply_postrecv;
};

int mpnipc_filter_register(const struct mpnipc_filter_ops *);
void mpnipc_filter_unregister(void);

void mpnipc_sender_id_set(int);
int mpnipc_sender_id_get(void);

int mpnipc_sender_init(mpnipc_sender *h, int port);
int mpnipc_sender_init_domain(mpnipc_sender* h, const char* path);
int mpnipc_sender_send(mpnipc_sender *h, const mpnipc_msg *data);
int mpnipc_sender_wait(mpnipc_sender *h, int timeout);
int mpnipc_sender_receive(mpnipc_sender *h, mpnipc_msg *data);
int mpnipc_sender_close(mpnipc_sender *h);

int mpnipc_receiver_init(mpnipc_receiver *h, int port);
int mpnipc_receiver_init_domain(mpnipc_receiver* h, const char* path);
int mpnipc_receiver_wait(mpnipc_receiver *h, int timeout_secs, int timeout_usecs);
int mpnipc_receiver_get_data(mpnipc_receiver *h, mpnipc_msg *data, int channel);
int mpnipc_receiver_reply(mpnipc_receiver *h, mpnipc_msg *data, int channel);
int mpnipc_receiver_close_channel(mpnipc_receiver *h, int channel);
int mpnipc_receiver_close(mpnipc_receiver *h);

int mpnipc_send_msg(mpnipc_sender*       existingConn,
                    const mpnipc_msg*    msg,
                    const char*          destAddr);

int mpnipc_send_and_get_msg(mpnipc_sender*       existingConn,
                            const mpnipc_msg*    msg,
                            mpnipc_msg*          reply,
                            const char*          destAddr);

int mpnipc_get_cfg(mpnipc_sender* existingConn,
                   int            senderId,
                   int            varidEntryIndex,
                   void*          pDesignatedVar,
                   int            dataLen);

int mpnipc_set_cfg(mpnipc_sender* existingConn,
                   int            senderId,
                   int            varidEntryIndex,
                   const void*    pDesignatedVar,
                   int            dataLen);

int mpnipc_delete_cfg(mpnipc_sender*   existingConn,
                      int              senderId,
                      int              varidEntryIndex,
                      const void*      pDesignatedVar,
                      int              dataLen,
                      const char*      destAddr);

int mpnipc_notify_as(mpnipc_sender*   existingConn,
                     int              varidEntryIndex,
                     const void*      pDesignatedVar,
                     int              dataLen);

int mpnipc_notify_alarmd(mpnipc_sender*   existingConn,
        int              varidEntryIndex,
        const void*      pDesignatedVar,
        int              dataLen);
int mpnipc_notify_evo(mpnipc_sender*  existingConn,
                     int              varidEntryIndex,
                     const void*      pDesignatedVar,
                     int              dataLen);

int mpnipc_notify_sms(mpnipc_sender*  existingConn,
                     int              varidEntryIndex,
                     const void*      pDesignatedVar,
                     int              dataLen);
int mpnipc_proxy_shell_cmd(const char* shellCmd,
                           char*       outputFilePath);

int mpnipc_lock_evo_ser_port_access(
    mpnipc_sender *existingConn,
    unsigned int serPortZeroBasedIndex,
    unsigned int senderId,
    const char *lockedBy
);

int mpnipc_unlock_sms_ser_port_access(mpnipc_sender* existingConn,
                                      unsigned int   serPortZeroBasedIndex,
                                      unsigned int   senderId);

int mpnipc_lock_sms_ser_port_access(
    mpnipc_sender *existingConn,
    unsigned int serPortZeroBasedIndex,
    unsigned int senderId,
    const char *lockedBy
);

int mpnipc_as_lock_all_ser_port_access(
    mpnipc_sender *existingConn,
    unsigned int serPortZeroBasedIndex,
    unsigned int senderId,
    const char *lockedBy);

int mpnipc_as_unlock_all_ser_port_access(
		mpnipc_sender* existingConn,
        unsigned int   serPortZeroBasedIndex,
        unsigned int   senderId);
int mpnipc_unlock_evo_ser_port_access(mpnipc_sender* existingConn,
                                      unsigned int   serPortZeroBasedIndex,
                                      unsigned int   senderId);

int mpnipc_execute_command(int command,
                       const char* destination,
                       const void* pParams,
                       int dataLen,
                       void **pResponse,
                       int *responseLen,
                       void (*writeMessageLine)(const char *pMessage, void *pOpaque),
                       void *pOpaque);

int mpnipc_send_trigger(const int command,
        const char*  destination,
        const void* 	pParams,
        const int 	dataLen);
int mpnipc_notify_server(mpnipc_sender*  existingConn,
        int              varidEntryIndex,
        const void*      pDesignatedVar,
        int              dataLen,
        int              serverId);

/*
 * Dynamic loading
 */
typedef int (*ipcft_send_msg)(
    mpnipc_sender *,
    const mpnipc_msg *,
    const char *
);

typedef int (*ipcft_send_and_get_msg)(
    mpnipc_sender *,
    const mpnipc_msg *,
    mpnipc_msg *,
    const char *
);

typedef int (*ipcft_execute_command)(
    int,
    const char *,
    const void *,
    int,
    void **,
    int *,
    void (*)(const char *, void *),
    void *
);


#define MPNIPC_FNNAME_SEND_MSG          "mpnipc_send_msg"
#define MPNIPC_FNNAME_SEND_AND_GETMSG   "mpnipc_send_and_get_msg"
#define MPNIPC_FNNAME_EXECUTE_COMMAND   "mpnipc_execute_command"

#ifdef __cplusplus
}
#endif
bool mpnipc_send_Auditlog_to_Mach10_Client(const char* action, const char* category, char* detail, char * user, char* ipaddr, char* result);
#endif
