
#ifndef __LTRX_WLAN_H__
#define __LTRX_WLAN_H__

#ifdef USE_WLAN_RF_REDPINE

#define WLAN_24GHZ_RSSI2LEVEL(__r) (        \
    __r < -80 ? 0 : (                       \
    __r < -75 ? 1 : (                       \
    __r < -70 ? 2 : (                       \
    __r < -65 ? 3 : (                       \
    __r < -60 ? 4 : 5 )))))                 \

#define WLAN_50GHZ_RSSI2LEVEL(__r) (        \
    __r < -70 ? 0 : (                       \
    __r < -68 ? 1 : (                       \
    __r < -65 ? 2 : (                       \
    __r < -62 ? 3 : (                       \
    __r < -60 ? 4 : 5 )))))                 \

#endif /* USE_WLAN_RF_REDPINE */

#endif /* __LTRX_WLAN_H__ */
