/*
 * Copyright (C) 2016 Lantronix, Inc. All Rights Reserved.
 *
 * ltrx_security_api.h
 * ltrx security API
 */

/**
* @file ltrx_security_api.h
* @brief This is interface header for Lantronix Security API
*/

#ifndef __LTRX_SECURITY_API_H
#define __LTRX_SECURITY_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stdbool.h"
#include "stdlib.h"

/**
* @brief List of possible return codes
*/
typedef enum ltrx_status
{
    LTRX_SUCCESS                = 0x00, //!< Function succeeded
    LTRX_CONFIG_ZONE_LOCKED     = 0x01, //!< Configuration zone is locked
    LTRX_DATA_ZONE_LOCKED       = 0x02, //!< Data zone is locked
    LTRX_WAKE_FAILED            = 0xD0, //!< Failed to wake the trusted platform module
    LTRX_CHECKMAC_VERIFY_FAILED = 0xD1, //!< Response status byte indicates CheckMac failure (status byte = 0x01)
    LTRX_PARSE_ERROR            = 0xD2, //!< Response status byte indicates parsing error (status byte = 0x03)
    LTRX_STATUS_CRC             = 0xD4, //!< Response status byte indicates CRC error (status byte = 0xFF)
    LTRX_STATUS_UNKNOWN         = 0xD5, //!< Response status byte is unknown
    LTRX_STATUS_ECC             = 0xD6, //!< Response status byte is ECC fault (status byte = 0x05)
    LTRX_STATUS_SELFTEST_ERROR  = 0xD7, //!< Response status byte is Self Test Error, chip in failure mode (status byte = 0x07)
    LTRX_FUNC_FAIL              = 0xE0, //!< Function could not execute due to incorrect condition / state
    LTRX_GEN_FAIL               = 0xE1, //!< Unspecified error
    LTRX_INVALID_PARAMETER      = 0xE2, //!< Bad argument (out of range, null pointer, etc.)
    LTRX_INVALID_ID             = 0xE3, //!< Invalid device id, id not set
    LTRX_INVALID_SIZE           = 0xE4, //!< Count value is out of range or greater than buffer size
    LTRX_BAD_CRC                = 0xE5, //!< incorrect CRC received
    LTRX_RX_FAIL                = 0xE6, //!< Timed out while waiting for response. Number of bytes received is > 0
    LTRX_RX_NO_RESPONSE         = 0xE7, //!< Not an error while the Command layer is polling for a command response
    LTRX_RESYNC_WITH_WAKEUP     = 0xE8, //!< Re-synchronization succeeded, but only after generating a Wake-up
    LTRX_PARITY_ERROR           = 0xE9, //!< for protocols needing parity
    LTRX_TX_TIMEOUT             = 0xEA, //!< for Atmel PHY protocol, timeout on transmission waiting for master
    LTRX_RX_TIMEOUT             = 0xEB, //!< for Atmel PHY protocol, timeout on receipt waiting for master
    LTRX_COMM_FAIL              = 0xF0, //!< Communication with device failed. Same as in hardware dependent modules
    LTRX_TIMEOUT                = 0xF1, //!< Timed out while waiting for response. Number of bytes received is 0
    LTRX_BAD_OPCODE             = 0xF2, //!< opcode is not supported by the device
    LTRX_WAKE_SUCCESS           = 0xF3, //!< received proper wake token
    LTRX_EXECUTION_ERROR        = 0xF4, //!< chip was in a state where it could not execute the command, response status byte indicates command execution error (status byte = 0x0F)
    LTRX_UNIMPLEMENTED          = 0xF5, //!< Function or some element of it hasn't been implemented yet
    LTRX_ASSERT_FAILURE         = 0xF6, //!< Code failed run-time consistency check
    LTRX_TX_FAIL                = 0xF7, //!< Failed to write
    LTRX_NOT_LOCKED             = 0xF8, //!< Required zone was not locked
    LTRX_NO_DEVICES             = 0xF9, //!< For protocols that support device discovery (kit protocol), no devices were found
    LTRX_HEALTH_TEST_ERROR      = 0xFA, //!< Random number generator health test error
}LTRX_STATUS;

/**
* @brief Private key indices on the device
*/
typedef enum private_key_storage_index
{
    LTRX_PRIVATE_KEY_1=0,/**< Private Key storage index 1 */
    LTRX_PRIVATE_KEY_2=1,/**< Private Key storage index 2 */
    LTRX_PRIVATE_KEY_3=2,/**< Private Key storage index 3 */
    LTRX_PRIVATE_KEY_4=3,/**< Private Key storage index 4 */
}PRIVATE_KEY_STORAGE_INDEX;

/**
* @brief Public key indices on the device
*/
typedef enum public_key_storage_index
{
    LTRX_PUBLIC_KEY_1=0,/**< Public Key storage index 1 */
    LTRX_PUBLIC_KEY_2=1,/**< Public Key storage index 2 */
}PUBLIC_KEY_STORAGE_INDEX;

/**
* @brief Public and Private key pair indices on the device
*/
typedef enum key_pair_storage_index
{
    LTRX_PUBLIC_PRIVATE_KEY_1=0,/**< Public-Private Key storage index 1 */
    LTRX_PUBLIC_PRIVATE_KEY_2=1,/**< Public-Private Key storage index 2 */
}KEY_PAIR_STORAGE_INDEX;

#if 0
/**
* @brief Certificate indices on the device
*/
typedef enum certificate_storage_index
{
    LTRX_CERTIFICATE_1=0,/**< Certificate storage index 1 */
    LTRX_CERTIFICATE_2,  /**< Certificate storage index 2 */
}CERTIFICATE_STORAGE_INDEX;

/**
* @brief Certificate private key pair indices on the device
*/
typedef enum credential_storage_index
{
    LTRX_CREDENTIAL_1=0,/**< Certificate-Private Key storage index 1 */
    LTRX_CREDENTIAL_2,  /**< Certificate-Private Key storage index 2 */
}CREDENTIAL_STORAGE_INDEX;
#endif

#define LTRX_TPM_FLAGS_NOOP       (0x0) /**< No operation */
#define LTRX_TPM_FLAGS_LOCK       (0x1) /**< Lock after operation completes */
#define LTRX_TPM_FLAGS_OVERWRITE  (0x4) /**< Overwrite previous contents */

#define LTRX_SYMMETRIC_KEY_SIZE   (32) /**< Size of symmetric SHA key */
#define LTRX_SHA_DIGEST_SIZE      (32) /**< Size of SHA digest */
#define LTRX_SIGNATURE_SIZE       (64) /**< Size of P-256 signature */
#define LTRX_PUBLIC_KEY_SIZE      (64) /**< Size of P-256 public key */
#define LTRX_RANDOM_NUM_SIZE      (32) /**< Number of bytes of random data */
/**
* @brief Query Trusted Platform Module support on the device
*
* @return LTRX_SUCCESS on success, otherwise an error code
*/
bool ltrx_tpm_enabled(void);

#if 0
/**
* @brief Returns certificate and private key index used for the credential
*
* @param[in] idx            Credential storage index
* @param[out] certificate   Storage index of the certificate
* @param[out] private_key   Storage index of the private key
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_credential_to_storage(CREDENTIAL_STORAGE_INDEX idx, CERTIFICATE_STORAGE_INDEX* certificate, PRIVATE_KEY_STORAGE_INDEX* private_key);
#endif

/**
* @brief Returns public and private key index used for the key pair
*
* @param[in] idx            Index of the key pair stored
* @param[out] public_key    Index of the public key storage
* @param[out] private_key   Index of the private key storage
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_keypair_to_storage(KEY_PAIR_STORAGE_INDEX idx, PUBLIC_KEY_STORAGE_INDEX* public_key, PRIVATE_KEY_STORAGE_INDEX* private_key);

/**
* @brief Free memory buffer
*
* @param[in] buffer             Memory which needs to be freed
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_free_buffer(uint8_t* buffer);

/**
* @brief Generate 32 bytes of random data
*
* @param[out] random        Random data
* @param[out] length        Length of random data
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_get_random(uint8_t** random, size_t* length);

/**
* @brief Generate and store a public private key pair in the device
*
* @param[in] idx            Storage index of public/private key pair
* @param[out] flags         Operation flags
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_generate_public_private_key_pair(KEY_PAIR_STORAGE_INDEX idx, uint32_t flags);

/**
* @brief Generate and store a private key in the device
*
* @param[in] idx           Storage index of private key
* @param[in] flags         Operation flags
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_generate_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint32_t flags);

/**
* @brief Store a private key in the device
*
* @param[in] idx           Storage index of private key
* @param[in] flags         Operation flags
* @param[in] key           Private key
* @param[in] keyLength     Length of private key
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_store_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint32_t flags, const uint8_t *key, size_t keyLength);

/**
* @brief Read a private key stored in the device
*
* @param[in] idx            Storage index of private key
* @param[out] key           Private key
* @param[out] keyLength     Length of private key
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_read_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint8_t **key, size_t* keyLength);

/**
* @brief Store a public key in the device
*
* @param[in] idx           Storage index of public key
* @param[in] flags         Operation flags
* @param[in] key           Public key
* @param[in] keyLength     Length of public key
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_store_public_key(PUBLIC_KEY_STORAGE_INDEX idx, uint32_t flags, const uint8_t *key, size_t keyLength);

/**
* @brief Read a public key stored in the device
*
* @param[in] idx            Storage index of public key
* @param[out] key           Public key
* @param[out] keyLength     Length of public key
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_read_public_key(PUBLIC_KEY_STORAGE_INDEX idx, uint8_t **key, size_t* keyLength);

/**
* @brief Delete a private key stored in the device
*
* @param[in] idx           Storage index of private key
* @param[in] flags         Operation flags
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_delete_private_key(PRIVATE_KEY_STORAGE_INDEX idx, uint32_t flags);

/**
* @brief Delete a public key stored in the device
*
* @param[in] idx           Storage index of public key
* @param[in] flags         Operation flags
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_delete_public_key(PUBLIC_KEY_STORAGE_INDEX idx, uint32_t flags);

/**
* @brief Delete a public private key pair stored in the device
*
* @param[in] idx           Storage index of public/private key pair
* @param[in] flags         Operation flags
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_delete_public_private_key_pair(KEY_PAIR_STORAGE_INDEX idx, uint32_t flags);

/**
* @brief Sign a message using a private key stored in the device
*
* @param[in] idx                Storage index of private key
* @param[in] message            Message to be signed
* @param[in] messageLength      Length of the message
* @param[out] signature         Signature
* @param[out] signatureLength   Length of the signature
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_sign_message(PRIVATE_KEY_STORAGE_INDEX idx, const uint8_t *message, size_t messageLength, uint8_t **signature, size_t* signatureLength);

/**
* @brief Verifies a signature with a public key stored in the device
*
* @param[in] idx             Storage index of public key
* @param[in] message         Signed message
* @param[in] messageLength   Length of the message
* @param[in] signature       Signature
* @param[in] signatureLength Length of the signature
* @param[out] is_verified    Signature verification result
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_verify_signature(PUBLIC_KEY_STORAGE_INDEX idx, const uint8_t *message, size_t messageLength, const uint8_t *signature, size_t signatureLength, bool *is_verified);

#if 0
/**
* @brief Store a TLS Credential private key and certificate on the device
*
* @param[in] idx             Credential storage index
* @param[in] flags           Operation flags
* @param[in] key             Key which needs to be stored
* @param[in] key_len         Size of the key
* @param[in] cert            Certificate which needs to be stored
* @param[in] cert_len        Size of the certificate
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_store_credential(CREDENTIAL_STORAGE_INDEX idx, uint32_t flags, const uint8_t *key, size_t key_len, uint8_t *cert, size_t cert_len);

/**
* @brief Read TLS Credential private key and certificate stored on the device
*
* @param[in] idx             Credential storage index
* @param[out] key             Key which is read from storage index
* @param[out] key_len         Size of the key
* @param[out] cert            Certificate which is read from storage index
* @param[out] cert_len        Size of the certificate
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_read_credential(CREDENTIAL_STORAGE_INDEX idx, uint8_t **key, size_t* key_len, uint8_t **cert, size_t* cert_len);

/**
* @brief Delete a TLS Credential private key and certificate stored in the device
*
* @param[in] idx             Credential storage index
* @param[in] flags           Operation flags
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_tpm_delete_credential(CREDENTIAL_STORAGE_INDEX idx, uint32_t flags);
#endif

/**
* @brief Read certificate, private key, and trusted certificate path for a SSL credential stored in the device
*
* @param[in]  credentialName    SSL Credential name
* @param[out] certPath          Path of certificate in PEM format
* @param[out] keyPath           Path of private Key in PEM format
* @param[out] CApath            Path of trusted certificates
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_cfg_get_credential(const char* credentialName, char** certPath, char** keyPath, char** CApath);

/**
* @brief Export status information in XSR format
*
* @param[in]  groups            Comma separated list of status groups
* @param[out] xsrPath           Path of exported status in XSR format
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_status_get(const char* groups, const char* xsrPath, const char* messagePath);

/**
* @brief Export configuration information in XCR format
*
* @param[in]  groups            Comma separated list of configuration groups
* @param[out] xcrPath           Path of exported configuration in XCR format
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_cfg_get(const char* groups, const char* xcrPath, const char* messagePath);

/**
* @brief Import configuration information in XCR format
*
* @param[in]  groups            Comma separated list of configuration groups
* @param[in]  xcrPath           Path of exported configuration in XCR format
* @param[out] messages          Import errors
* @return LTRX_SUCCESS on success, otherwise an error code
*/
LTRX_STATUS ltrx_cfg_set(const char* groups, const char* xcrPath, const char* messagePath);

#ifdef __cplusplus
}
#endif

#endif //__LTRX_SECURITY_API_H
