
#pragma once

int netman_if_getstatus(const int zeroBasedIndex,bool* link,bool* ip);

#define NM_PRN_DISC_FIFO_NAME           "/tmp/prnDiscFifo"
#define NM_LINK_NOTIFY_INIT             ' '
#define NM_LINK_NOTIFY_UP               'U'
#define NM_LINK_NOTIFY_DN               'D'
#define NM_LINK_NOTIFY_CFG              'C'
#define NM_WPS_STAT_FIFO_NAME           "/tmp/wpsStatFifo"
#define NM_WPS_STAT_INIT                ' '
#define NM_WPS_STAT_ACT                 'A'
#define NM_WPS_STAT_TIMEOUT             'T'
#define NM_WPS_STAT_FAIL                'F'
#define NM_WPS_STAT_CANCEL              'C'
#define NM_WPS_STAT_SUCCESS             'S'
#define NM_WPS_STAT_PROFILE             'P'
#define NM_WPS_PROFILE_FILE             "/tmp/ltrx_wps_profile"

#define NM_STR_WLAN_CONNECTED           "ESTABLISHED"
#define NM_STR_WLAN_DISCONNECTED        "DISCONNECTED"

#ifdef USE_NETWORK_FAILOVER
bool netman_failover_getstats(
    const int zeroBasedIndex,
    bool *state,
    time_t *timeOfLastChange,
    int *transitions,
    int *failoverInterface
);
bool netman_failover_clearstats(const int zeroBasedIndex);
bool netman_failover_getifpriority(const int zeroBasedIndex, int *priority);
bool netman_failover_IsHostReachable(
    const char *interfaceName,
    int method,
    const char *target,
    int timeout
);
#endif

#ifdef USE_CELLULAR
int netman_cellular_roaming_set(bool state);
int netman_cellular_roaming_get(bool *state);
int netman_cellular_roaming_reset(void);
#endif

#ifdef USE_WLAN_TRIGGERED_AP
#define NM_AP_TRIGGER_ERROR     -1
#define NM_AP_TRIGGER_OK        0
#define NM_AP_TRIGGER_NOT_CFG   1

int netman_soft_ap_trigger(void);
#endif

#ifdef USE_WLAN_SOFT_AP_CHANNEL_SETTING
int netman_soft_ap_channel_set(void);
#endif

#ifdef USE_WLAN_RADIO_BAND_SETTING
int netman_wlan_band_set(void);
#endif

#define NM_AP_INFO_DFS_SCAN_START       0x01
#define NM_AP_INFO_DFS_SCAN_END         0x02
#define NM_AP_INFO_AP_CHNL_MOVE         0x10
#ifdef USE_SOFT_AP
int netman_soft_ap_scan_inform(unsigned int info);
#endif
#ifdef USE_EAPOL
int netman_eapol_inform(unsigned int info);
#endif
