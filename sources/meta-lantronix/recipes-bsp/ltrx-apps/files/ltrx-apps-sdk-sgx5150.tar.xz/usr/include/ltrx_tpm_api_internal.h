/*
 * Copyright (C) 2018 Lantronix, Inc. All Rights Reserved.
 *
 * ltrx_tpm_api_internal.h
 * ltrx tpm API internal
 */

/**
* @file ltrx_tpm_api_internal.h
*/
#ifndef __LTRX_TPM_INTERNAL_H
#define __LTRX_TPM_INTERNAL_H

#include "ltrx_security_api.h"

#define SECURE_BOOT_LTRX_PUBLIC_KEY_SLOT         11
#define SECURE_BOOT_OEM_PUBLIC_KEY_SLOT          12

/*
* @brief Storage indices.
*
* storage indices.
*/
/**
* @brief TPM storage indices.
*
* TPM storage key indices.
*/
typedef enum ltrx_storage_index
{
    LTRX_STORAGE_1=0,   /**< Storage index 1. */
    LTRX_STORAGE_2,     /**< Storage index 2. */
    LTRX_STORAGE_3,     /**< Storage index 3. */
    LTRX_STORAGE_4,     /**< Storage index 4. */
    LTRX_STORAGE_5,     /**< Storage index 5. */
    LTRX_STORAGE_6,     /**< Storage index 6. */
    LTRX_STORAGE_7,     /**< Storage index 7. */
    LTRX_STORAGE_8,     /**< Storage index 8. */
    LTRX_STORAGE_9,     /**< Storage index 9. */
    LTRX_STORAGE_10,    /**< Storage index 10. */
    LTRX_STORAGE_11,    /**< Storage index 11. */
    LTRX_STORAGE_12,    /**< Storage index 12. */
    LTRX_STORAGE_13,    /**< Storage index 13. */
    LTRX_STORAGE_14,    /**< Storage index 14. */
    LTRX_STORAGE_15,    /**< Storage index 15. */
    LTRX_STORAGE_16,    /**< Storage index 16. */
}STORAGE_INDEX;

/**
* Clear TPM
*
* @param[in] flags         Operation flags
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_clear(uint32_t flags);

/**
* Check if storage index is locked
*
* @param[in] idx    storage index
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_is_locked(STORAGE_INDEX idx, bool *is_locked);

/**
* Lock/Unlock storage at index
*
* @param[in] idx    storage index
* @param[in] lock   lock state
* @param[in] is_locked    new lock state
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_lock(STORAGE_INDEX idx, bool lock, bool *is_locked);

/**
* Get TPM revision information.
*
* @param[out] revision  version information.
* @param[out] length    length of version information
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_info(uint8_t** revision, size_t* length);

/**
* Read TPM configuration
*
* @param[out] config_data configuration data
* @param[out] length    length of configuration data
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_read_config(uint8_t** config_data, size_t* length);

/**
* Write TPM configuration
*
* @param[in] config_data configuration data
* @param[in] length    length of configuration data
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_write_config(uint8_t* config_data, size_t length);

/**
* Check if TPM configuration is locked
*
* @param[out] is_locked     True: if configuration is locked, otherwise False
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_config_is_locked(bool *is_locked);

/**
* Lock/Unlock TPM configuration
*
* @param[in] lock   Lock state
* @param[out] is_locked New lock state
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_config_lock(bool lock, bool* is_locked);

/**
* Check if TPM data is locked
*
* @param[out] is_locked     True: if data is locked, otherwise False
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_data_is_locked(bool *is_locked);

/**
* Lock/Unlock TPM data
*
* @param[in] lock   Lock state
* @param[out] is_locked New lock state
* @return LTRX_SUCCESS on success, otherwise an error code.
*/
LTRX_STATUS ltrx_tpm_data_lock(bool lock, bool* is_locked);

#endif
