/* $Id: tlog.h,v 1.24 2011/03/17 19:58:44 eliska Exp $ */
#ifndef __TLOG_H__
#define __TLOG_H__

/*
** ----------------------------------------------------------------------------
**                                Includes
** ----------------------------------------------------------------------------
*/

#include "evolution_tlog.h"

#if 0
/*
** ----------------------------------------------------------------------------
**                                Structs
** ----------------------------------------------------------------------------
*/

struct tlog_data
{
    unsigned int visibleRecordNumber;
    uint16_t internalRecordNumber;
    enum tlog_facility facility;
    enum tlog_severity_level severity;
    const char *fileName;
    int lineNumber;
    char description[47];
    int year;
    int month;
    int date;
    int hours;
    int minutes;
    int seconds;
};

/*
** ----------------------------------------------------------------------------
**                                 Globals
** ----------------------------------------------------------------------------
*/
extern struct trigger *g_TLogTrigger;

/*
** ----------------------------------------------------------------------------
**                                Prototypes
** ----------------------------------------------------------------------------
*/


#define TLOG_DESTINATION_NONE       0x0
#define TLOG_DESTINATION_SYSLOG     0x1
#define TLOG_DESTINATION_FILE       0x2

void TLogInit(const char *programName);
void TLogSetLevel(int level);
void TLogSetDestination(uint32_t destinations);
void TLogOpenFile(const char *fname);
void TLogCloseFile(void);

void TlogLazyInit(void);

void TLogFormatOutput(
    char *outBuffer, size_t bufferSize, const struct tlog_data *td
);

bool TLogGetTlogData(
    struct tlog_data *td,
    uint32_t *internalRecordNumber
);
#endif

#endif
