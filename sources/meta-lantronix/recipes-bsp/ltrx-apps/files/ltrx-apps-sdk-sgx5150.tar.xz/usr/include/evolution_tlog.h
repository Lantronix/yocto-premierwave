/* $Id: evolution_tlog.h,v 1.17 2010/10/04 21:51:15 eliska Exp $ */
/*
** Copyright (C) 2008 By
** Lantronix, Inc.
** 15353 Barranca Pkwy
** Irvine, CA 92168
**
** This software is furnished under a license and may be used
** and copied only in accordance with the terms of such license
** and with the inclusion of the above copyright notice.
** This software or any other copies thereof may not be provided
** or otherwise made available to any other person.  No title to
** and ownership of the software is hereby transferred.
**
** The information in this software is subject to change without
** notice and should not be construed as a commitment by Lantronix,
** Inc.
*/
/*!
** \file
**
** \addtogroup tlog
**
** \brief Log developer and system messages.
** 
** TLog allows logging of developer and system messages.
** Messages logged with the TLog module are stored in a RAM based, 100 entry,
** sliding window (only the last 100 entries are stored).
** They are also used as syslog messages. See the TLOG() and syslog() macros.
**
** Each tlog entry can have a facility and severity (as in a syslog message).
** Two macros have been provided (TLOG() and syslog()) that fill in the source
** file name and line number. In the case of TLOG(), the severity is also set as
** Facility User (TLOG_FACILITY_USER).
**
** TLog entries can be viewed from the CLI by issuing a "show tlog" command from
** the device level (which is under the enable level). This will show the current
** tlog buffer. The command "auto show tlog" will update the display automatically
** until a key is pressed.
** 
** \par On using tlog as syslog.
** Syslog message are categorized by "facility" and "severity".
** Facilities are the "modules" that a message can come from. Each facility can
** have a message of a certain severity (as noted below).
**
** \par Facilities are defined as (from RFC3164):
**  \code
**  Name          Numeric Code     Description
**  -----------   ------------     -----------
**  LOG_KERNEL         0           kernel
**  LOG_USER           1           user-level
**  LOG_MAIL           2           mail
**  LOG_SYS_DEAMONS    3           system deamons
**  LOG_SECURITY       4           security/authorization (10 too)
**  LOG_SYSLOGD        5           internal syslogd
**  LOG_LPR            6           lpr
**  LOG_NET_NEWS       7           network news
**  LOG_UUCP           8           UUCP
**  LOG_CRON           9           clock deamon (15 too)
**  LOG_AUTHORIZATION  10          security/authorization (4 too)
**  LOG_FTP            11          FTP
**  LOG_NTP            12          NTP
**  LOG_LOG_AUDIT      13          log audit
**  LOG_LOG_ALERT      14          log alert
**  LOG_CRON2          15          clock deamon
**  LOG_LOCAL0         16          local use 0
**  LOG_LOCAL1         17          local use 1
**  LOG_LOCAL2         18          local use 2
**  LOG_LOCAL3         19          local use 3
**  LOG_LOCAL4         20          local use 4
**  LOG_LOCAL5         21          local use 5
**  LOG_LOCAL6         22          local use 6
**  LOG_LOCAL7         23          local use 7
**  \endcode
** @{  
*/
#ifndef __SDK_TLOG_H__
#define __SDK_TLOG_H__

#include "ltrx_log.h"

//#define TLOG_SEVERITY_NONE      LOG
#define TLOG_SEVERITY_EMERGENCY     LOG_EMERG
#define TLOG_SEVERITY_ALERT         LOG_ALERT
#define TLOG_SEVERITY_CRIT          LOG_CRIT
#define TLOG_SEVERITY_ERR           LOG_ERR
#define TLOG_SEVERITY_WARNING       LOG_WARNING
#define TLOG_SEVERITY_NOTICE        LOG_NOTICE
#define TLOG_SEVERITY_INFO          LOG_INFO
#define TLOG_SEVERITY_DEBUG         LOG_DEBUG

#define TLOG(__s, __f)   \
    logmsg(__FILE__, __LINE__, 0, LOG_USER, __s, __f)

#define VTLOG(__s, __f, __a...)   \
    logmsgf(__FILE__, __LINE__, 0, LOG_USER, __s, __f, ##__a)

void TLogWriteMessage(const char *pMessage, void *pOpaque);


#endif
/* @} End Doxygen of group. Don't write below this line */  
