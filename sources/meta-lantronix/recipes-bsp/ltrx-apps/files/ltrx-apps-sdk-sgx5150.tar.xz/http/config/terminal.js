function SetAdmin_TerminalDisplay(xml)
{
var menu=document.getElementById('terminal_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('terminal_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function UpdateTerminalDisplay()
{
var menu = GetDisplayValue("new_Terminal.Login_Connect_Menu");
document.getElementById("previewLoginConnectMenu_Display").style.display = (menu == "Enabled" ? "" : "none");
Update();
}
function SetTerminalDisplay(xml)
{
displayElementRootNames = new Array();
SetDisplaySelection('Terminal.Terminal_Type');
SetDisplaySelection('Terminal.Login_Connect_Menu');
SetDisplaySelection('Terminal.Exit_Connect_Menu');
SetDisplaySelection('Terminal.Send_Break');
SetDisplaySelection('Terminal.Break_Duration');
SetDisplaySelection('Terminal.Echo');
SetSubmit(false);
var d = document.getElementById("previewLoginConnectMenu");
if(d)
{
var r = "";
r += '<table class="basicTable" id="previewLoginConnectMenu_Display">';
r += '<tr>';
r += '<td><b>Preview of Login Connect Menu:</b></td>';
r += '</tr>';
r += '<tr>';
r += '<td><code><pre>';
r += GetXmlData(xml, 'previewLoginConnectMenu');
r += '</pre></code></td>';
r += '</tr>';
r += '</table>';
d.innerHTML = r;
}
UpdateTerminalDisplay();
document.getElementById("terminalform").style.display = "block";
}
function TerminalRender(xml)
{
var numSerialPorts = GetXmlData(xml, "numSerialPorts");
var port = GetXmlData(xml, 'port');
var serialPorts = document.getElementById('numSerialPorts').innerHTML;
document.getElementById("hiddenport").innerHTML = port;
document.getElementById("terminalline").innerHTML = "Terminal on " + (
Number(port) < 0 ? "Network" :
( (Number(port)<Number(serialPorts)) ? ("Line " + (Number(port) + 1)) : ("USB " + (Number(port) - Number(serialPorts) + 1)) )
);
if(port < 0)
{
document.getElementById("terminal_send_break_Display").style.display = "none";
document.getElementById("terminal_break_duration_Display").style.display = "none";
}
if(numSerialPorts > 4)
{
var d = document.getElementById("terminal_selection");
if(d)
{
var r = "";
r += '<table id="Nav1" class="table table-striped table-condensed">';
r += "<tr>";
if(numSerialPorts > 3)
{
r += "<td align='right'><b>Select Terminal on:</b></td>";
r += "<td align='left'>";
r += "<";
r += "select name='navSelect' class='form-control' style='width: 28%;' ";
r += "id='navSelect' ";
r += "onchange=\" ";
r += "var page = document.getElementById('hiddencurrentterminalpage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'portnumber='+this.value]);";
r += " \" ";
r += ">";
for(var i = -1; i < numSerialPorts; ++i)
{
var sel = (port == i) ? " selected " : "";
r += "<option value='" + i + "' " + sel + ">";
if(i < 0)
{
r += "Network";
}
else
{
r += "Line " + (i + 1);
}
r += "</option>";
}
r += "</select>";
r += "</td>";
}
else
{
for(var i = 0; i <= numSerialPorts; ++i)
{
r += "<td id='terminalnav" + i + "'>";
r += "<a ";
r += "href='javascript:void(0)'";
r += "onclick=\"";
r += "var page = document.getElementById('hiddencurrentterminalpage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'portnumber=" + (i-1) + "']);";
r += "\"";
r += ">";
r += i > 0 ? "Line " + i : "Network";
r += "</a>";
r += "</td>";
}
}
r += "</tr>";
r += "</table>";
d.innerHTML = r;
HighlightElementInTable("Nav1", "terminalnav" + (Number(port)+1));
}
}
}
