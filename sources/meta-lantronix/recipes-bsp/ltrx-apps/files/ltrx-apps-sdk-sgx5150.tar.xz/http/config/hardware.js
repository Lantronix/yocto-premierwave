function SetHardwareLinks()
{
document.getElementById('cpuspeedD').style.display =
(document.getElementById('cpuspeed').innerHTML == '120.0 MHz') ? 'none' : 'inline';
}
function SetHardwareDisplay()
{
GetMessageDisplay('diag_hardware',"hw",11);
GetMessageDisplay('diag_hw_current_config',"strings",40);
GetMessageDisplay('diag_hw_cpu_type',"strings",52);
GetMessageDisplay('diag_hw_cpu_speed',"strings",60);
GetMessageDisplay('diag_hw_ram_size',"hw",6);
GetMessageDisplay('diag_hw_flash_size',"hw",7);
}
