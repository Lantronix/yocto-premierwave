function replaceStringOnce(mainStr, searchStr, replaceStr)
{
var foundOffset = mainStr.indexOf(searchStr);
if(foundOffset == -1)
{
return mainStr;
}
else
{
var front = mainStr.substring(0,foundOffset);
var back = mainStr.substring(foundOffset+searchStr.length,mainStr.length);
return front + replaceStr + back;
}
}
function LocalizeGroupName(localizedGroup)
{
if(localizedGroup.indexOf("user management")==0)localizedGroup=replaceStringOnce(localizedGroup,"user management",GetMessage("usermgmt", 4));
else if(localizedGroup.indexOf("cli")==0)localizedGroup=replaceStringOnce(localizedGroup,"cli","CLI");
else if(localizedGroup.indexOf("ssh")==0)localizedGroup=replaceStringOnce(localizedGroup,"ssh","SSH");
else if(localizedGroup.indexOf("telnet")==0)localizedGroup=replaceStringOnce(localizedGroup,"telnet","Telnet");
else if(localizedGroup.indexOf("arp")==0)localizedGroup=replaceStringOnce(localizedGroup,"arp","ARP");
else if(localizedGroup.indexOf("icmp")==0)localizedGroup=replaceStringOnce(localizedGroup,"icmp","ICMP");
else if(localizedGroup.indexOf("ip")==0)localizedGroup=replaceStringOnce(localizedGroup,"ip","IP");
else if(localizedGroup.indexOf("tcp")==0)localizedGroup=replaceStringOnce(localizedGroup,"tcp","TCP");
else if(localizedGroup.indexOf("udp")==0)localizedGroup=replaceStringOnce(localizedGroup,"udp","UDP");
else if(localizedGroup.indexOf("rss")==0)localizedGroup=replaceStringOnce(localizedGroup,"rss","RSS");
else if(localizedGroup.indexOf("percepxion line")==0)localizedGroup=replaceStringOnce(localizedGroup,"percepxion line","percepxion Line");
else if(localizedGroup.indexOf("percepxion")==0)localizedGroup=replaceStringOnce(localizedGroup,"percepxion","percepxion");
else if(localizedGroup.indexOf("email")==0)localizedGroup=replaceStringOnce(localizedGroup,"email","Email");
else if(localizedGroup.indexOf("applications")==0)localizedGroup=replaceStringOnce(localizedGroup,"applications","Applications");
else if(localizedGroup.indexOf("gateway")==0)localizedGroup=replaceStringOnce(localizedGroup,"gateway","Gateway");
else if(localizedGroup.indexOf("dhcp server")==0)localizedGroup=replaceStringOnce(localizedGroup,"dhcp server","DHCP Server");
else if(localizedGroup.indexOf("virtual ip")==0)localizedGroup=replaceStringOnce(localizedGroup,"virtual ip","Virtual IP");
else if(localizedGroup.indexOf("routing protocols")==0)localizedGroup=replaceStringOnce(localizedGroup,"routing protocols","Routing Protocols");
else if(localizedGroup.indexOf("gre")==0)localizedGroup=replaceStringOnce(localizedGroup,"gre","GRE");
else if(localizedGroup.indexOf("terminal")==0)localizedGroup=replaceStringOnce(localizedGroup,"terminal","Terminal");
else if(localizedGroup.indexOf("usb line")==0)localizedGroup=replaceStringOnce(localizedGroup,"usb line","USB Line");
else if(localizedGroup.indexOf("line")==0)localizedGroup=replaceStringOnce(localizedGroup,"line","Line");
else if(localizedGroup.indexOf("serial command mode")==0)localizedGroup=replaceStringOnce(localizedGroup,"serial command mode","Serial Command Mode");
else if(localizedGroup.indexOf("sessions")==0)localizedGroup=replaceStringOnce(localizedGroup,"sessions","Sessions");
else if(localizedGroup.indexOf("tunnel accept")==0)localizedGroup=replaceStringOnce(localizedGroup,"tunnel accept","Tunnel Accept");
else if(localizedGroup.indexOf("tunnel serial")==0)localizedGroup=replaceStringOnce(localizedGroup,"tunnel serial","Tunnel Serial");
else if(localizedGroup.indexOf("tunnel connect")==0)localizedGroup=replaceStringOnce(localizedGroup,"tunnel connect","Tunnel Connect");
else if(localizedGroup.indexOf("tunnel disconnect")==0)localizedGroup=replaceStringOnce(localizedGroup,"tunnel disconnect","Tunnel Disconnect");
else if(localizedGroup.indexOf("tunnel packing")==0)localizedGroup=replaceStringOnce(localizedGroup,"tunnel packing","Tunnel Packing");
else if(localizedGroup.indexOf("tunnel modem")==0)localizedGroup=replaceStringOnce(localizedGroup,"tunnel modem","Tunnel Modem");
else if(localizedGroup.indexOf("tunnel")==0)localizedGroup=replaceStringOnce(localizedGroup,"tunnel","Tunnel");
else if(localizedGroup.indexOf("diagnostics")==0)localizedGroup=replaceStringOnce(localizedGroup,"diagnostics","Diagnostics");
else if(localizedGroup.indexOf("hardware")==0)localizedGroup=replaceStringOnce(localizedGroup,"hardware","Hardware");
else if(localizedGroup.indexOf("memory")==0)localizedGroup=replaceStringOnce(localizedGroup,"memory","Memory");
else if(localizedGroup.indexOf("processes")==0)localizedGroup=replaceStringOnce(localizedGroup,"processes","Processes");
else if(localizedGroup.indexOf("IP sockets")==0)localizedGroup=replaceStringOnce(localizedGroup,"IP sockets","IP Sockets");
else if(localizedGroup.indexOf("filesystem")==0)localizedGroup=replaceStringOnce(localizedGroup,"filesystem","Filesystem");
else if(localizedGroup.indexOf("input filters")==0)localizedGroup=replaceStringOnce(localizedGroup,"input filters","Input Filters");
else if(localizedGroup.indexOf("reboot schedule")==0)localizedGroup=replaceStringOnce(localizedGroup,"reboot schedule","Reboot Schedule");
else if(localizedGroup.indexOf("ftp server")==0)localizedGroup=replaceStringOnce(localizedGroup,"ftp server","FTP Server");
else if(localizedGroup.indexOf("smart roam")==0)localizedGroup=replaceStringOnce(localizedGroup,"smart roam","Smart Roam");
else if(localizedGroup.indexOf("access point")==0)localizedGroup=replaceStringOnce(localizedGroup,"access point",GetMessage("softap", 0));
else if(localizedGroup.indexOf("action")==0)localizedGroup=replaceStringOnce(localizedGroup,"action","Action");
else if(localizedGroup.indexOf("bridge")==0)localizedGroup=replaceStringOnce(localizedGroup,"bridge",GetMessage("net", 121));
else if(localizedGroup.indexOf("bluetooth line")==0)localizedGroup=replaceStringOnce(localizedGroup,"bluetooth line","Bluetooth Line");
else if(localizedGroup.indexOf("bluetooth")==0)localizedGroup=replaceStringOnce(localizedGroup,"bluetooth",GetMessage("bluetooth", 0));
else if(localizedGroup.indexOf("clock")==0)localizedGroup=replaceStringOnce(localizedGroup,"clock",GetMessage("rtc", 40));
else if(localizedGroup.indexOf("security")==0)localizedGroup=replaceStringOnce(localizedGroup,"security","Security");
else if(localizedGroup.indexOf("sftp server")==0)localizedGroup=replaceStringOnce(localizedGroup,"sftp server","SFTP Server");
else if(localizedGroup.indexOf("discovery")==0)localizedGroup=replaceStringOnce(localizedGroup,"discovery",GetMessage("discovery", 16));
else if(localizedGroup.indexOf("query port")==0)localizedGroup=replaceStringOnce(localizedGroup,"query port","Query Port");
else if(localizedGroup.indexOf("upnp")==0)localizedGroup=replaceStringOnce(localizedGroup,"upnp","UPnP");
else if(localizedGroup.indexOf("ethernet:")==0)localizedGroup=replaceStringOnce(localizedGroup,"ethernet",GetMessage("net", 276));
else if(localizedGroup.indexOf("ethernet")==0)localizedGroup=replaceStringOnce(localizedGroup,"ethernet",GetMessage("net", 276));
else if(localizedGroup.indexOf("execute")==0)localizedGroup=replaceStringOnce(localizedGroup,"execute",GetMessage("strings", 173));
else if(localizedGroup.indexOf("exit cli")==0)localizedGroup=replaceStringOnce(localizedGroup,"exit cli",GetMessage("strings", 174));
else if(localizedGroup.indexOf("wlan:")==0)localizedGroup=replaceStringOnce(localizedGroup,"wlan",GetMessage("net", 265));
else if(localizedGroup.indexOf("wlan scan")==0)localizedGroup=replaceStringOnce(localizedGroup,"wlan scan",GetMessage("net", 265)+" "+GetMessage("net", 231));
else if(localizedGroup.indexOf("wlan status")==0)localizedGroup=replaceStringOnce(localizedGroup,"wlan status",GetMessage("net", 265)+" "+GetMessage("strings", 0));
else if(localizedGroup.indexOf("wlan profile")==0)localizedGroup=replaceStringOnce(localizedGroup,"wlan profile",GetMessage("net", 150));
else if(localizedGroup.indexOf("wlan")==0)localizedGroup=replaceStringOnce(localizedGroup,"wlan",GetMessage("net", 265));
else if(localizedGroup.indexOf("network failover:")==0)localizedGroup=replaceStringOnce(localizedGroup,"network failover","Network Failover");
else if(localizedGroup.indexOf("network failover")==0)localizedGroup=replaceStringOnce(localizedGroup,"network failover","Network Failover");
else if(localizedGroup.indexOf("failover")==0)localizedGroup=replaceStringOnce(localizedGroup,"failover","Failover");
else if(localizedGroup.indexOf("network")==0)localizedGroup=replaceStringOnce(localizedGroup,"network","Network");
else if(localizedGroup.indexOf("qos")==0)localizedGroup=replaceStringOnce(localizedGroup,"qos","QoS");
else if(localizedGroup.indexOf("http authentication uri")==0)localizedGroup=replaceStringOnce(localizedGroup,"http authentication uri",GetMessage("http", 111));
else if(localizedGroup.indexOf("http server")==0)localizedGroup="HTTP";
else if(localizedGroup=="http")localizedGroup="HTTP";
else if(localizedGroup.indexOf("http log")==0)localizedGroup=replaceStringOnce(localizedGroup,"http log","HTTP "+GetMessage("http", 109));
else if(localizedGroup.indexOf("interface:")==0)localizedGroup=replaceStringOnce(localizedGroup,"interface",GetMessage("strings", 54));
else if(localizedGroup.indexOf("interface")==0)localizedGroup=replaceStringOnce(localizedGroup,"interface",GetMessage("strings", 54));
else if(localizedGroup.indexOf("ssh server")==0)localizedGroup=replaceStringOnce(localizedGroup,"ssh server",GetMessage("sshserver", 38));
else if(localizedGroup.indexOf("ssh client")==0)localizedGroup=replaceStringOnce(localizedGroup,"ssh client",GetMessage("sshclient", 42));
else if(localizedGroup.indexOf("ssl")==0)localizedGroup="SSL";
else if(localizedGroup.indexOf("syslog")==0)localizedGroup=replaceStringOnce(localizedGroup,"syslog",GetMessage("syslog", 14));
else if(localizedGroup.indexOf("modbus local slave")==0)localizedGroup=replaceStringOnce(localizedGroup,"modbus local slave",GetMessage("modbus", 5));
else if(localizedGroup.indexOf("modbus tcp server:permanent")==0)localizedGroup=replaceStringOnce(localizedGroup,"modbus tcp server:permanent",GetMessage("modbus", 3));
else if(localizedGroup.indexOf("modbus tcp server:additional")==0)localizedGroup=replaceStringOnce(localizedGroup,"modbus tcp server:additional",GetMessage("modbus", 4));
else if(localizedGroup.indexOf("modbus")==0)localizedGroup=replaceStringOnce(localizedGroup,"modbus",GetMessage("modbus", 2));
else if(localizedGroup.indexOf("cp functions")==0)localizedGroup="CP Functions";
else if(localizedGroup.indexOf("snmp")==0)localizedGroup="SNMP";
else if(localizedGroup.indexOf("vpn")==0)localizedGroup="VPN";
else if(localizedGroup.indexOf("host")==0)localizedGroup=replaceStringOnce(localizedGroup,"host","Host");
else if(localizedGroup.indexOf("smtp")==0)localizedGroup="SMTP";
else if(localizedGroup.indexOf("xml import control")==0)localizedGroup="XML";
else if(localizedGroup.indexOf("xsr")==0)localizedGroup="XSR";
else if(localizedGroup.indexOf("device")==0)localizedGroup=replaceStringOnce(localizedGroup,"device",GetMessage("status", 1));
return localizedGroup;
}
function OpenInNewTab(url)
{
var win = window.open(url,"_blank");
win.focus();
}
function showHelp()
{
if(document.getElementById('documentData').innerHTML!='')
{
var title="";
title += "Lantronix Web Manager - Help";
text = document.getElementById('documentData').innerHTML
bootbox.alert({ title: title, size: "large", message: '<div style="height:480px; max-height:480px; overflow: auto">'+text+"</div>" });
}
}
function Logoff()
{
var r=ajax.getRequestObject();
r.open('POST', '/logout', false,'<user name>','<password>');
r.send('');
document.body.innerHTML="<center>"+GetMessage("logout",2)+"</center><br/><center>"+GetMessage("logout",3)+" <b><a href='/'>"+GetMessage("logout",4)+" </a></b>"+GetMessage("logout",5)+"</center>";
}
function clearFormUpdates(formId,submitButtonId,cancelButtonId,applyButtonId)
{
if(formId!=null)
{
var objForm = document.getElementById(formId);
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
var name = formElements[i].name;
if (name)
{
if (formElements[i].type == 'submit')
{
continue;
}
if (formElements[i].name == 'iehack')
{
continue;
}
if (formElements[i].type == 'checkbox' || formElements[i].type == 'radio')
{
var oldState=formElements[i].getAttribute('org_state');
formElements[i].checked=((oldState=='true')?true:false);
}
if (formElements[i].type == 'text')
{
formElements[i].value=formElements[i].getAttribute('org_value');
}
if (formElements[i].type == 'select-one')
{
for(var opt=0;opt<formElements[i].options.length;opt++)
{
if(formElements[i].options[opt].text==formElements[i].getAttribute('org_value'))
{
formElements[i].selectedIndex=opt;
break;
}
}
}
}
}
}
}
var d = document.getElementById('results');
if(d)
{
d.innerHTML="";
d.style.display = 'none';
}
updateButtonVisibilities(formId,submitButtonId,cancelButtonId,applyButtonId);
return;
}
function submitFormUpdates(formId,submitButtonId,cancelButtonId,applyButtonId)
{
if(formId!=null)
{
var objForm = document.getElementById(formId);
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
var name = formElements[i].name;
if (name)
{
if (formElements[i].type == 'submit')
{
continue;
}
if (formElements[i].name == 'iehack')
{
continue;
}
if (formElements[i].type == 'checkbox' || formElements[i].type == 'radio')
{
var newState=((formElements[i].checked)?'true':'false');
formElements[i].setAttribute('org_state',newState);
}
if (formElements[i].type == 'text')
{
formElements[i].setAttribute('org_value',formElements[i].value);
}
if (formElements[i].type == 'select-one' && formElements[i].options.length)
{
formElements[i].setAttribute('org_value',formElements[i].options[formElements[i].selectedIndex].text);
}
}
}
}
}
updateButtonVisibilities(formId,submitButtonId,cancelButtonId,applyButtonId);
return;
}
function getFormElementById(formId,elementId)
{
if(formId!=null)
{
var objForm = document.getElementById(formId);
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
if(formElements[i].id==elementId)return formElements[i];
}
}
}
return null;
}
function updateButtonVisibilities(formId,submitButtonId,cancelButtonId,applyButtonId)
{
var bApplyButtonVisible=false;
var bSubmitButtonVisible=false;
var bCancelButtonVisible=false;
if(formId!=null)
{
var objForm = document.getElementById(formId);
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
var name = formElements[i].name;
if (name)
{
if (formElements[i].type == 'submit')
{
continue;
}
if (formElements[i].name == 'iehack')
{
continue;
}
if (formElements[i].type == 'checkbox' || formElements[i].type == 'radio')
{
var oldState=formElements[i].getAttribute('org_state');
var newState=formElements[i].checked;
if(newState.toString()!=oldState)
{
bApplyButtonVisible=true;
bSubmitButtonVisible=true;
bCancelButtonVisible=true;
break;
}
}
if (formElements[i].type == 'text' || formElements[i].type == 'password')
{
if(formElements[i].getAttribute('org_value')!=formElements[i].value)
{
bApplyButtonVisible=true;
bSubmitButtonVisible=true;
bCancelButtonVisible=true;
break;
}
}
if (formElements[i].type == 'select-one' && formElements[i].options.length)
{
if(formElements[i].getAttribute('org_value')!=formElements[i].options[formElements[i].selectedIndex].text)
{
bApplyButtonVisible=true;
bSubmitButtonVisible=true;
bCancelButtonVisible=true;
break;
}
}
}
}
var submitButton=getFormElementById(formId,submitButtonId);
if(submitButton)
{
submitButton.disabled=false;
submitButton.style.visibility=bSubmitButtonVisible?"visible":"hidden";
submitButton.style.display=bSubmitButtonVisible?"":"none";
}
var cancelButton=getFormElementById(formId,cancelButtonId);
if(cancelButton)
{
cancelButton.disabled=false;
cancelButton.style.visibility=bCancelButtonVisible?"visible":"hidden";
cancelButton.style.display=bSubmitButtonVisible?"":"none";
}
var applyButton=getFormElementById(formId,applyButtonId);
if(applyButton)
{
applyButton.disabled=false;
applyButton.style.visibility=bApplyButtonVisible?"visible":"hidden";
applyButton.style.display=bSubmitButtonVisible?"":"none";
}
}
}
}
function GetRealTextNode(node)
{
if(node.hasChildNodes() && node.firstChild.nodeType != 3)
{
return node.firstChild;
}
else if(node.hasChildNodes() && node.childNodes[1].nodeType == 1)
{
return node.childNodes[1];
}
else if(node.hasChildNodes() && node.firstChild.nodeType == 1)
{
return node.firstChild;
}
return null;
}
function GetHiddenFrameOutput(hframe)
{
var i;
var j;
var target;
var data;
var nodes = window.frames[hframe].document.getElementsByTagName('xml');
for(i = 0; i < nodes.length; ++i)
{
var node = GetRealTextNode(nodes[i]);
if(node)
{
target = null;
data = null;
for(j = 0; j < node.childNodes.length ; ++j)
{
if(
node.childNodes[j].nodeName.toLowerCase() == "target" &&
node.childNodes[j].firstChild
)
{
target = node.childNodes[j].firstChild.nodeValue;
}
else if(node.childNodes[j].nodeName.toLowerCase() == "data")
{
data = node.childNodes[j];
}
}
if(target && data)
{
eval(target + "(data);");
}
}
}
}
confirmPostProcedure = "";
function PrintMsg(xml, id)
{
var d = document.getElementById(id);
if(d)
{
d.style.visibility='hidden';
var isStr = true;
if(xml.firstChild)
{
isStr = false;
}
if(
(xml.nodeType == 1 && ! xml.firstChild) ||
(isStr && xml.length == 0) ||
(
! isStr &&
(! xml.firstChild || xml.firstChild.nodeValue == '')
)
)
{
d.innerHTML = '';
d.style.display = 'none';
}
else
{
var r = '';
if(
(isStr && xml == 'br') ||
(! isStr && xml.firstChild.nodeValue == 'br')
)
{
r += "<br>";
}
else
{
var msg = isStr ? xml : xml.firstChild.nodeValue;
if(msg.match(/^CONFIRM:/))
{
var confirmMessage = msg.replace("CONFIRM:", GetMessage("strings",135)+":");
r += "<b>";
r += "<div class='alert alert-danger' role='alert'>";
r += confirmMessage;
r += " <a class=\"btn btn-primary btn-sm\"";
r += 'href="javascript:void(0)"';
r += 'onclick="';
r += "var confirms = GetDisplayValue('confirms');";
r += "SetDisplayValue('confirms', '' + confirms + '" + msg + "');";
r += confirmPostProcedure;
r += "return false;";
r += '"';
r += ">"+GetMessage('strings',31)+"</a>";
r += " <a class=\"btn btn-primary btn-sm\"";
r += 'href="javascript:void(0)"';
r += 'onclick="';
r += "var curData = ajaxHistory.getCurrentData();";
r += "var curPage = ajaxHistory.getCurrentLocation();";
r += "return ajax_AddToHistory(curPage, curData);";
r += '"';
r += ">"+GetMessage('strings',8)+"</a>";
r += "</div>";
r += "</b>";
}
else
{
if(msg.match(/^ERROR:/))
{
msg = msg.replace("ERROR:", "<strong>"+GetMessage("strings",48)+":</strong>");
var prior_errors=document.getElementById("trresult_errors");
var errors='';
if(prior_errors)
{
errors+=prior_errors.innerHTML;
errors += "<br>";
}
errors += msg;
r += "<div class='alert alert-danger alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                <span class=\"sr-only\">Close</span>                              </button>";
r += "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>";
r += "<div id='trresult_errors'>" + errors + "</div></div>";
var prior_warnings=document.getElementById("trresult_warnings");
var warnings='';
if(prior_warnings)
{
warnings+=prior_warnings.innerHTML;
}
if(warnings!='')
{
r += "<div class='alert alert-warning alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                    <span class=\"sr-only\">Close</span>                                  </button>";
r += "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>";
r += "<div id='trresult_warnings'>" + warnings + "</div></div>";
}
var prior_infos=document.getElementById("trresult_infos");
var infos='';
if(prior_infos)
{
infos+=prior_infos.innerHTML;
}
if(infos!='')
{
r += "<div class='alert alert-success alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                    <span class=\"sr-only\">Close</span>                                  </button>";
r += "<span class='glyphicon glyphicon-ok-sign' aria-hidden='true'></span>";
r += "<div id='trresult_infos'>" + infos + "</div></div>";
}
}
else if(msg.match(/^WARNING:/))
{
var prior_errors=document.getElementById("trresult_errors");
var errors='';
if(prior_errors)
{
errors+=prior_errors.innerHTML;
}
if(errors!='')
{
r += "<div class='alert alert-danger alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                    <span class=\"sr-only\">Close</span>                                  </button>";
r += "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>";
r += "<div id='trresult_errors'>" + errors + "</div></div>";
}
var prior_warnings=document.getElementById("trresult_warnings");
var warnings='';
if(prior_warnings)
{
warnings+=prior_warnings.innerHTML;
warnings+= "<br>";
}
msg = msg.replace("WARNING:", "<strong>"+GetMessage("strings",49)+":</strong>");
warnings += msg;
r += "<div class='alert alert-warning alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                <span class=\"sr-only\">Close</span>                              </button>";
r += "<span class='glyphicon glyphicon-question-sign' aria-hidden='true'></span>";
r += "<div id='trresult_warnings'>" + warnings + "</div></div>";
var prior_infos=document.getElementById("trresult_infos");
var infos='';
if(prior_infos)
{
infos+=prior_infos.innerHTML;
}
if(infos!='')
{
r += "<div class='alert alert-success alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                    <span class=\"sr-only\">Close</span>                                  </button>";
r += "<span class='glyphicon glyphicon-ok-sign' aria-hidden='true'></span>";
r += "<div id='trresult_infos'>" + infos + "</div></div>";
}
}
else
{
var prior_errors=document.getElementById("trresult_errors");
var errors='';
if(prior_errors)
{
errors+=prior_errors.innerHTML;
}
if(errors!='')
{
r += "<div class='alert alert-danger alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                    <span class=\"sr-only\">Close</span>                                  </button>";
r += "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>";
r += "<div id='trresult_errors'>" + errors + "</div></div>";
}
var prior_warnings=document.getElementById("trresult_warnings");
var warnings='';
if(prior_warnings)
{
warnings+=prior_warnings.innerHTML;
}
if(warnings!='')
{
r += "<div class='alert alert-warning alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                    <span class=\"sr-only\">Close</span>                                  </button>";
r += "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>";
r += "<div id='trresult_warnings'>" + warnings + "</div></div>";
}
var prior_infos=document.getElementById("trresult_infos");
var infos='';
if(prior_infos)
{
infos+=prior_infos.innerHTML;
infos+= "<br>";
}
msg = msg.replace("NOTE:", "<strong>"+GetMessage("strings",132)+":</strong>");
msg = msg.replace("INFO:", "<strong>"+GetMessage("strings",134)+":</strong>");
infos += msg;
r += "<div class='alert alert-success alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                                <span class=\"sr-only\">Close</span>                              </button>";
r += "<span class='glyphicon glyphicon-ok-sign' aria-hidden='true'></span>";
r += "<div id='trresult_infos'>" + infos + "</div></div>";
}
}
}
d.innerHTML = r;
d.style.display = 'block';
}
d.style.visibility='visible';
}
}
function PrintPostResults(xml)
{
PrintMsg(xml, 'results');
}
function GetXmlDataByZeroBasedIndex(node, tag, z)
{
var e = node.getElementsByTagName(tag);
if(e.length <= z)
{
return null;
}
else if(e[z].firstChild == null)
{
return "";
}
return e[z].firstChild.nodeValue;
}
function GetXmlData(node, tag)
{
return GetXmlDataByZeroBasedIndex(node, tag, 0);
}
function GetXmlBool(node, tag)
{
var d = GetXmlData(node, tag);
return (d && d == "1");
}
function XMLToString(oXML)
{
if(oXML==null)return "";
if (window.ActiveXObject)
{
return oXML.xml;
}
else
{
return (new XMLSerializer()).serializeToString(oXML);
}
}
function GetMsgAndDisplay(xml)
{
if(! xml || ! xml.hasChildNodes())
{
alert("ERROR: Unable to display message.");
}
else
{
var f = GetXmlData(xml, "f");
var c = GetXmlData(xml, "c");
var i = GetXmlData(xml, "i");
var msg=GetMessage(c,i);
eval(f + "(msg);");
}
}
function GetMessageDisplay(elementId, listName, listIndex, args)
{
var e = document.getElementById(elementId);
if(e)
{
e.innerHTML = GetMessage(listName, listIndex, args);
}
}
function GetConfirmationMessage(c,i,args)
{
var msg=GetMessage(c,i,args);
msg = msg.replace("CONFIRM:", GetMessage("strings",135)+":");
msg = msg.replace("ERROR:", GetMessage("strings",48)+":");
msg = msg.replace("WARNING:", GetMessage("strings",49)+":");
msg = msg.replace("NOTE:", GetMessage("strings",132)+":");
msg = msg.replace("INFO:", GetMessage("strings",134)+":");
return msg;
}
var translationDataError=false;
var translationErrorTime=null;
function GetMessage(c,i,args)
{
if(_msgs && _msgs[c] && _msgs[c][i])
{
var msg = _msgs[c][i];
var finalMsg = msg.slice(0);
if(args)
{
for(var i = 0; i < args.length; i++)
{
finalMsg = decodeURIComponent(finalMsg);
finalMsg = finalMsg.replace(
/\{\}/,
args[i]? args[i] : ""
);
}
}
return finalMsg;
}
if(!translationDataError)
{
translationDataError=true;
alert("Please wait while translation data ('"+c+":"+i+"') is loaded. The page will automatically refresh in 5 seconds.");
clearTimeout(translationErrorTime);
translationErrorTime=setTimeout(function(){ translationDataError=false; window.location.href='/';},5000);
}
return "";
}
function GetMsgAndDisplayPrintf(xml)
{
if(! xml || ! xml.hasChildNodes())
{
alert("ERROR: Unable to display message.");
}
else
{
var f = GetXmlData(xml, "f");
var c = GetXmlData(xml, "c");
var i = GetXmlData(xml, "i");
var args = xml.getElementsByTagName('arg');
var finalMsg = GetMessage(c,i);
for(var i = 0; i < args.length; i++)
{
finalMsg = decodeURIComponent(finalMsg);
finalMsg = finalMsg.replace(
/\{\}/,
args[i].firstChild ? args[i].firstChild.nodeValue : ""
);
}
eval(f + "(finalMsg);");
}
}
function Localize_DiagnosticsTab()
{
document.getElementById('diag_tab_dns').innerHTML=GetMessage("dns",14);
document.getElementById('diag_tab_ping').innerHTML=GetMessage("ping",17);
document.getElementById('diag_tab_routes').innerHTML=GetMessage("routes",7);
document.getElementById('diag_tab_traceroute').innerHTML=GetMessage("tr",8);
}
function Initialize(xml)
{
if(xml && xml.hasChildNodes())
{
var numSerialPorts = GetXmlData(xml, "numSerialPorts");
document.getElementById("numSerialPorts").innerHTML = numSerialPorts;
var numUSBPorts = GetXmlData(xml, "numUSBPorts");
document.getElementById("numUSBPorts").innerHTML = numUSBPorts;
var numBluetoothPorts = GetXmlData(xml, "numBluetoothPorts");
document.getElementById("numBluetoothPorts").innerHTML = numBluetoothPorts;
var numTunnels = GetXmlData(xml, "numTunnels");
document.getElementById("numTunnels").innerHTML = numTunnels;
}
}
function Localize_AdminTab(xml)
{
document.getElementById('admin_tab_applications').innerHTML=GetMessage("strings",170);
document.getElementById('admin_tab_cli_statistics').innerHTML=GetMessage("strings",36);
document.getElementById('admin_tab_cli_configuration').innerHTML=GetMessage("strings",37);
document.getElementById('admin_tab_clock').innerHTML=GetMessage("rtc",40);
document.getElementById('admin_tab_discovery').innerHTML=GetMessage("discovery",16);
document.getElementById('admin_tab_http_statistics').innerHTML=GetMessage("strings",36);
document.getElementById('admin_tab_http_configuration').innerHTML=GetMessage("strings",37);
document.getElementById('admin_tab_http_authentication').innerHTML=GetMessage("strings",56);
document.getElementById('admin_tab_ssl_credentials').innerHTML=GetMessage("strings",43);
document.getElementById('admin_tab_ssl_trustedauthorities').innerHTML=GetMessage("strings",57);
document.getElementById('admin_tab_ssl_csr').innerHTML=GetMessage("ssl",147);
document.getElementById('admin_tab_syslog').innerHTML=GetMessage("syslog",14);
document.getElementById('admin_tab_system').innerHTML=GetMessage("system",16);
document.getElementById('admin_tab_usermanagement').innerHTML=GetMessage("usermgmt",4);
document.getElementById('admin_tab_xml').innerHTML=GetMessage("xml",36);
document.getElementById('admin_tab_xml_exportconfiguration').innerHTML=GetMessage("xml",37);
document.getElementById('admin_tab_xml_exportstatus').innerHTML=GetMessage("xml",38);
document.getElementById('admin_tab_xml_importconfiguration').innerHTML=GetMessage("xml",39);
document.getElementById('admin_tab_quicksetup').innerHTML=GetMessage("qsetup",1);
var numSerialPorts = document.getElementById("numSerialPorts").innerHTML;
var numUSBPorts = document.getElementById("numUSBPorts").innerHTML;
var numBluetoothPorts = document.getElementById("numBluetoothPorts").innerHTML;
var numTunnels = document.getElementById("numTunnels").innerHTML;
var numLineTerminals=parseInt(numSerialPorts)+parseInt(numUSBPorts);
if(numSerialPorts==0)
{
SetFxDisplay("line_Index",'none');
SetFxDisplay("modbus_Index",'none');
SetFxDisplay('mach10_line1_Index','none');
SetFxDisplay('mach10_line2_Index','none');
SetFxDisplay('mach10_line3_Index','none');
}
SetFxDisplay("line1_Index",numSerialPorts>0?"":"none");
SetFxDisplay("mach10_line1_Index",numSerialPorts>0?"":"none");
SetFxDisplay("line2_Index",numSerialPorts>1?"":"none");
SetFxDisplay("mach10_line2_Index",numSerialPorts>0?"":"none");
if(numUSBPorts==0)
{
SetFxDisplay("usb_Index",'none');
SetFxDisplay('mach10_usb1_Index','none');
}
SetFxDisplay("usb1_Index",numUSBPorts>0?"":"none");
SetFxDisplay("mach10_usb1_Index",numUSBPorts>0?"":"none");
if(numBluetoothPorts==0)
{
SetFxDisplay("bluetoothSerial_Index",'none');
SetFxDisplay('mach10_bluetoothSerial1_Index','none');
}
SetFxDisplay("bluetoothSerial1_Index",numBluetoothPorts>0?"":"none");
SetFxDisplay("mach10_bluetoothSerial1_Index",numBluetoothPorts>0?"":"none");
if(numTunnels==0)
{
SetFxDisplay("tunnel_Index",'none');
}
SetFxDisplay("tunnel1_Index",numTunnels>0?"":"none");
SetFxDisplay("tunnel2_Index",numTunnels>1?"":"none");
SetFxDisplay("tunnel3_Index",numTunnels>2?"":"none");
SetFxDisplay("tunnel4_Index",numTunnels>3?"":"none");
if(numLineTerminals==0)
{
SetFxDisplay("terminal_Index",'none');
}
SetFxDisplay("termnavline1",numSerialPorts>0?"":"none");
SetFxDisplay("termnavline2",numSerialPorts>1?"":"none");
SetFxDisplay("termnavusb1",numUSBPorts>0?"":"none");
}
function Localize_NetworkTab()
{
document.getElementById('softap_index').innerHTML=GetMessage("softap",0);
document.getElementById('bridge_index').innerHTML=GetMessage("net",121);
document.getElementById('bridge_statistics').innerHTML=GetMessage("strings",36);
document.getElementById('bridge_configuration').innerHTML=GetMessage("strings",37);
document.getElementById('nav1_wired').innerHTML=GetMessage("net",276);
document.getElementById('nav1_network_interface').innerHTML=GetMessage("strings",54);
document.getElementById('nav1_network_configuration').innerHTML=GetMessage("strings",37);
document.getElementById('nav1_network_link').innerHTML=GetMessage("strings",77);
document.getElementById('nav1_network_link_configuration').innerHTML=GetMessage("strings",37);
document.getElementById('nav2_wireless').innerHTML=GetMessage("net",265);
document.getElementById('nav2_network_interface').innerHTML=GetMessage("strings",54);
document.getElementById('nav2_network_configuration').innerHTML=GetMessage("strings",37);
document.getElementById('nav2_network_link').innerHTML=GetMessage("strings",77);
document.getElementById('nav2_network_link_configuration').innerHTML=GetMessage("strings",37);
document.getElementById('protocol_stack_index').innerHTML=GetMessage("net",124);
document.getElementById('wlan_wps_index').innerHTML=GetMessage("net",253);
document.getElementById('quickconnect_index').innerHTML=GetMessage("net",125);
document.getElementById('wlan_profiles_index').innerHTML=GetMessage("net",126);
}
function Localize_DiagTab()
{
document.getElementById('diag_tab_dns').innerHTML=GetMessage("dns",14);
document.getElementById('diag_tab_hardware').innerHTML=GetMessage("hw",8);
document.getElementById('diag_tab_ip_sockets').innerHTML=GetMessage("ip_sockets",6);
document.getElementById('diag_tab_log').innerHTML=GetMessage("diagnostics_log",6);
document.getElementById('diag_tab_memory').innerHTML=GetMessage("memory",6);
document.getElementById('diag_tab_hardware').innerHTML=GetMessage("hw",8);
document.getElementById('diag_tab_processes').innerHTML=GetMessage("tasks",3);
document.getElementById('diag_tab_threads').innerHTML=GetMessage("threads",3);
document.getElementById('diag_tab_ping').innerHTML=GetMessage("ping",17);
document.getElementById('diag_tab_routes').innerHTML=GetMessage("routes",7);
document.getElementById('diag_tab_traceroute').innerHTML=GetMessage("tr",8);
}
function Localize(xml)
{
document.getElementById('tab_Status').innerHTML=GetMessage("strings",0);
document.getElementById('tab_Network').innerHTML=GetMessage("strings",1);
document.getElementById('tab_Filesystem').innerHTML=GetMessage("strings",16);
document.getElementById('tab_Diagnostics').innerHTML=GetMessage("strings",3);
document.getElementById('tab_Administration').innerHTML=GetMessage("strings",4);
document.getElementById('toggle_menu').innerHTML=GetMessage("strings",66);
document.getElementById('text_logout').innerHTML=GetMessage("logout",0);
document.getElementById('text_help').innerHTML=GetMessage("strings",115);
document.title=GetMessage("strings",137);
document.getElementById('key_copyright').innerHTML=GetMessage("strings",138);
}
function WebMgrLogoutEnable(xml)
{
var lc = document.getElementById("logoutContainer");
if (lc)
{
if(GetXmlData(xml, "username") && document.getElementById('current_user'))
{
document.getElementById('current_user').innerHTML=GetXmlData(xml, "username");
}
lc.style.display = "block";
}
}
function WebMgrLogoutDisable(xml)
{
var lc = document.getElementById("logoutContainer");
if (lc)
{
lc.style.display = "none";
}
}
function WebMgrHelpEnable(xml)
{
var lc = document.getElementById("helpContainer");
if (lc)
{
lc.style.visibility = "visible";
}
}
function WebMgrHelpDisable(xml)
{
var lc = document.getElementById("helpContainer");
if (lc)
{
lc.style.visibility = "hidden";
}
}
function HighlightElementInTable(tableId, elementId)
{
var navTable = document.getElementById(tableId);
if(navTable != undefined){
var entries = navTable.getElementsByTagName("td");
for(var i = 0; i < entries.length; ++i)
{
entries[i].className = "";
}
var e = document.getElementById(elementId);
if(e != undefined){
e.className = "selected";
}
}
}
function SetNav(xml)
{
var n1 = GetXmlData(xml, 'n1');
var n2 = GetXmlData(xml, 'n2');
var n3 = GetXmlData(xml, 'n3');
if(n1 != undefined)
{
HighlightElementInTable("Nav1", n1);
}
if(n2 != undefined)
{
HighlightElementInTable("Nav2", n2);
}
if(n3 != undefined && n3 >= 0){
HighlightElementInTable(n2 + "_Nav", n2 + "_" + (1 + Number(n3)));
document.getElementById(n2 + '_OptNav').style.display = 'inline';
}
}
showIdPrevious = "";
function ShowId(id)
{
var d = document.getElementById(showIdPrevious);
if(d)
{
d.style.display = 'none';
}
showIdPrevious = id;
d = document.getElementById(id);
if(d)
{
d.style.display = 'block';
}
}
function replaceString(mainStr, searchStr, replaceStr)
{
var foundOffset = mainStr.indexOf(searchStr);
if(foundOffset == -1)
{
return mainStr;
}
else
{
var front = mainStr.substring(0,foundOffset);
var back = mainStr.substring(foundOffset+searchStr.length,mainStr.length);
return front + replaceStr + replaceString(back,searchStr,replaceStr);
}
}
function stringMatch(x, y)
{
var x1 = replaceString(x, "&gt;", ">");
var y1 = replaceString(y, "&gt;", ">");
return (x1 == y1);
}
var fileSystemStatusXmlHttp;
var fileSystemStatusEnable = false;
var fileSystemStatusTimer = null;
function FileSystemMonitor(){
fileSystemStatusEnable = true;
fileSystemStatusTimer=setTimeout("PollFileSystemStatus()", 1000);
}
function FileSystemMonitorDisable()
{
fileSystemStatusEnable = false;
clearTimeout(fileSystemStatusTimer);
fileSystemStatusTimer=null;
}
function PollFileSystemStatus(){
fileSystemStatusXmlHttp = ajax.getRequestObject();
if(fileSystemStatusXmlHttp){
var url = window.location.protocol+"//"+window.location.hostname+(window.location.port ? ':'+window.location.port : '') +"/file_system_status?" + Date();
fileSystemStatusXmlHttp.open("GET", url, true);
fileSystemStatusXmlHttp.onreadystatechange = FileSystemStatusCallback;
fileSystemStatusXmlHttp.send(null);
clearTimeout(fileSystemStatusTimer);
fileSystemStatusTimer=null;
if(fileSystemStatusEnable)
{
fileSystemStatusTimer=setTimeout("PollFileSystemStatus()", 2000);
}
}
}
function FileSystemStatusCallback(){
if(fileSystemStatusXmlHttp && fileSystemStatusEnable){
if(fileSystemStatusXmlHttp.readyState == 4){
if(fileSystemStatusXmlHttp.status == 200){
if(
fileSystemStatusXmlHttp.responseText &&
fileSystemStatusXmlHttp.responseText.length > 0
){
var text = "" + fileSystemStatusXmlHttp.responseText + '\r';
var d = document.getElementById('results');
if(d)
{
d.innerHTML='';
}
PrintMsg(text, "results");
}
}
}
}
}
function GetInputElementValue(ie)
{
if(ie.type=="select-one")
{
if(ie.selectedIndex >= 0 && ie.selectedIndex < ie.length)
{
return ie.options[ie.selectedIndex].value;
}
return "";
}
else if(ie.type=="checkbox")
{
return ie.checked ? "Enabled" : "Disabled";
}
else if(ie.type==undefined && ie.length>0 && ie[0].type=="radio")
{
for(var i=0; i<ie.length; ++i)
{
if(ie[i].checked)
{
return ie[i].value;
}
}
return "";
}
else
{
return ie.value;
}
}
function FindElement(name)
{
for(var i=0;i<document.forms.length;i++)
{
var ie = document.forms[i].elements[name];
if(ie)return ie;
}
return null;
}
function GetDisplayValue(name)
{
var ie = document.forms[0].elements[name];
if(! ie)ie = FindElement(name);
if(! ie)
{
return "";
}
return GetInputElementValue(ie);
}
function SetDisplayValue(name, value)
{
var n = document.forms[0].elements[name];
if(! n)n = FindElement(name);
if(n)
{
if(n.type=="select-one")
{
for(var i=0; i<n.length; ++i)
{
if(n.options[i].value==value)
{
n.selectedIndex=i;
break;
}
}
}
else if(n.type=="checkbox")
{
n.checked = value == "Enabled";
}
else if(n.type==undefined && n.length>0 && n[0].type=="radio")
{
for(var i=0; i<n.length; ++i)
{
n[i].checked = n[i].value==value ? true : false;
}
}
else
{
n.value = value;
}
}
}
function SetDisplayValueEx(frmName,name, value)
{
var reqForm=document.getElementById(frmName);
if(reqForm)
{
var n = reqForm.elements[name];
if(n)
{
if(n.type=="select-one")
{
for(var i=0; i<n.length; ++i)
{
if(n.options[i].value==value)
{
n.selectedIndex=i;
break;
}
}
}
else if(n.type=="checkbox")
{
n.checked = value == "Enabled";
}
else if(n.type==undefined && n.length>0 && n[0].type=="radio")
{
for(var i=0; i<n.length; ++i)
{
n[i].checked = n[i].value==value ? true : false;
}
}
else
{
n.value = value;
}
}
}
}
function GetDivValue(e)
{
return e.textContent == undefined ? e.innerText : e.textContent;
}
function GetDivValueById(id)
{
var e = document.getElementById(id);
return GetDivValue(e);
}
function SetDisplaySelection(name)
{
displayElementRootNames.push(name);
var cvalue = GetDivValueById("current_" + name);
var s = document.getElementById("status_" + name);
if(s)
{
var svalue = GetDivValue(s);
s.style.backgroundColor = (cvalue == svalue ? "" : "yellow");
}
SetDisplayValue("new_" + name, cvalue);
return cvalue;
}
function SetDisplaySelectionEx(frmName, name)
{
displayElementRootNames.push(name);
var cvalue = GetDivValueById("current_" + name);
var s = document.getElementById("status_" + name);
if(s)
{
var svalue = GetDivValue(s);
s.style.backgroundColor = (cvalue == svalue ? "" : "yellow");
}
SetDisplayValueEx(frmName,"new_" + name, cvalue);
return cvalue;
}
function SetSubmit(enable, xml)
{
SetButtonVisibilities(xml);
var submit_button=document.getElementById('submit_button');
if(submit_button)
{
submit_button.style.display=(IsSubmitButtonForcedToBeVisible() || enable)?'':'none';
}
var cancel_button=document.getElementById('cancel_button');
if(cancel_button)
{
cancel_button.style.display=(enable)?'':'none';
}
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display=(IsApplyButtonForcedToBeVisible() || enable)?'':'none';
}
var test_button=document.getElementById('test_button');
if(test_button)
{
test_button.style.display=(IsTestButtonForcedToBeVisible() || enable)?'':'none';
}
var rb = document.getElementById('reassert_button');
if(rb)
{
rb.style.backgroundColor = "yellow";
var displayReasert = false;
if(! IsSubmitButtonForcedToBeVisible() && ! enable)
{
for(var i = 0; i < displayElementRootNames.length; ++i)
{
var name = displayElementRootNames[i];
var c = document.getElementById("current_"+name);
var s = document.getElementById("status_"+name);
if(c && s && GetDivValue(c) != GetDivValue(s) && (GetDivValue(s)!="N/A"))
{
displayReasert = true;
break;
}
}
}
rb.style.display=displayReasert?'':'none';
}
}
function Update(optElement)
{
if(optElement)
{
if(
optElement.value == "<None>" ||
optElement.value == "<Configured>" ||
optElement.value == "<Random>" ||
optElement.value == "<Default>"
)
{
optElement.select();
}
}
var somethingChanged = false;
for(var i = 0; i < displayElementRootNames.length; ++i)
{
var name = displayElementRootNames[i];
var cvalue = GetDivValueById("current_" + name);
var ie = document.forms[0].elements["new_" + name];
if(! ie)ie = FindElement("new_" + name);
if(ie)
{
var nvalue = GetInputElementValue(ie);
if(cvalue != nvalue)
{
somethingChanged = true;
break;
}
}
else
{
alert("No element named new_" + name);
}
}
SetSubmit(somethingChanged);
}
var PreviousIndexDisplayElement;
function IndexDisplayElement(e)
{
if(PreviousIndexDisplayElement == undefined)
{
PreviousIndexDisplayElement = document.getElementById("status_Index");
}
PreviousIndexDisplayElement.className = PreviousIndexDisplayElement.className.replace(new RegExp("active", "g"), "");
PreviousIndexDisplayElement = e;
e.className += " active";
}
function IndexIdChange(xml)
{
var id = GetXmlData(xml, "id");
if(id && document.getElementById(id))
{
IndexDisplayElement(document.getElementById(id));
}
}
function isPhoneNumber(number)
{
var i,j,strTemp;
strTemp="0123456789-()# +";
for (i=0;i<number.length;i++){
j=strTemp.indexOf(number.charAt(i));
if (j==-1){
return false;
}
}
return true;
}
function isEmailAddress(addr)
{
var i = addr.length;
var temp = addr.indexOf('@');
var tempd = addr.indexOf('.');
if(temp>1){
if(i-temp > 3){
if(i-tempd>0){
return true;
}
}
}
return false;
}
function CheckNumbers(prefix,start,end,message,message2)
{
var i = start;
for(i=start;i<=end;i++){
var v = GetDisplayValue(prefix + i);
if(v != ""){
if(isPhoneNumber(v) == false){
alert(message + i + message2);
return false;
}
}
}
return true;
}
function CheckEmails(prefix,start,end,message,message2)
{
var i = start;
for(i=start;i<=end;i++){
var v = GetDisplayValue(prefix + i);
if(v != ""){
if(isEmailAddress(v) == false){
alert(message + i + message2);
return false;
}
}
}
return true;
}
function CheckEmptys(prefix,start,end)
{
var i = start;
var cnt = 0;
for(i=start;i<=end;i++){
var v = GetDisplayValue(prefix + i);
if(v != ""){
cnt++;
}
}
return cnt;
}
function LimitInputElementValue(ie)
{
var value = GetInputElementValue(ie);
var mlength = ie.getAttribute? parseInt(ie.getAttribute("maxlength")) : "";
if (ie.getAttribute && ie.value.length > mlength){
ie.value = ie.value.substring(0,mlength)
}
}
