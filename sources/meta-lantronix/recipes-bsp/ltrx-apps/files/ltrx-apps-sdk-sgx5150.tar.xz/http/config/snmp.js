function SetSnmpDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Snmp.Snmpd.State');
SetDisplaySelection('Snmp.Snmpd.Port');
SetDisplaySelection('Snmp.Snmpd.Version');
SetDisplaySelection('Snmp.Snmpd.Read_Community');
SetDisplaySelection('Snmp.Snmpd.Write_Community');
SetDisplaySelection('Snmp.Snmpd.Username');
SetDisplaySelection('Snmp.Snmpd.Security');
SetDisplaySelection('Snmp.Snmpd.Authentication_Password');
SetDisplaySelection('Snmp.Snmpd.Authentication_Protocol');
SetDisplaySelection('Snmp.Snmpd.Privacy_Password');
SetDisplaySelection('Snmp.Snmpd.Privacy_Protocol');
SetDisplaySelection('Snmp.Snmpd.Read_Only_Username');
SetDisplaySelection('Snmp.Snmpd.Read_Only_Security');
SetDisplaySelection('Snmp.Snmpd.Read_Only_Authentication_Password');
SetDisplaySelection('Snmp.Snmpd.Read_Only_Authentication_Protocol');
SetDisplaySelection('Snmp.Snmpd.Read_Only_Privacy_Password');
SetDisplaySelection('Snmp.Snmpd.Read_Only_Privacy_Protocol');
SetDisplaySelection('Snmp.Snmpd.System_Contact');
SetDisplaySelection('Snmp.Snmpd.System_Name');
SetDisplaySelection('Snmp.Snmpd.System_Description');
SetDisplaySelection('Snmp.System_Location');
SetDisplaySelection('Snmp.Traps.Primary_Destination');
SetDisplaySelection('Snmp.Traps.Primary_Destination_Port');
SetDisplaySelection('Snmp.Traps.Secondary_Destination');
SetDisplaySelection('Snmp.Traps.Secondary_Destination_Port');
SetDisplaySelection('Snmp.Traps.Version');
SetDisplaySelection('Snmp.Traps.Community');
SetDisplaySelection('Snmp.Traps.Username');
SetDisplaySelection('Snmp.Traps.Security');
SetDisplaySelection('Snmp.Traps.Authentication_Password');
SetDisplaySelection('Snmp.Traps.Authentication_Protocol');
SetDisplaySelection('Snmp.Traps.Privacy_Password');
SetDisplaySelection('Snmp.Traps.Privacy_Protocol');
UpdateSnmpDisplay(true);
document.getElementById("snmpform").style.display = "block";
}
function UpdateSnmpDisplay(initial, optElement)
{
var agentEnabled=true;
agentEnabled = GetDisplayValue("new_Snmp.Snmpd.State") == "Enabled";
var snmpdVersion3 = GetDisplayValue("new_Snmp.Snmpd.Version") == "SNMPv3";
SetFxDisplay(
"table_v2", !snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_read_community_Display", !snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_write_community_Display", !snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"table_v3_id", snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_engine_id_Display", snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"table_v3_rwuser", snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_username_Display", snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_security_Display", snmpdVersion3 ? "" : "none", initial
);
var snmpdSecurity = GetDisplayValue("new_Snmp.Snmpd.Security");
SetFxDisplay(
"snmpsnmpd_authenticationprotocol_Display", (snmpdVersion3 && snmpdSecurity!='No Authentication and No Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_authenticationpassword_Display", (snmpdVersion3 && snmpdSecurity!='No Authentication and No Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_privacyprotocol_Display", (snmpdVersion3 && snmpdSecurity=='Authentication and Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_privacypassword_Display", (snmpdVersion3 && snmpdSecurity=='Authentication and Privacy') ? "" : "none", initial
);
SetFxDisplay(
"table_v3_rouser", snmpdVersion3 ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_read_only_username_Display", snmpdVersion3 ? "" : "none", initial
);
var snmpd_read_only_User = GetDisplayValue("new_Snmp.Snmpd.Read_Only_Username");
SetFxDisplay(
"snmpsnmpd_read_only_security_Display", (snmpdVersion3 ) ? "" : "none", initial
);
var snmpd_read_only_Security = GetDisplayValue("new_Snmp.Snmpd.Read_Only_Security");
SetFxDisplay(
"snmpsnmpd_read_only_authenticationprotocol_Display", (snmpdVersion3 && snmpd_read_only_Security!='No Authentication and No Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_read_only_authenticationpassword_Display", (snmpdVersion3 && snmpd_read_only_Security!='No Authentication and No Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_read_only_privacyprotocol_Display", (snmpdVersion3 && snmpd_read_only_Security=='Authentication and Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmpsnmpd_read_only_privacypassword_Display", (snmpdVersion3 && snmpd_read_only_Security=='Authentication and Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmptrap_header_Display", agentEnabled? "" : "none", initial
);
SetFxDisplay(
"snmptrap_primary_destination_Display", agentEnabled? "" : "none", initial
);
SetFxDisplay(
"snmptrap_primary_destination_port_Display", agentEnabled? "" : "none", initial
);
SetFxDisplay(
"snmptrap_secondary_destination_Display", agentEnabled? "" : "none", initial
);
SetFxDisplay(
"snmptrap_secondary_destination_port_Display", agentEnabled? "" : "none", initial
);
var alarmSNMPTrap = GetDisplayValue("new_Snmp.Traps.Primary_Destination") != "" || GetDisplayValue("new_Snmp.Traps.Secondary_Destination") != "";
SetFxDisplay(
"snmptrap_version_Display", (agentEnabled && alarmSNMPTrap) ? "" : "none", initial
);
var snmptrapVersion3 = GetDisplayValue("new_Snmp.Traps.Version") == "SNMPv3";
SetFxDisplay(
"snmptrap_community_Display", (agentEnabled && alarmSNMPTrap && !snmptrapVersion3) ? "" : "none", initial
);
SetFxDisplay(
"snmptrap_username_Display", (agentEnabled && alarmSNMPTrap && snmptrapVersion3) ? "" : "none", initial
);
SetFxDisplay(
"snmptrap_security_Display", (agentEnabled && alarmSNMPTrap && snmptrapVersion3) ? "" : "none", initial
);
var snmptrapSecurity = GetDisplayValue("new_Snmp.Traps.Security");
SetFxDisplay(
"snmptrap_authenticationprotocol_Display", (agentEnabled && alarmSNMPTrap && snmptrapVersion3 && snmptrapSecurity!='No Authentication and No Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmptrap_authenticationpassword_Display", (agentEnabled && alarmSNMPTrap && snmptrapVersion3 && snmptrapSecurity!='No Authentication and No Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmptrap_privacyprotocol_Display", (agentEnabled && alarmSNMPTrap && snmptrapVersion3 && snmptrapSecurity=='Authentication and Privacy') ? "" : "none", initial
);
SetFxDisplay(
"snmptrap_privacypassword_Display", (agentEnabled && alarmSNMPTrap && snmptrapVersion3 && snmptrapSecurity=='Authentication and Privacy') ? "" : "none", initial
);
Update(optElement);
}
