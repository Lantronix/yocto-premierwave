function SetFtpServerDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Ftp_Server.State');
SetDisplaySelection('Ftp_Server.Port');
SetDisplaySelection('Ftp_Server.Data_Port');
SetDisplaySelection('Ftp_Server.Passive_Mode_Start_Port');
SetDisplaySelection('Ftp_Server.Passive_Mode_Ports');
UpdateFtpServerDisplay(true);
document.getElementById("ftpform").style.display = "block";
}
function BuildFtpHtml(xml)
{
}
function UpdateFtpServerDisplay(initial, optElement)
{
Update(optElement);
}
