function DNSLookupRender(xml)
{
var d = document.getElementById('dns_results');
if(d)
{
d.innerHTML = '';
var r = '';
if(! xml || ! xml.hasChildNodes())
{
}
else
{
r += "<div>";
r += "<table class=\"table table-striped table-condensed\">";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "t")
{
r += "<tr>";
r += "<td>" + GetXmlData(node, "n") + "</td>";
r += "</tr>";
}
}
r += "</table>";
r += "</div>";
}
d.innerHTML = r;
}
}
function DnsCacheRender(xml)
{
var d = document.getElementById('dnscache');
d.innerHTML = '';
var r = '';
r += '<table class="table table-striped table-condensed">';
r += '<thead><tr>';
r += '<td><b>Cache Entries</b></td>';
r += '</tr></thead>';
if(! xml || ! xml.hasChildNodes())
{
r += "<tr><td><b>There are no entries in the cache.</b></td></tr>";
}
else
{
for(var i = 0; xml && i < xml.childNodes.length; i++)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "d")
{
var name = GetXmlData(node, "n");
var ip = GetXmlData(node, "i");
var updates = GetXmlData(node, "u");
var numfail = GetXmlData(node, "f");
var maxfail = GetXmlData(node, "m");
r += "<tr><td>";
r += "<b>" + name + "</b> - " + ip + " [<a href=\"javascript:void(0)\" onclick=\"if (confirm('Are you SURE you want to delete this information?')) ajax_DnsClean([true, 'action=deleteentry&amp;name=" + encodeURIComponent(name) + "']); return false;\">Delete</a>]<br/>";
r += "Expires in " + GetXmlData(node, "e") + "<br/>";
if(updates && numfail && maxfail)
{
r += "Updates " + updates + "<br/>" + numfail + " Failures / " + maxfail + " Max Failures<br/>";
}
r += "</td></tr>";
}
}
}
r += "</table>";
d.innerHTML = r;
}
function SetDNSDisplay()
{
GetMessageDisplay('diag_dns',"dns",15);
GetMessageDisplay('diag_dns_current',"dns",7);
GetMessageDisplay('diag_dns_domain',"strings",75);
GetMessageDisplay('diag_dns_primary',"strings",61);
GetMessageDisplay('diag_dns_secondary',"strings",62);
document.getElementById('lookup_button').value=GetMessage("dns",16);
}
