function SetRoutingProtocolsDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Routing_Protocols.RIP.State');
SetDisplaySelection('Routing_Protocols.RIP.Version');
SetDisplaySelection('Routing_Protocols.RIP.Update_Interval');
SetDisplaySelection('Routing_Protocols.RIP.Timeout_Interval');
SetDisplaySelection('Routing_Protocols.RIP.GC_Interval');
SetDisplaySelection('Routing_Protocols.OSPF.State');
SetDisplaySelection('Routing_Protocols.OSPF.Hello_Interval');
SetDisplaySelection('Routing_Protocols.OSPF.Dead_Interval');
document.getElementById("routingprotocolsform").style.display = "block";
}
function SetAdmin_GatewayDisplay()
{
var menu=document.getElementById('gateway_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('gateway_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
var menu=document.getElementById('gatewayconf_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('gatewayconf_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function VirtualInterfacesRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve virtual ip.</p>";
var d = document.getElementById('virtual_interfaces');
d.innerHTML=r;
}
else
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><th><b>Enabled</b></th><th><b>Delete</b></th><th><b>Name</b></th><th><b>IP Address</b></th><th><b>LAN IP Address</b></th></tr></thead>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "virtual_interfaces")
{
var definedInterfaces=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var vinterface = node.childNodes[j];
if(vinterface.nodeName.toLowerCase() == "vinterface")
{
var identifier=GetXmlData(vinterface,"index");
var state=GetXmlData(vinterface,"state");
var name=GetXmlData(vinterface,"name");
if(name=="")name='&lt;None&gt;';
var ip_address=GetXmlData(vinterface,"ip_address");
if(ip_address!="&#60;None&#62;")
{
var ip_address=GetXmlData(vinterface,"ip_address");
if(ip_address=="" || ip_address=="&#60;None&#62;")ip_address="*";
var lan_ip_address=GetXmlData(vinterface,"lan_ip_address");
if(lan_ip_address=="" || ip_address=="&#60;None&#62;")lan_ip_address="*";
s += "<tr>";
s += "<td>";
s += "<input class='form-check-input' type='checkbox' ";
s += "onclick='updateButtonVisibilities(\"virtual_interface_list\",\"submit_changes\",\"cancel_changes\");' name='vinterface_state." + identifier +"' org_state='"+state+"' ";
if(state=="true")s += " checked ";
s += "/>";
s += "</td>";
s += "<td>"
s += "<input class='form-check-input' type='checkbox' ";
s += "onclick='updateButtonVisibilities(\"virtual_interface_list\",\"submit_changes\",\"cancel_changes\");' name='vinterface_delete." + identifier +"' org_state='false'/>";
s += "</td>";
s += "<td>";
s += "<a href=\"javascript:void(0)\" ";
s += " onclick=\"";
s += "ajax_AddToHistory(";
s += "'GatewayPage',";
s += "[true, '&amp;menu1=config&amp;menu2=VirtualInterfaces&amp;menu3=EditInterface&amp;edit_vinterface_identifier=" + identifier + "']";
s += ");";
s += "return false;";
s += "\"";
s += ">";
s += '<img class="fsimage" src="edit-icon.gif" width="20" height="20"/><br/>';
s += name;
s += "</a>";
s += "</td>";
s += "<td>"+ip_address+"</td>";
s += "<td>"+lan_ip_address+"</td>";
s += "</tr>";
definedInterfaces++;
}
}
}
}
}
if(definedInterfaces==0)
{
s = "<tr><td colspan='5'><i>No virtual IP addresses are defined</i></td></tr>";
}
r += s;
r += "</table>";
var d = document.getElementById('virtual_interfaces');
d.innerHTML=r;
updateButtonVisibilities('virtual_interface_list','submit_changes','cancel_changes');
}
}
function EditVirtualInterfaceRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Invalid virtual IP instance.</p>";
var d = document.getElementById('results');
d.innerHTML=r;
}
else
{
var s="";
r = "<table class='table table-striped table-condensed'>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "virtual_interface")
{
var definedInterfaces=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var vinterface = node.childNodes[j];
if(vinterface.nodeName.toLowerCase() == "vinterface")
{
var identifier=GetXmlData(vinterface,"index");
var name=GetXmlData(vinterface,"name");
var ip_address=GetXmlData(vinterface,"ip_address");
var lan_ip_address=GetXmlData(vinterface,"lan_ip_address");
s += "<tr><td width='40%'><b>Name</b></td>";
s += "<td><input type='text' size='32' maxlength='32' name='vinterface_name."+identifier+"' org_value='"+name+"' value='"+name+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_virtual_interface_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>IP Address</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='vinterface_ip_address."+identifier+"' org_value='"+ip_address+"' value='"+ip_address+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_virtual_interface_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>LAN IP Address</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='vinterface_lan_ip_address."+identifier+"' org_value='"+lan_ip_address+"' value='"+lan_ip_address+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_virtual_interface_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "</tr>";
definedInterfaces++;
}
}
}
}
if(definedInterfaces==0)
{
s = "<tr><td colspan='2'><i>Invalid virtual IP.</i></td></tr>";
}
r += s;
r += "</table>";
var d = document.getElementById('gateway_virtual_interface_editvinterface');
d.innerHTML=r;
updateButtonVisibilities('gateway_virtual_interface_edit','submit_changes','cancel_changes');
}
}
function SetVirtualInterfaceDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("virtual_interface_list").style.display = "block";
document.getElementById("virtual_interface_add").reset();
document.getElementById("virtual_interface_add").style.display = "block";
}
function SetVirtualInterfaceEditDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("gateway_virtual_interface_edit").style.display = "block";
}
function GatewayPortForwardingRulesRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve port forwarding rules.</p>";
var d = document.getElementById('gateway_portforwarding_rules');
d.innerHTML=r;
}
else
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><th><b>Enabled</b></th><th><b>Delete</b></th><th><b>Name</b></th><th><b>Ingress IP Address: Port Range</b></th><th><b>Protocol</b></th><th><b>IP Address: Target Port</b></th></tr></thead>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "port_forwarding")
{
var definedRules=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var rule = node.childNodes[j];
if(rule.nodeName.toLowerCase() == "rule")
{
var identifier=GetXmlData(rule,"index");
var state=GetXmlData(rule,"state");
var friendly_name=GetXmlData(rule,"friendly_name");
if(friendly_name=="")friendly_name='&lt;None&gt;';
var port_or_range=GetXmlData(rule,"port_or_range");
var target_port=GetXmlData(rule,"target_port");
if(target_port=="")target_port="*";
var protocol=GetXmlData(rule,"protocol");
var ip_address=GetXmlData(rule,"ip_address");
var target_ip_address=GetXmlData(rule,"target_ip_address");
if(target_ip_address!="&#60;None&#62;")
{
var ip_address=GetXmlData(rule,"ip_address");
if(ip_address=="" || ip_address=="&#60;None&#62;")ip_address="*";
s += "<tr>";
s += "<td>";
s += "<input class='form-check-input' type='checkbox' ";
s += "onclick='updateButtonVisibilities(\"gateway_portforwarding_list\",\"submit_changes\",\"cancel_changes\");' name='rule_state." + identifier +"' org_state='"+state+"' ";
if(state=="true")s += " checked ";
s += "/>";
s += "</td>";
s += "<td>"
s += "<input class='form-check-input' type='checkbox' ";
s += "onclick='updateButtonVisibilities(\"gateway_portforwarding_list\",\"submit_changes\",\"cancel_changes\");' name='rule_delete." + identifier +"' org_state='false'/>";
s += "</td>";
s += "<td>";
s += "<a href=\"javascript:void(0)\" ";
s += " onclick=\"";
s += "ajax_AddToHistory(";
s += "'GatewayPage',";
s += "[true, '&amp;menu1=config&amp;menu2=PortForwarding&amp;menu3=EditRule&amp;edit_rule_identifier=" + identifier + "']";
s += ");";
s += "return false;";
s += "\"";
s += ">";
s += '<img class="fsimage" src="edit-icon.gif" width="20" height="20"/><br/>';
s += friendly_name;
s += "</a>";
s += "</td>";
s += "<td>"+ip_address+": ";
s += " "+port_or_range+"</td>";
s += "<td>"+protocol+"</td>";
s += "<td>"+target_ip_address+": ";
s += " "+target_port+"</td>";
s += "</tr>";
definedRules++;
}
}
}
}
}
if(definedRules==0)
{
s = "<tr><td colspan='6'><i>No rules are defined</i></td></tr>";
}
r += s;
r += "</table>";
var d = document.getElementById('gateway_portforwarding_rules');
d.innerHTML=r;
updateButtonVisibilities('gateway_portforwarding_list','submit_changes','cancel_changes');
}
}
function GatewayEditPortForwardingRuleRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Invalid rule.</p>";
var d = document.getElementById('results');
d.innerHTML=r;
}
else
{
var s="";
r = "<table class='table table-striped table-condensed'>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "port_forwarding")
{
var definedRules=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var rule = node.childNodes[j];
if(rule.nodeName.toLowerCase() == "rule")
{
var identifier=GetXmlData(rule,"index");
var friendly_name=GetXmlData(rule,"friendly_name");
var port_or_range=GetXmlData(rule,"port_or_range");
var target_port=GetXmlData(rule,"target_port");
var protocol=GetXmlData(rule,"protocol");
var ip_address=GetXmlData(rule,"ip_address");
var target_ip_address=GetXmlData(rule,"target_ip_address");
s += "<tr><td width='40%'><b>Name</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='rule_name."+identifier+"' org_value='"+friendly_name+"' value='"+friendly_name+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_portforwarding_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Ingress IP Address</b></br><i>(Optional)</i></td>";
s += "<td><input type='text' size='32' maxlength='64' name='rule_ip_address."+identifier+"' org_value='"+ip_address+"' value='"+ip_address+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_portforwarding_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Port or Range</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='rule_port."+identifier+"' org_value='"+port_or_range+"' value='"+port_or_range+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_portforwarding_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Protocol</b></td>";
s += "<td><table><tr><td><select class='form-control' name='rule_protocol."+identifier+"' org_value='"+protocol+"' onchange='updateButtonVisibilities(\"gateway_portforwarding_edit\",\"submit_changes\",\"cancel_changes\");'>";
s += "<option value='0'";
if(protocol=="Both")
{
s += "selected";
}
s += ">Both</option>";
s += "<option value='1'";
if(protocol=="TCP")
{
s += "selected";
}
s += ">TCP</option>";
s += "<option value='2'";
if(protocol=="UDP")
{
s += "selected";
}
s += ">UDP</option>";
s += "</select></td></tr></table></td></tr>";
s += "<tr><td><b>IP Address</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='rule_target_ip_address."+identifier+"' org_value='"+target_ip_address+"' value='"+target_ip_address+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_portforwarding_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Target Port</b></br><i>(Optional)</i></td>";
s += "<td><input type='text' size='32' maxlength='64' name='rule_target_port."+identifier+"' org_value='"+target_port+"' value='"+target_port+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_portforwarding_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
definedRules++;
}
}
}
}
if(definedRules==0)
{
s = "<tr><td colspan='2'><i>Invalid rule.</i></td></tr>";
}
r += s;
r += "</table>";
var d = document.getElementById('gateway_portforwarding_editrule');
d.innerHTML=r;
updateButtonVisibilities('gateway_portforwarding_edit','submit_changes','cancel_changes');
}
}
function GatewayEditStaticRoutesRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Invalid route.</p>";
var d = document.getElementById('results');
d.innerHTML=r;
}
else
{
var s="";
r = "<table class='table table-striped table-condensed'>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "static_routes")
{
var definedRoutes=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var route = node.childNodes[j];
if(route.nodeName.toLowerCase() == "route")
{
var identifier=GetXmlData(route,"index");
var state=GetXmlData(route,"state");
var friendly_name=GetXmlData(route,"friendly_name");
var network=GetXmlData(route,"network");
var gateway=GetXmlData(route,"gateway");
var selected=GetXmlData(route,"selected");
var metric=GetXmlData(route,"metric");
s += "<tr><td><b>Name</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='route_name."+identifier+"' org_value='"+friendly_name+"' value='"+friendly_name+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_staticroutes_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Network or Host</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='route_network."+identifier+"' org_value='"+network+"' value='"+network+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_staticroutes_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Gateway</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='route_gateway."+identifier+"' org_value='"+gateway+"' value='"+gateway+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_staticroutes_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Interface</b></td>";
s += "<td><table><tr><td><select class='form-control' id='route_interface."+identifier+"' name='route_interface."+identifier+"' org_value='"+selected+"' onchange='updateButtonVisibilities(\"gateway_staticroutes_edit\",\"submit_changes\",\"cancel_changes\");'>";
if(xml)
{
var i = 0;
var interfaces = xml.getElementsByTagName("interface");
for(i = 0; interfaces && i < interfaces.length; ++i)
{
var interface = interfaces[i].firstChild.nodeValue;
s += "<option value='"+interface+"'";
if(interface==selected)
{
s += "selected";
}
s += ">"+interface+"</option>";
}
}
s += "</select></td></tr></table></td></tr>";
s += "<tr><td><b>Metric</b></td>";
s += "<td><input type='text' size='3' maxlength='3' name='route_metric."+identifier+"' org_value='"+metric+"' value='"+metric+"' ";
s += "onkeyup='updateButtonVisibilities(\"gateway_staticroutes_edit\",\"submit_changes\",\"cancel_changes\");'/></td>";
s += "</tr>";
definedRoutes++;
var parentForm = document.getElementById('gateway_staticroutes_edit');
var targetId = "route_interface."+identifier;
var interfaceSelection = document.getElementById(targetId);
if(xml && interfaceSelection)
{
interfaceSelection.length = 0;
var i = 0;
var selected=xml.getElementsByTagName("selected");
if(selected && selected.length>0)
{
var selectedInterface=selected[0].firstChild.nodeValue;
}
var interfaces = xml.getElementsByTagName("interface");
for(i = 0; interfaces && i < interfaces.length; ++i)
{
var interface = interfaces[i].firstChild.nodeValue;
interfaceSelection.options[i] = new Option(
interface, interface, false, false
);
if(interface==selectedInterface)
{
interfaceSelection.selectedIndex=i;
}
}
}
}
}
}
}
if(definedRoutes==0)
{
s = "<tr><td colspan='2'><i>Invalid route.</i></td></tr>";
}
r += s;
r += "</table>";
var d = document.getElementById('gateway_staticroutes_editroute');
d.innerHTML=r;
updateButtonVisibilities('gateway_staticroutes_edit','submit_changes','cancel_changes');
}
}
function toggleRoutingTable(obj) {
el = document.getElementById("routing_table");
var old = el.style.display;
el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
el.style.display = (el.style.display == "none") ? "" : "none";
elip = document.getElementById("routing_table_ipv6");
var olds = elip.style.display;
elip.style.visibility = (elip.style.visibility == "visible") ? "hidden" : "visible";
elip.style.display = (elip.style.display == "none") ? "" : "none";
if(el.style.display=="none"
&& elip.style.display == "none"
)
{
obj.innerHTML="Routing Table [+]";
}
else
{
obj.innerHTML="Routing Table [-]";
}
}
function GatewayStaticRoutesRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve static routes.</p>";
var d = document.getElementById('gateway_staticroutes_routes');
d.innerHTML=r;
}
else
{
var s="";
var t="";
var u="";
t = "<h4><p>IPv4</p></h4>";
t += "<table class='table table-striped table-condensed'>";
t += "<thead><tr><th><b>Network</b></th><th><b>Gateway</b></th><th><b>Mask</b></th><th><b>Flags</b></th><th><b>Metric</b></th><th><b>Interface</b></th></tr></thead>";
u = "<h4><p>IPv6</p></h4>";
u += "<table class='basicTable fixedTable table table-striped table-condensed'>";
u+= "<thead><tr><th><b>Network</b></th><th><b>NextHop</b></th><th><b>Flags</b></th><th><b>Metric</b></th><th><b>Interface</b></th></tr></thead>";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><th><b>Enabled</b></th><th><b>Delete</b></th><th><b>Name</b></th><th><b>Route</b></th><th><b>Applied</b></th></tr></thead>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "all_routes")
{
var allRoutes=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var route = node.childNodes[j];
if(route.nodeName.toLowerCase() == "route")
{
var dest=GetXmlData(route,"dest");
var gw=GetXmlData(route,"gw");
var mask=GetXmlData(route,"mask");
var flags=GetXmlData(route,"flags");
var metric=GetXmlData(route,"metric");
var interface=GetXmlData(route,"interface");
t += "<tr>";
t += "<td>"+dest+"</td><td>"+gw+"</td><td>"+mask+"</td><td>"+flags+"</td><td>"+metric+"</td><td>"+interface+"</td>";
t += "</tr>";
allRoutes++;
}
}
}
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "all_routes")
{
var allRoutes=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var route = node.childNodes[j];
if(route.nodeName.toLowerCase() == "route_ipv6")
{
var dest=GetXmlData(route,"dest");
var nh=GetXmlData(route,"nh");
var flags=GetXmlData(route,"flags");
var metric=GetXmlData(route,"metric");
var interface=GetXmlData(route,"interface");
u += "<tr>";
u += "<td>"+dest+"</td><td>"+nh+"</td><td>"+flags+"</td><td>"+metric+"</td><td>"+interface+"</td>";
u += "</tr>";
allRoutes++;
}
}
}
if(node.nodeName.toLowerCase() == "static_routes")
{
var definedRoutes=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var route = node.childNodes[j];
if(route.nodeName.toLowerCase() == "route")
{
var identifier=GetXmlData(route,"index");
var state=GetXmlData(route,"state");
var friendly_name=GetXmlData(route,"friendly_name");
if(friendly_name=="")friendly_name='&lt;None&gt;';
var network=GetXmlData(route,"network");
var interface=GetXmlData(route,"interface");
var metric=GetXmlData(route,"metric");
var applied=GetXmlData(route,"applied");
s += "<tr>";
s += "<td>";
s += "<input class='form-check-input' type='checkbox' ";
s += "onclick='updateButtonVisibilities(\"gateway_staticroutes_list\",\"submit_changes\",\"cancel_changes\");' name='route_state." + identifier +"' org_state='"+state+"' ";
if(state=="true")s += " checked ";
s += "/>";
s += "</td>";
s += "<td>"
s += "<input class='form-check-input' type='checkbox' ";
s += "onclick='updateButtonVisibilities(\"gateway_staticroutes_list\",\"submit_changes\",\"cancel_changes\");' name='route_delete." + identifier +"' org_state='false'/>";
s += "</td>";
s += "<td>";
s += "<a href=\"javascript:void(0)\" ";
s += " onclick=\"";
s += "ajax_AddToHistory(";
s += "'GatewayPage',";
s += "[true, '&amp;menu1=config&amp;menu2=StaticRoutes&amp;menu3=EditRoute&amp;edit_route_identifier=" + identifier + "']";
s += ");";
s += "return false;";
s += "\"";
s += ">";
s += '<img class="fsimage" src="edit-icon.gif" width="20" height="20"/><br/>';
s += friendly_name;
s += "</a>";
s += "</td>";
s += "<td>"+network+"</td>";
s += "<td>";
if (applied=="true")
{
s += "Yes";
}
else
{
s += "No";
}
s += "</td>";
s += "</tr>";
definedRoutes++;
}
}
}
}
if(definedRoutes==0)
{
s = "<tr><td colspan='7'><i>No routes are defined</i></td></tr>";
}
if(allRoutes==0)
{
t = "<tr><td colspan='6'><i>No routes are defined</i></td></tr>";
}
r += s;
r += "</table>";
var d = document.getElementById('gateway_staticroutes_routes');
d.innerHTML=r;
var e = document.getElementById('routing_table');
t += "</table>";
e.innerHTML=t;
var eipvsix = document.getElementById('routing_table_ipv6');
u += "</table>";
eipvsix.innerHTML=u;
updateButtonVisibilities('gateway_staticroutes_list','submit_changes','cancel_changes');
}
}
function GatewayStatusRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve gateway status.</p>";
var d = document.getElementById('wan_status');
d.innerHTML=r;
}
else
{
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "wan_status")
{
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='3'><b>WAN</b></td></tr></thead>";
r += "<tr>";
r += "<td width='40%'><b>Operating Mode:</b></td><td colspan='2'>"+GetXmlData(node, "routing")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>Firewall:</b></td><td colspan='2'>"+GetXmlData(node, "firewall")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>MAC Address filter:</b></td><td colspan='2'>"+GetXmlData(node, "mac_address_filter")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>IP Address filter:</b></td><td colspan='2'>"+GetXmlData(node, "ip_address_filter")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>Default IP Address Filter Policy:</b></td><td colspan='2'>"+GetXmlData(node, "ip_address_filter_policy")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>WAN Interface:</b></td><td colspan='2'>"+GetXmlData(node, "wan_interface")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>LAN Interface:</b></td><td colspan='2'>"+GetXmlData(node, "lan_interface")+"</td>";
r += "</tr>";
r += "<tr><td colspan='3'><b>Router</b></td></tr>";
r += "<tr>";
r += "<td><b>IP Address:</b></td><td colspan='2'>"+GetXmlData(node, "ip_address")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>IPv6 Address:</b></td><td colspan='2'>"+GetXmlData(node, "router_ipv6_address")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>IPv6 Link Local Address:</b></td><td colspan='2'>"+GetXmlData(node, "router_ipv6_link_address")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>Primary DNS:</b></td><td colspan='2'>"+GetXmlData(node, "pdns")+"</td>";
r += "</tr>";
r += "<tr>";
r += "<td><b>Secondary DNS:</b></td><td colspan='2'>"+GetXmlData(node, "sdns")+"</td>";
r += "</tr>";
r += "</table>";
var d = document.getElementById('wan_status');
d.innerHTML=r;
}
if(node.nodeName.toLowerCase() == "port_forwarding")
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='5'><b>Port Forwarding</b></td></tr></thead>";
var definedRules=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var rule = node.childNodes[j];
if(rule.nodeName.toLowerCase() == "rule")
{
var target_ip_address=GetXmlData(rule,"target_ip_address");
if(target_ip_address!="&#60;None&#62;")
{
definedRules++;
var ip_address=GetXmlData(rule,"ip_address");
if(ip_address=="" || ip_address=="&#60;None&#62;")ip_address="*";
var port_or_range=GetXmlData(rule,"ports");
var target_port=GetXmlData(rule,"target_port");
if(target_port=="")target_port="*";
s += "<tr>";
s += "<td>"+GetXmlData(rule,"name")+"</td>";
s += "<td>"+ip_address+": "+port_or_range+"</td>";
s += "<td>"+GetXmlData(rule,"protocol")+"</td>";
s += "<td>"+target_ip_address+": "+target_port+"</td>";
s += "</tr>";
}
}
}
if(definedRules==0)
{
s = "<tr><td colspan='3'><i>No rules are defined</i></td></tr>";
}
else
{
r += "<tr><td><b>Name</b></td><td><b>Ingress IP Address: Port Range</b></td><td><b>Protocol</b></td><td><b>IP Address: Target Port</b></td></tr>";
}
r += s;
r += '</table>';
var d = document.getElementById('port_forwarding');
d.innerHTML=r;
}
if(node.nodeName.toLowerCase() == "static_routes")
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='4'><b>Static Routes</b></td></tr></thead>";
var definedRoutes=0;
for(var k = 0; node && node.childNodes && k < node.childNodes.length; ++k)
{
var route = node.childNodes[k];
if(route.nodeName.toLowerCase() == "route")
{
s += "<tr><td>"+GetXmlData(route,"network")+"</td><td>"+GetXmlData(route,"gateway")+"</td><td>"+GetXmlData(route,"interface")+"</td><td>"+GetXmlData(route,"metric")+"</td></tr>";
if(GetXmlData(route,"network")!="&#60;None&#62;")definedRoutes++;
}
}
if(definedRoutes==0)
{
s = "<tr><td colspan='4'><i>No routes are defined</i></td></tr>";
}
else
{
r += "<tr><td><b>Network or Host</b></td><td><b>Gateway</b></td><td><b>Interface</b></td><td><b>Metric</b></td></tr>";
}
r += s;
r += '</table>';
var d = document.getElementById('static_routes');
d.innerHTML=r;
}
if(node.nodeName.toLowerCase() == "mac_filters")
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='2'><b>MAC Address Filters</b></td></tr></thead>";
var definedRules=0;
for(var k = 0; node && node.childNodes && k < node.childNodes.length; ++k)
{
var rule = node.childNodes[k];
if(rule.nodeName.toLowerCase() == "mac_filter")
{
s += "<tr><td>"+GetXmlData(rule,"mac")+"</td><td>"+GetXmlData(rule,"action")+"</td></tr>";
definedRules++;
}
}
if(definedRules==0)
{
s = "<tr><td colspan='2'><i>No filters are defined</i></td></tr>";
}
else
{
r += "<tr><td width='40%'><b>MAC Address</b></td><td><b>Action</b></td></tr>";
}
r += s;
r += '</table>';
var d = document.getElementById('mac_filters');
d.innerHTML=r;
}
if(node.nodeName.toLowerCase() == "ip_filters")
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='2'><b>IP Address Filters</b></td></tr></thead>";
var definedRules=0;
for(var k = 0; node && node.childNodes && k < node.childNodes.length; ++k)
{
var rule = node.childNodes[k];
if(rule.nodeName.toLowerCase() == "ip_filter")
{
s += "<tr><td>"+GetXmlData(rule,"ip")+"</td><td>"+GetXmlData(rule,"action")+"</td></tr>";
definedRules++;
}
}
if(definedRules==0)
{
s = "<tr><td colspan='2'><i>No IP filters are defined</i></td></tr>";
}
else
{
r += "<tr><td width='40%'><b>IP Address</b></td><td><b>Action</b></td></tr>";
}
r += s;
r += '</table>';
var d = document.getElementById('ip_filters');
d.innerHTML=r;
}
if(node.nodeName.toLowerCase() == "dhcpd")
{
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='2'><b>DHCP Server</b></td></tr></thead>";
for(var l = 0; node && node.childNodes && l < node.childNodes.length; ++l)
{
var child = node.childNodes[l];
if(child.nodeName.toLowerCase() == "lease_time")
{
r += "<tr><td><b>Lease Time:</b></td><td>"+GetXmlData(node, 'lease_time')+" hours</td></tr>";
}
if(child.nodeName.toLowerCase() == "state")
{
r += "<tr><td width='40%'><b>State:</b></td><td>"+GetXmlData(node, 'state')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "relay_state")
{
r += "<tr><td width='40%'><b>DHCP Relay:</b></td><td>"+GetXmlData(node, 'relay_state')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "relay_ip_address")
{
r += "<tr><td><b>DHCP Server IP Address:</b></td><td>"+GetXmlData(node, 'relay_ip_address')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "start_ip_address")
{
r += "<tr><td><b>Start IP Address:</b></td><td>"+GetXmlData(node, 'start_ip_address')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "end_ip_address")
{
r += "<tr><td><b>End IP Address:</b></td><td>"+GetXmlData(node, 'end_ip_address')+"</td></tr>";
}
}
r += "</table>";
r += "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='2'><b>DHCPv6 Server</b></td></tr></thead>";
for(var l = 0; node && node.childNodes && l < node.childNodes.length; ++l)
{
var child = node.childNodes[l];
if(child.nodeName.toLowerCase() == "ipv6_state")
{
r += "<tr><td width='40%'><b>State:</b></td><td>"+GetXmlData(node, 'ipv6_state')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "start_ipv6_address")
{
r += "<tr><td><b>Start IPv6 Address:</b></td><td>"+GetXmlData(node, 'start_ipv6_address')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "end_ipv6_address")
{
r += "<tr><td><b>End IPv6 Address:</b></td><td>"+GetXmlData(node, 'end_ipv6_address')+"</td></tr>";
}
}
r += "</table>";
var s = "<table class='table table-striped table-condensed'>";
s += "<tr><td colspan='3'><b>Static Leases:</b></td></tr>"
s += "<tr><td width='10%'><b>MAC Address</b></td><td width='30%'><b>IP Address</b></td><td><b>IPv6 Address</b></td></tr>";
var definedLeases=0;
for(var l = 0; node && node.childNodes && l < node.childNodes.length; ++l)
{
var child = node.childNodes[l];
if(child.nodeName.toLowerCase() == "address_reservation")
{
var reservation_index=GetXmlData(child,"index");
var mac=GetXmlData(child,"mac");
var ip_address=GetXmlData(child,"ip_address");
var ipv6_address=GetXmlData(child,"ipv6_address");
s += "<tr><td width='40%'>"+mac+"</td><td>"+ip_address+"</td><td>"+ipv6_address+"</td></tr>";
definedLeases++;
}
}
if(definedLeases==0)
{
s += "<tr><td colspan='3'><i>No static leases are defined</i></td></tr>";
}
s += "</table>"
r += s;
var t = "<table class='table table-striped table-condensed'>";
t += "<tr><td colspan='4'><b>Current Leases:</b></td></tr>";
t += "<tr><td  width='10%'><b>MAC Address</b></td><td width='30%'><b>IP Address</b></td><td><b>Hostname</b></td><td><b>Expiry</b></td></tr>";
var assignedLeases=0;
var z = "<table class='table table-striped table-condensed'>";
z += "<tr><td colspan='4'><b>Current IPv6 Leases:</b></td></tr>";
z += "<tr><td width='10%'><b>MAC Address</b></td><td width='30%'><b>IPv6 Address</b></td><td><b>Hostname</b></td><td><b>Expiry</b></td></tr>";
var assignedLeasesIpv6=0;
for(var l = 0; node && node.childNodes && l < node.childNodes.length; ++l)
{
var child = node.childNodes[l];
if(child.nodeName.toLowerCase() == "current_lease")
{
var mac=GetXmlData(child,"mac");
var ip=GetXmlData(child,"ip");
var hostname=GetXmlData(child,"host");
var expiry=GetXmlData(child,"expiry");
t += "<tr><td width='40%'>"+mac+"</td><td>"+ip+"</td><td>"+hostname+"</td><td>"+expiry+"</td></tr>";
assignedLeases++;
}
if(child.nodeName.toLowerCase() == "current_lease_ipv6")
{
var mac=GetXmlData(child,"mac");
var ip=GetXmlData(child,"ip");
var hostname=GetXmlData(child,"host");
var expiry=GetXmlData(child,"expiry");
z += "<tr><td width='40%'>"+mac+"</td><td>"+ip+"</td><td>"+hostname+"</td><td>"+expiry+"</td></tr>";
assignedLeasesIpv6++;
}
}
if(assignedLeases==0)
{
t += "<tr><td colspan='4'><i>No IPv4 leases were assigned</i></td></tr>"
}
t += "</table>"
r += t;
if(assignedLeasesIpv6==0)
{
z += "<tr><td colspan='4'><i>No IPv6 leases were assigned</i></td></tr>"
}
z += "</table>"
r += z;
var d = document.getElementById('dhcpd');
d.innerHTML=r;
}
if(node.nodeName.toLowerCase() == "routing_protocols")
{
var s = "<tr><td colspan='2'><b>RIP</b></td></tr>";
var t = "<tr><td colspan='2'><b>OSPF</b></td></tr>";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='2'><b>Routing Protocols</b></td></tr></thead>";
for(var l = 0; node && node.childNodes && l < node.childNodes.length; ++l)
{
var child = node.childNodes[l];
if(child.nodeName.toLowerCase() == "rip_state")
{
s += "<tr><td width='40%'><b>State:</b></td><td>"+GetXmlData(node, 'rip_state')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "rip_version")
{
s += "<tr><td width='40%'><b>Version:</b></td><td>"+GetXmlData(node, 'rip_version')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "rip_update_interval")
{
s += "<tr><td width='40%'><b>Update Interval:</b></td><td>"+GetXmlData(node, 'rip_update_interval')+" seconds</td></tr>";
}
if(child.nodeName.toLowerCase() == "rip_timeout_interval")
{
s += "<tr><td width='40%'><b>Timeout Interval:</b></td><td>"+GetXmlData(node, 'rip_timeout_interval')+" seconds</td></tr>";
}
if(child.nodeName.toLowerCase() == "rip_gc_interval")
{
s += "<tr><td width='40%'><b>GC Interval:</b></td><td>"+GetXmlData(node, 'rip_gc_interval')+" seconds</td></tr>";
}
if(child.nodeName.toLowerCase() == "ospf_state")
{
t += "<tr><td width='40%'><b>State:</b></td><td>"+GetXmlData(node, 'ospf_state')+"</td></tr>";
}
if(child.nodeName.toLowerCase() == "ospf_hello_interval")
{
t += "<tr><td width='40%'><b>Hello Interval:</b></td><td>"+GetXmlData(node, 'ospf_hello_interval')+" seconds</td></tr>";
}
if(child.nodeName.toLowerCase() == "ospf_dead_interval")
{
t += "<tr><td width='40%'><b>Dead Interval:</b></td><td>"+GetXmlData(node, 'ospf_dead_interval')+" seconds</td></tr>";
}
}
r += s;
r += t;
r += '</table>';
var d = document.getElementById('routing_protocols');
d.innerHTML=r;
}
if(node.nodeName.toLowerCase() == "virtual_interfaces")
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='3'><b>Virtual IP</b></td></tr></thead>";
var definedInterfaces=0;
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var vinterface = node.childNodes[j];
if(vinterface.nodeName.toLowerCase() == "vinterface")
{
var ip_address=GetXmlData(vinterface,"ip_address");
if(ip_address!="&#60;None&#62;")
{
definedInterfaces++;
s += "<tr>";
s += "<td width='40%'>"+GetXmlData(vinterface,"name")+"</td>";
s += "<td>"+ip_address+"</td>";
s += "<td>"+GetXmlData(vinterface,"lan_ip_address")+"</td>";
s += "</tr>";
}
}
}
if(definedInterfaces==0)
{
s = "<tr><td colspan='3'><i>No Virtual IP addresses are defined</i></td></tr>";
}
else
{
r += "<tr><td><b>Name</b></td><td><b>IP Address</b></td><td><b>LAN IP Address</b></td></tr>";
}
r += s;
r += '</table>';
var d = document.getElementById('virtual_interfaces');
d.innerHTML=r;
}
}
}
}
function SetGatewayStatusDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
}
function UpdateWANConnection()
{
Update(false);
}
function UpdateLANConnection()
{
Update(false);
}
function SetGatewayConfigWANDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('GatewayWANConfiguration.Operating_Mode');
SetDisplaySelection('GatewayWANConfiguration.Firewall');
SetDisplaySelection('GatewayWANConfiguration.MAC_Address_Filter');
SetDisplaySelection('GatewayWANConfiguration.IP_Address_Filter');
SetDisplaySelection('GatewayWANConfiguration.Default_IP_Address_Filter_Policy');
SetDisplaySelection('GatewayWANConfiguration.WAN_Interface');
SetDisplaySelection('GatewayWANConfiguration.LAN_Interface');
SetDisplaySelection('GatewayWANConfiguration.Router_IP_Address');
SetDisplaySelection('GatewayWANConfiguration.Router_IPv6_Address');
SetDisplaySelection('GatewayWANConfiguration.Primary_DNS');
SetDisplaySelection('GatewayWANConfiguration.Secondary_DNS');
document.getElementById("gatewaywanform").style.display = "block";
var parentForm = document.getElementById('gatewaywanform');
parentForm.selectedWANInterface.length = 0;
parentForm.selectedLANInterface.length = 0;
var i = 0;
if(xml)
{
var selected=xml.getElementsByTagName("selected");
if(selected && selected.length>0)
{
var selectedInterface=selected[0].firstChild.nodeValue;
document.getElementById("new_GatewayWANConfiguration.WAN_Interface").value=selectedInterface;
}
var interfaces = xml.getElementsByTagName("interface");
for(i = 0; interfaces && i < interfaces.length; ++i)
{
var interface = interfaces[i].firstChild.nodeValue;
parentForm.selectedWANInterface.options[i] = new Option(
interface, interface, false, false
);
if(interface==selectedInterface)
{
parentForm.selectedWANInterface.selectedIndex=i;
}
}
var selected=xml.getElementsByTagName("lan_selected");
if(selected && selected.length>0)
{
var selectedInterface=selected[0].firstChild.nodeValue;
document.getElementById("new_GatewayWANConfiguration.LAN_Interface").value=selectedInterface;
}
var interfaces = xml.getElementsByTagName("lan_interface");
for(i = 0; interfaces && i < interfaces.length; ++i)
{
var interface = interfaces[i].firstChild.nodeValue;
parentForm.selectedLANInterface.options[i] = new Option(
interface, interface, false, false
);
if(interface==selectedInterface)
{
parentForm.selectedLANInterface.selectedIndex=i;
}
}
var filters = xml.getElementsByTagName("mac_filter");
m = "<table class='table table-striped table-condensed'>";
m += "<thead><tr><td><b>Delete</b></td><td width='40%'><b>MAC Address</b></td><td><b>Action</b></td></tr></thead>";
var definedFilters=0;
for(i = 0; filters && i < filters.length; ++i)
{
var filter=filters[i];
var index=GetXmlData(filter,"index");
var action=GetXmlData(filter,"action");
var mac=GetXmlData(filter,"mac");
if(mac)
{
m += "<tr>";
m += "<td>"
m += "<input class='form-check-input' type='checkbox' ";
m += " onclick='updateButtonVisibilities(\"mac_filter\",\"submit_mac_filter_changes\",\"cancel_mac_filter_changes\");' ";
m += " name='filter_" + index +".state' org_state='false'/>";
m += "</td>";
m += "<td>";
m += "<input type='text' size='16' maxlength='64' name='filter_"+index+".mac' org_value='"+mac+"' value='"+mac+"' ";
m += " onkeyup='updateButtonVisibilities(\"mac_filter\",\"submit_mac_filter_changes\",\"cancel_mac_filter_changes\");'/>";
m += "</td>";
m += "<td><table><tr><td><select class='form-control' name='filter_"+index+".action' org_value='"+action+"' onchange='updateButtonVisibilities(\"mac_filter\",\"submit_mac_filter_changes\",\"cancel_mac_filter_changes\");'>";
m += "<option value='ACCEPT'";
if(action=='ACCEPT')
{
m += " selected";
}
m += ">ACCEPT</option>";
m += "<option value='DROP'";
if(action=='DROP')
{
m += " selected";
}
m += ">DROP</option>";
m += "</select></td></tr></table></td>";
m += "</tr>";
definedFilters++;
}
}
if(definedFilters==0)
{
m += "<tr><td colspan='3'><i>No filters are defined</i></td></tr>";
}
m += "</table>";
d = document.getElementById('mac_filter_configuration');
if(d)d.innerHTML=m;
updateButtonVisibilities('mac_filter','submit_mac_filter_changes','cancel_mac_filter_changes');
document.getElementById("mac_filter").style.display = "block";
document.getElementById("new_mac_filter").reset();
document.getElementById("new_mac_filter").style.display = "block";
var filters = xml.getElementsByTagName("ip_filter");
m = "<table class='table table-striped table-condensed'>";
m += "<thead><tr><td><b>Delete</b></td><td width='40%'><b>IP Address</b></td><td><b>Action</b></td></tr></thead>";
var definedFilters=0;
for(i = 0; filters && i < filters.length; ++i)
{
var filter=filters[i];
var index=GetXmlData(filter,"index");
var action=GetXmlData(filter,"action");
var ip=GetXmlData(filter,"ip");
if(ip)
{
m += "<tr>";
m += "<td>"
m += "<input class='form-check-input' type='checkbox' ";
m += " onclick='updateButtonVisibilities(\"ip_filter\",\"submit_ip_filter_changes\",\"cancel_ip_filter_changes\");' ";
m += " name='filter_" + index +".state' org_state='false'/>";
m += "</td>";
m += "<td>";
m += "<input type='text' size='64' maxlength='64' name='filter_"+index+".ip' org_value='"+ip+"' value='"+ip+"' ";
m += " onkeyup='updateButtonVisibilities(\"ip_filter\",\"submit_ip_filter_changes\",\"cancel_ip_filter_changes\");'/>";
m += "</td>";
m += "<td><table><tr><td><select class='form-control' name='filter_"+index+".action' org_value='"+action+"' onchange='updateButtonVisibilities(\"ip_filter\",\"submit_ip_filter_changes\",\"cancel_ip_filter_changes\");'>";
m += "<option value='ACCEPT'";
if(action=='ACCEPT')
{
m += " selected";
}
m += ">ACCEPT</option>";
m += "<option value='DROP'";
if(action=='DROP')
{
m += " selected";
}
m += ">DROP</option>";
m += "</select></td></tr></table></td>";
m += "</tr>";
definedFilters++;
}
}
if(definedFilters==0)
{
m += "<tr><td colspan='3'><i>No IP filters are defined</i></td></tr>";
}
m += "</table>";
d = document.getElementById('ip_filter_configuration');
if(d)d.innerHTML=m;
updateButtonVisibilities('ip_filter','submit_ip_filter_changes','cancel_ip_filter_changes');
document.getElementById("ip_filter").style.display = "block";
document.getElementById("new_ip_filter").reset();
document.getElementById("new_ip_filter").style.display = "block";
}
}
function SetGatewayConfigPortForwardingDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("gateway_portforwarding_list").style.display = "block";
document.getElementById("gateway_portforwarding_add").reset();
document.getElementById("gateway_portforwarding_add").style.display = "block";
}
function SetGatewayConfigPortForwardingRuleEditDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("gateway_portforwarding_edit").style.display = "block";
}
function SetGatewayConfigStaticRoutesDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("gateway_staticroutes_list").style.display = "block";
document.getElementById("gateway_staticroutes_add").reset();
var parentForm = document.getElementById('gateway_staticroutes_add');
parentForm.route_interface.length = 0;
var i = 0;
if(xml)
{
var interfaces = xml.getElementsByTagName("interfaces");
for(i = 0; interfaces && i < interfaces.length; ++i)
{
var interface = interfaces[i].firstChild.nodeValue;
parentForm.route_interface.options[i] = new Option(
interface, interface, false, false
);
}
}
document.getElementById("gateway_staticroutes_add").style.display = "block";
}
function SetGatewayConfigStaticRoutesEditDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("gateway_staticroutes_edit").style.display = "block";
}
