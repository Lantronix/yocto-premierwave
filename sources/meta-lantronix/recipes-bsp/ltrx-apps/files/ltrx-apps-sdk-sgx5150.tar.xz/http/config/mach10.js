function SetAdmin_MACH10Display()
{
var menu=document.getElementById('mach10_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('mach10_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function Mach10ErrorDisplay(xml)
{
if(! xml || ! xml.hasChildNodes())
{
return;
}
var message = GetXmlData(xml,"message");
var formatted = message.replace(/\n/g, "<br/>");
document.getElementById('mach10error').innerHTML=formatted;
}
function SetMach10Display(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Mach10.State');
SetDisplaySelection('Mach10.Active_Connection');
SetDisplaySelection('Mach10.Connection_1.Use_Proxy');
SetDisplaySelection('Mach10.Connection_1.Proxy_Type');
SetDisplaySelection('Mach10.Connection_1.Proxy_Host');
SetDisplaySelection('Mach10.Connection_1.Proxy_Port');
SetDisplaySelection('Mach10.Connection_1.Proxy_Username');
SetDisplaySelection('Mach10.Connection_1.Proxy_Password');
SetDisplaySelection('Mach10.Connection_1.Host');
SetDisplaySelection('Mach10.Connection_1.Connect_To');
SetDisplaySelection('Mach10.Connection_1.Port');
SetDisplaySelection('Mach10.Connection_1.Secure_Port');
SetDisplaySelection('Mach10.Connection_1.Validate_Certificates');
SetDisplaySelection('Mach10.Connection_1.Local_Port');
SetDisplaySelection('Mach10.Connection_1.MQTT_State');
SetDisplaySelection('Mach10.Connection_1.MQTT_Security');
SetDisplaySelection('Mach10.Connection_1.MQTT_Local_Port');
SetDisplaySelection('Mach10.Connection_2.Use_Proxy');
SetDisplaySelection('Mach10.Connection_2.Proxy_Type');
SetDisplaySelection('Mach10.Connection_2.Proxy_Host');
SetDisplaySelection('Mach10.Connection_2.Proxy_Port');
SetDisplaySelection('Mach10.Connection_2.Proxy_Username');
SetDisplaySelection('Mach10.Connection_2.Proxy_Password');
SetDisplaySelection('Mach10.Connection_2.Host');
SetDisplaySelection('Mach10.Connection_2.Connect_To');
SetDisplaySelection('Mach10.Connection_2.Port');
SetDisplaySelection('Mach10.Connection_2.Secure_Port');
SetDisplaySelection('Mach10.Connection_2.Validate_Certificates');
SetDisplaySelection('Mach10.Connection_2.Local_Port');
SetDisplaySelection('Mach10.Connection_2.MQTT_State');
SetDisplaySelection('Mach10.Connection_2.MQTT_Security');
SetDisplaySelection('Mach10.Connection_2.MQTT_Local_Port');
UpdateMach10Display(true);
SetDisplaySelection('Mach10.Device_ID');
SetDisplaySelection('Mach10.Device_Key');
SetDisplaySelection('Mach10.Device_Name');
SetDisplaySelection('Mach10.Device_Description');
SetDisplaySelection('Mach10.Status_Update_Interval');
SetDisplaySelection('Mach10.Content_Check_Interval');
SetDisplaySelection('Mach10.Apply_Firmware_Updates');
SetDisplaySelection('Mach10.Apply_Configuration_Updates');
SetDisplaySelection('Mach10.Reboot_After_Update');
SetDisplaySelection('Mach10.Audit_Log');
SetDisplaySelection('Mach10.Reboot_After_Firmware_Update');
SetDisplaySelection('Mach10.Allow_Remote_Connections');
SetDisplaySelection('Mach10.Remote_Access_Local_Port');
document.getElementById("mach10form").style.display = "block";
SetAdmin_MACH10Display();
}
function BuildMach10Html(xml)
{
}
function UpdateMach10Display(initial, optElement)
{
Update(optElement);
}
function SetMach10LineDisplay(xml)
{
var port = document.getElementById("hiddenmach10port").innerHTML;
var numSerialPorts = document.getElementById("numSerialPorts").innerHTML;
var numUSBPorts = document.getElementById("numUSBPorts").innerHTML;
var numBluetoothPorts = document.getElementById("numBluetoothPorts").innerHTML;
if(port<numSerialPorts)
{
document.getElementById("line_name").innerHTML = 'Line ' + (Number(port) + 1);
}
else if(port > numSerialPorts && port < numSerialPorts+numUSBPorts)
{
document.getElementById("line_name").innerHTML = 'USB ' + (Number(port)- Number(numSerialPorts) + 1);
}
else if(port > numSerialPorts+numUSBPorts && port < numSerialPorts+numUSBPorts+numBluetoothPorts)
{
document.getElementById("line_name").innerHTML = 'BluetoothSerial ' + (Number(port)- Number(numSerialPorts) - numUSBPorts + 1);
}
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Mach10.State');
SetDisplaySelection('Mach10.Project_Tag');
SetDisplaySelection('Mach10.Status_Update_Interval');
SetDisplaySelection('Mach10.Content_Check_Interval');
SetDisplaySelection('Mach10.Command_Delimiter');
SetDisplaySelection('Mach10.Local_Port');
document.getElementById("mach10form").style.display = "block";
SetAdmin_MACH10Display();
}
function Mach10Render(xml)
{
var numbluPorts = GetXmlData(xml, 'numBluetoothPorts');
var numserPorts = GetXmlData(xml, 'numSerialPorts');
var numusbPorts = GetXmlData(xml, 'numUSBPorts');
var port = GetXmlData(xml, 'port');
document.getElementById("hiddenmach10port").innerHTML = port;
document.getElementById("line_name").innerHTML = 'Line ' + (Number(port) + 1);
var d = document.getElementById("line_selection");
if(d && numserPorts > 4)
{
var r = "";
r += '<table id="Nav1" class="table table-striped table-condensed">';
r += "<tr>";
r += "<td align='right'><b>Select :</b></td>";
r += "<td align='left'>";
r += "<";
r += "select name='navSelect' class='form-control' style='width: 28%;' ";
r += "id='navSelect' ";
r += "onchange=";
r += " \" ";
r += "return ajax_AddToHistory('PercepxionLinePage', [true, 'portnumber='+this.value]);";
r += " \" ";
r += ">"
for(var i = 0; i < numserPorts; ++i)
{
var sel = (port == i ? " SELECTED " : "");
r += "<option value='" + i + "' " + sel + ">Line " + (i+1) +" </option>";
}
r += "</select>";
r += "</td>";
r += "</tr>";
r += "</table>";
d.innerHTML = r;
}
}
