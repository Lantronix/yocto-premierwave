function SetSocketsDisplay()
{
GetMessageDisplay('diag_ip_sockets',"ip_sockets",0);
GetMessageDisplay('diag_ip_sockets_protocol',"strings",124);
GetMessageDisplay('diag_ip_sockets_rxq',"ip_sockets",2);
GetMessageDisplay('diag_ip_sockets_txq',"ip_sockets",3);
GetMessageDisplay('diag_ip_sockets_localaddr_port',"ip_sockets",4);
GetMessageDisplay('diag_ip_sockets_remoteaddr_port',"ip_sockets",5);
GetMessageDisplay('diag_ip_sockets_state',"strings",46);
}
