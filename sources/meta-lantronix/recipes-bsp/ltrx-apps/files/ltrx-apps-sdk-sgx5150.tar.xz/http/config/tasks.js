function TaskHighlights(xml)
{
var tbl = document.getElementById('tasks');
var rows = tbl.getElementsByTagName('tr');
for(var i = 0; i < rows.length; ++i)
{
var task = rows[i].childNodes[5].innerHTML;
var cell = rows[i].childNodes[4];
var value = cell.innerHTML;
if(task == "Idle Task")
{
cell.style.fontWeight = 'bold';
}
else
{
if(value < 50)
{
cell.style.backgroundColor = '#CCFFCC';
}
else if(value < 75)
{
cell.style.backgroundColor = '#FFFF66';
}
else
{
cell.style.backgroundColor = '#FF4C00';
cell.style.fontWeight = 'bold';
}
}
}
}
function SetTasksDisplay()
{
GetMessageDisplay('diag_tasks',"tasks",0);
GetMessageDisplay('diag_tasks_name',"tasks",1);
GetMessageDisplay('diag_tasks_total_processor_load',"tasks",2);
}
