function SetSystemPage(xml)
{
GetMessageDisplay('system', "system", 16);
GetMessageDisplay('reboot', "system", 9);
document.getElementById('submit_reboot').value=GetMessage("strings", 6);
GetMessageDisplay('otaupgrade', "system", 28);
GetMessageDisplay('ota_firmware_ver', 'strings', 51);
document.getElementById('submit_otaUpgrade').value=GetMessage("strings", 171);
GetMessageDisplay('factory_defaults', "system", 10);
document.getElementById('submit_factory').value=GetMessage("system", 18);
GetMessageDisplay('system_firmware_upload', "system", 19);
document.getElementById('imageUploadButton').value=GetMessage("fs", 110);
GetMessageDisplay('name', "strings", 65);
GetMessageDisplay('short_name', "system", 11);
GetMessageDisplay('long_name', "system", 12);
document.getElementById('submit_name').value=GetMessage("strings", 7);
GetMessageDisplay('current_config', "strings", 40);
GetMessageDisplay('firmware_ver', "strings", 51);
GetMessageDisplay('current_conf_short_name', "system", 11);
GetMessageDisplay('current_conf_long_name', "system", 12);
}
function SystemUploadProgrammingFlashMessage()
{
FileSystemMonitorDisable();
PrintMsg(GetMessage("strings", 108),
"results"
);
}
function ConfirmReboot()
{
var msg = GetConfirmationMessage('strings',12);
bootbox.confirm(msg, function(result) {
if( result == true )
{
FileSystemMonitorDisable();
document.getElementById('formReboot').submit();
}
});
}
function ConfirmOtaUpgrade()
{
var msg = GetConfirmationMessage('strings',172) + "<br>" + GetConfirmationMessage('strings',180);
bootbox.confirm(msg, function(result) {
if(result==true)
{
document.getElementById('formOtaUpgrade').submit();
}
});
}
function ConfirmFactoryReset()
{
var msg = GetConfirmationMessage('system',14);
msg += '<br>';
msg += GetConfirmationMessage('system',23);
bootbox.confirm(msg, function(result) {
if(result==true)
{
document.getElementById('formFactoryDefaults').submit();
}
});
}
function ConfirmFirmwareUpload()
{
var msg = GetConfirmationMessage('system',8);
msg += '<br>';
msg += GetConfirmationMessage('system',23);
bootbox.confirm(msg, function(result) {
if(result==true)
{
document.getElementById('formImageUpload').submit();
FileSystemMonitor();
}
});
}
function UpdateRebootSchedule()
{
var submitButton=getFormElementById("scheduledreboot","btn_reboot_schedule");
var somethingChanged=false;
if(
(GetDivValueById("current_scheduled_reboot.State") != GetDisplayValue("new_scheduled_reboot.State")) ||
(GetDivValueById("current_scheduled_reboot.Schedule") != GetDisplayValue("new_scheduled_reboot.Schedule")) ||
(GetDivValueById("current_scheduled_reboot.Hours") != GetDisplayValue("new_scheduled_reboot.Hours")) ||
(GetDivValueById("current_scheduled_reboot.Minutes") != GetDisplayValue("new_scheduled_reboot.Minutes")) ||
(GetDivValueById("current_scheduled_reboot.Interval") != GetDisplayValue("new_scheduled_reboot.Interval")) ||
(GetDivValueById("current_scheduled_reboot.Unit") != GetDisplayValue("new_scheduled_reboot.Unit"))
)
{
somethingChanged=true;
}
submitButton.disabled=false;
submitButton.style.visibility=somethingChanged?"visible":"hidden";
submitButton.style.display=somethingChanged?"block":"none";
var type = GetDisplayValue("new_scheduled_reboot.Schedule");
document.getElementById("scheduled_reboot_time").style.display= (type=="Daily")?'':'none';
document.getElementById("scheduled_reboot_interval").style.display= (type=="Interval")?'':'none';
}
function SetRebootScheduleDisplay(xml)
{
var submitButton=getFormElementById("scheduledreboot","btn_reboot_schedule");
submitButton.disabled=false;
submitButton.style.visibility="hidden";
submitButton.style.display="none";
SetDisplayValue("new_scheduled_reboot.State", GetDivValueById("current_scheduled_reboot.State"));
SetDisplayValue("new_scheduled_reboot.Schedule", GetDivValueById("current_scheduled_reboot.Schedule"));
SetDisplayValue("new_scheduled_reboot.Hours", GetDivValueById("current_scheduled_reboot.Hours"));
SetDisplayValue("new_scheduled_reboot.Minutes", GetDivValueById("current_scheduled_reboot.Minutes"));
SetDisplayValue("new_scheduled_reboot.Interval", GetDivValueById("current_scheduled_reboot.Interval"));
SetDisplayValue("new_scheduled_reboot.Unit", GetDivValueById("current_scheduled_reboot.Unit"));
UpdateRebootSchedule();
}
function UpdateResetButtonState()
{
var submitButton=getFormElementById("external_buttons_form","submit_external_buttons");
var somethingChanged=false;
if(GetDivValueById("current_CPFunctions.Reset_to_Factory_Defaults_CP") != GetDisplayValue("new_CPFunctions.Reset_to_Factory_Defaults_CP"))
{
somethingChanged=true;
}
submitButton.disabled=false;
submitButton.style.visibility=somethingChanged?"visible":"hidden";
submitButton.style.display=somethingChanged?"block":"none";
}
function SetResetButtonDisplay(xml)
{
var submitButton=getFormElementById("external_buttons_form","submit_external_buttons");
submitButton.disabled=false;
submitButton.style.visibility="hidden";
submitButton.style.display="none";
SetDisplayValue("new_CPFunctions.Reset_to_Factory_Defaults_CP", GetDivValueById("current_CPFunctions.Reset_to_Factory_Defaults_CP"));
SetDisplayValue("new_CPFunctions.WPS_PushButton_CP", GetDivValueById("current_CPFunctions.WPS_PushButton_CP"));
UpdateResetButtonState();
}
function SetFirmwareUpdateDisplay(xml)
{
if(xml && xml.hasChildNodes())
{
var ota_installed = GetXmlData(xml,"ota_installed");
if(ota_installed != "true")
{
document.getElementById('submit_otaUpgrade').disabled=true;
}
var firmware_update = GetXmlData(xml,"firmware_update");
if(firmware_update != "true")
{
document.getElementById('firmware_update_section').style.visibility='hidden';
document.getElementById('firmware_update_section').style.display='none';
}
var device_reboot = GetXmlData(xml, "device_reboot");
if(device_reboot != "true")
{
document.getElementById('device_reboot_section').style.visibility='hidden';
document.getElementById('device_reboot_section').style.display='none';
}
var factory_reset = GetXmlData(xml, "factory_reset");
if(factory_reset != "true")
{
document.getElementById('factory_reset_section').style.visibility='hidden';
document.getElementById('factory_reset_section').style.display='none';
}
var reboot_schedule = GetXmlData(xml, "reboot_schedule");
if(reboot_schedule != "true")
{
document.getElementById('reboot_schedule_section').style.visibility='hidden';
document.getElementById('reboot_schedule_section').style.display='none';
}
var device_group = GetXmlData(xml, "device_group");
if(device_group != "true")
{
document.getElementById('device_group_section').style.visibility='hidden';
document.getElementById('device_group_section').style.display='none';
}
}
}
function SetSystemPageDisplay(xml)
{
if(xml && xml.hasChildNodes())
{
}
SetRebootScheduleDisplay()
SetResetButtonDisplay(xml);
SetFirmwareUpdateDisplay(xml);
}
