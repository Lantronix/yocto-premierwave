function confirmGenerateCertificate()
{
var n = document.getElementById('sslcredentialname').innerHTML;
var f = document.getElementById('sslform');
var t = GetInputElementValue(f.elements['keytype']);
var b = GetInputElementValue(f.elements['bits']);
if(t=="ECDSA")
{
b = GetInputElementValue(f.elements['curve_bits']);
}
var time = document.getElementById('ssl_time' + t + b + 'bit').innerHTML;
var args = [t,b,time];
var msg=GetConfirmationMessage('ssl',81,args);
if(time != '')
{
bootbox.confirm(msg, function(result) {
if(result==true)
{
ajax_SslGenerateCertificate(
[
true,
(
ajaxGetFormValuesWithoutClearingThem(
'sslform'
) +
'&sslcredentialname=' + n
)
]
);
}
});
}
else
{
ajax_SslGenerateCertificate(
[
true,
(
ajaxGetFormValuesWithoutClearingThem(
'sslform'
) +
'&sslcredentialname=' + n
)
]
);
}
}
function confirmGenerateCSR()
{
ajax_SslGenerateCSR(
[
true,
(
ajaxGetFormValuesWithoutClearingThem(
'csrform'
)
)
]
);
}
function CSRSetDownloadLinks(xml)
{
document.getElementById("csr_output").style.display="none";
{
var d = document.getElementById('delele_csr');
var r = "<a href=\"javascript:void(0)\" onclick=\"bootbox.confirm(GetConfirmationMessage('strings',41), function(result) {";
r += "if(result==true){ajax_SslCSRCleanDownloadLink([true, '']);}});return false;\"><img src=\"/remove.gif\" /></a>&nbsp;"
r += "<b>"+GetMessage("strings",42)+"</b>";
d.innerHTML=r;
}
{
var d = document.getElementById('csr_cert');
var r = '';
if(xml)
{
var backup=xml.getElementsByTagName("csr_cert");
if(backup && backup.length>0)
{
var backup_value=backup[0].firstChild.nodeValue;
r = "<img src=\"/file.gif\" />&nbsp;";
r += "<a download='csr.pem' href=\"/fs?file=";
r += encodeURIComponent(backup_value);
r += "\" target=\"_blank\">"+GetMessage("ssl",147)+"</a>";
var backup_size=xml.getElementsByTagName("csr_cert_size");
if(backup_size && backup_size.length>0)
{
var backup_size_value=backup_size[0].firstChild.nodeValue;
r += "</br>(" + backup_size_value + ")";
}
var subject=xml.getElementsByTagName("csr_subject");
if(subject && subject.length>0)
{
var backup_size_value=subject[0].firstChild.nodeValue;
r += "</br><b>" + GetMessage("ssl",89) + ":&nbsp;</b>" + backup_size_value + "";
}
var algorithm=xml.getElementsByTagName("csr_algorithm");
if(algorithm && algorithm.length>0)
{
var backup_size_value=algorithm[0].firstChild.nodeValue;
r += "</br><b>" + GetMessage("ssl",84) + ":&nbsp;</b>" + backup_size_value + "";
}
document.getElementById("csr_output").style.display="";
}
}
d.innerHTML=r;
}
{
var d = document.getElementById('csr_key');
var r = '';
if(xml)
{
var backup=xml.getElementsByTagName("csr_key");
if(backup && backup.length>0)
{
var backup_value=backup[0].firstChild.nodeValue;
r = "<img src=\"/file.gif\" />&nbsp;";
r += "<a download='private_key.pem' href=\"/fs?file=";
r += encodeURIComponent(backup_value);
r += "\" target=\"_blank\">"+GetMessage("ssl",65)+"</a>";
var backup_size=xml.getElementsByTagName("csr_key_size");
if(backup_size && backup_size.length>0)
{
var backup_size_value=backup_size[0].firstChild.nodeValue;
r += "</br>(" + backup_size_value + ")";
}
var bits=xml.getElementsByTagName("csr_key_bits");
if(bits && bits.length>0)
{
var backup_size_value=bits[0].firstChild.nodeValue;
r += "</br><b>" + GetMessage("ssl",75) + ":&nbsp;</b>" + backup_size_value + "";
}
}
}
d.innerHTML=r;
}
}
function SetAdmin_SSLDisplay()
{
var menu=document.getElementById('ssl_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('ssl_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function SslCertRender(xml)
{
var n = document.getElementById('sslcredentialname').innerHTML;
var d = document.getElementById(GetXmlData(xml, "type"));
d.innerHTML = '';
r = "<table class=\"table table-striped table-condensed\">";
r += "<tr><td><b>"+GetMessage("strings",52)+":</b></td><td>" + GetXmlData(xml, "type");
r += "&nbsp;&nbsp;<a href='javascript:void(0)' class='btn btn-primary btn-sm'";
r += " onclick=\"";
r += "bootbox.confirm('"+GetConfirmationMessage("strings", 41)+"',function(result){if(result==true){";
r += "ajax_SslCertClean([false, 'delete";
r += GetXmlData(xml, "type") + "cert', '" + n + "']);}});return false;\"";
r += ">"+GetMessage("strings",42)+"</a>";
r += "</td></tr>";
r += "<tr><td><b>"+GetMessage("ssl",83)+":</b></td><td>" + GetXmlData(xml, "vers") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("strings",104)+":</b></td><td style=\"font-family: monospace;\">" + GetXmlData(xml, "ser") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("ssl",84)+":</b></td><td>" + GetXmlData(xml, "alg") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("ssl",85)+":</b></td><td>";
r += "<b>C:</b> " + GetXmlData(xml, "ic") + "<br/>";
r += "<b>ST:</b> " + GetXmlData(xml, "ist") + "<br/>";
r += "<b>L:</b> " + GetXmlData(xml, "il") + "<br/>";
r += "<b>O:</b> " + GetXmlData(xml, "io") + "<br/>";
r += "<b>OU:</b> " + GetXmlData(xml, "iou") + "<br/>";
var issuer_dcnum=parseInt(GetXmlData(xml,"issuer_dcnum"));
for(var j=0;j<issuer_dcnum;j++)
{
r += "<b>DC:</b> " + GetXmlData(xml, "issuer_dc_"+j) + "<br/>";
}
r += "<b>CN:</b> " + GetXmlData(xml, "icn") + "<br/>";
r += "</td></tr> ";
r += "<tr><td><b>"+GetMessage("ssl",86)+":</b></td><td>";
r += "<b>"+GetMessage("ssl",87)+":</b> " + GetXmlData(xml, "vi") + "<br/>";
r += "<b>"+GetMessage("ssl",88)+":</b> " + GetXmlData(xml, "ve") + "<br/>";
r += "</td></tr>";
r += "<tr><td><b>"+GetMessage("ssl",89)+":</b></td><td>";
r += "<b>C:</b> " + GetXmlData(xml, "sc") + "<br/>";
r += "<b>ST:</b> " + GetXmlData(xml, "sst") + "<br/>";
r += "<b>L:</b> " + GetXmlData(xml, "sl") + "<br/>";
r += "<b>O:</b> " + GetXmlData(xml, "so") + "<br/>";
r += "<b>OU:</b> " + GetXmlData(xml, "sou") + "<br/>";
var subject_dcnum=parseInt(GetXmlData(xml,"subject_dcnum"));
for(var j=0;j<subject_dcnum;j++)
{
r += "<b>DC:</b> " + GetXmlData(xml, "subject_dc_"+j) + "<br/>";
}
r += "<b>CN:</b> " + GetXmlData(xml, "scn") + "<br/>";
r += "</td></tr> ";
r += "<tr><td><b>"+GetMessage("ssl",90)+":</b></td><td style=\"font-family: monospace;\">";
r += GetXmlData(xml, "keyb") + "<br/>";
r += GetXmlData(xml, "keyd");
r += "</td></tr> ";
r += "</table> ";
d.innerHTML = r;
}
function SslRender(xml)
{
var d = document.getElementById('expires');
if(d)
{
d.value = GetXmlData(xml, "expiration_date");
}
}
function SslShowDeleteAll(xml)
{
document.getElementById('delete_all').style.visibility = "visible";
document.getElementById('delete_all').style.display = "block";
}
function SslHideDeleteAll(xml)
{
document.getElementById('delete_all').style.visibility = "hidden";
document.getElementById('delete_all').style.display = "none";
}
function SslTrustedCaCertRender(xml)
{
GetMessageDisplay('current_cert_auth',"ssl",124);
GetMessageDisplay('ssl_ca_delete_all',"strings",168);
GetMessageDisplay('upload_auth_cert',"ssl",125);
GetMessageDisplay('auth',"ssl",92);
GetMessageDisplay('auth_cert_type',"ssl",64);
GetMessageDisplay('pfx_password',"strings",90);
GetMessageDisplay('str_show_cert_passw',"strings",136);
document.getElementById('sslcapasswd').type=(document.getElementById('show_cert_pass').checked?'text':'password');
document.getElementById('submit_button').value=GetMessage("strings",7);
var d = document.getElementById('ssltrustedcadata');
if(GetXmlData(xml, "clear") == "true")
{
d.innerHTML = "";
document.getElementById('sslintercadata').innerHTML = "";
}
else
{
r = "<table class=\"table table-striped table-condensed\"><tr>";
r += "<td width=25%><b>"+GetMessage("ssl", 91)+"<br/>"+GetMessage("ssl",92)+"</b><br/>";
r += "<a href='javascript:void(0)' class='btn btn-primary btn-sm'";
r += " onclick=\"";
r += "bootbox.confirm('"+GetConfirmationMessage("ssl",156)+"<br/>"+GetConfirmationMessage("strings",41)+"',function(result){if(result==true){";
r += "ajax_SslCertClean([false, 'deletessltca', '" + GetXmlData(xml, "i") + "']);}});return false;\"";
r += ">"+GetMessage("strings",42)+"</a>";
r += "</td><td>";
var errors=parseInt(GetXmlData(xml,"errors"));
for(var j=0;j<errors;j++)
{
var error=parseInt(GetXmlData(xml,"error_"+j));
var str_error="";
switch(error)
{
case -1:
str_error=GetMessage('ssl',159,[""]);
break;
case -2:
str_error=GetMessage('ssl',160,[""]);
break;
case 2:
str_error=GetMessage('ssl',141,[""]);
break;
case 20:
str_error=GetMessage('ssl',142,[""]);
break;
case 18:
str_error=GetMessage('ssl',145,[""]);
break;
case 9:
str_error=GetMessage('ssl',143,[""]);
break;
case 10:
str_error=GetMessage('ssl',144,[""]);
break;
default:
str_error=GetMessage('ssl',146,[""]);
break;
}
if(str_error!="")
{
r += "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>";
r += "&nbsp;<div style='color:red'>" + str_error + "</div>";
}
}
r += "<b>C:</b> " + GetXmlData(xml, "sc") + "<br/>";
r += "<b>ST:</b> " + GetXmlData(xml, "sst") + "<br/>";
r += "<b>L:</b> " + GetXmlData(xml, "sl") + "<br/>";
r += "<b>O:</b> " + GetXmlData(xml, "so") + "<br/>";
r += "<b>OU:</b> " + GetXmlData(xml, "sou") + "<br/>";
var subject_dcnum=parseInt(GetXmlData(xml,"subject_dcnum"));
for(var j=0;j<subject_dcnum;j++)
{
r += "<b>DC:</b> " + GetXmlData(xml, "subject_dc_"+j) + "<br/>";
}
r += "<b>CN:</b> " + GetXmlData(xml, "scn") + "<br/>";
r += "<b>"+GetMessage("ssl",87)+":</b> " + GetXmlData(xml, "svi") + "<br/>";
r += "<b>"+GetMessage("ssl",88)+":</b> " + GetXmlData(xml, "sve") + "<br/>";
r += "</td></tr> ";
r += "</table> ";
d.innerHTML += r;
}
}
function SslIntermediateCaCertRender(xml)
{
var d = document.getElementById('sslintercadata');
if(GetXmlData(xml, "clear") == "true")
{
d.innerHTML = "";
document.getElementById('sslintercadata').innerHTML = "";
}
else
{
r = "<table class=\"table table-striped table-condensed\"><tr>";
r += "<td width=25%><b>"+GetMessage("ssl", 93)+"<br/>"+GetMessage("ssl",92)+"</b><br/>";
r += "<a href='javascript:void(0)' class='btn btn-primary btn-sm'";
r += " onclick=\"";
r += "bootbox.confirm('"+GetConfirmationMessage("ssl",156)+"<br/>"+GetConfirmationMessage("strings",41)+"',function(result){if(result==true){";
r += "ajax_SslCertClean([false, 'deletesslica', '" + GetXmlData(xml, "i") + "']);}});return false;\"";
r += ">"+GetMessage("strings",42)+"</a>";
r += "</td><td>";
var errors=parseInt(GetXmlData(xml,"errors"));
r += "<table>";
for(var j=0;j<errors;j++)
{
r += "<tr>";
var error=parseInt(GetXmlData(xml,"error_"+j));
var str_error="";
switch(error)
{
case 2:
str_error=GetMessage('ssl',141,[""]);
break;
case 20:
str_error=GetMessage('ssl',142,[""]);
break;
case 18:
str_error=GetMessage('ssl',145,[""]);
break;
case 9:
str_error=GetMessage('ssl',143,[""]);
break;
case 10:
str_error=GetMessage('ssl',144,[""]);
break;
default:
str_error=GetMessage('ssl',146,[""]);
break;
}
if(str_error!="")
{
r += "<td><span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span></td>";
r += "<td>&nbsp;<div style='color:red'>" + str_error + "</div></td>";
}
r += "</tr>";
}
r += "</table>";
r += "<b>C:</b> " + GetXmlData(xml, "sc") + "<br/>";
r += "<b>ST:</b> " + GetXmlData(xml, "sst") + "<br/>";
r += "<b>L:</b> " + GetXmlData(xml, "sl") + "<br/>";
r += "<b>O:</b> " + GetXmlData(xml, "so") + "<br/>";
r += "<b>OU:</b> " + GetXmlData(xml, "sou") + "<br/>";
var subject_dcnum=parseInt(GetXmlData(xml,"subject_dcnum"));
for(var j=0;j<subject_dcnum;j++)
{
r += "<b>DC:</b> " + GetXmlData(xml, "subject_dc_"+j) + "<br/>";
}
r += "<b>CN:</b> " + GetXmlData(xml, "scn") + "<br/>";
r += "<b>"+GetMessage("ssl",87)+":</b> " + GetXmlData(xml, "svi") + "<br/>";
r += "<b>"+GetMessage("ssl",88)+":</b> " + GetXmlData(xml, "sve") + "<br/>";
r += "<br/><b>"+GetMessage("ssl",94)+":</b><br/>";
r += "<b>C:</b> " + GetXmlData(xml, "isc") + "<br/>";
r += "<b>ST:</b> " + GetXmlData(xml, "isst") + "<br/>";
r += "<b>L:</b> " + GetXmlData(xml, "isl") + "<br/>";
r += "<b>O:</b> " + GetXmlData(xml, "iso") + "<br/>";
r += "<b>OU:</b> " + GetXmlData(xml, "isou") + "<br/>";
var issuer_dcnum=parseInt(GetXmlData(xml,"issuer_dcnum"));
for(var j=0;j<issuer_dcnum;j++)
{
r += "<b>DC:</b> " + GetXmlData(xml, "issuer_dc_"+j) + "<br/>";
}
r += "<b>CN:</b> " + GetXmlData(xml, "iscn") + "<br/>";
r += "</td></tr> ";
r += "</table> ";
d.innerHTML += r;
}
}
function SslUploadClearForm(xml)
{
document.getElementById("sslpostform").reset();
document.getElementById("pfxcert").style.display = "none";
document.getElementById("pfxkey").style.display = "none";
}
function SslPasswordClearForm(xml)
{
document.getElementById("sslcertpasswd").value = "";
document.getElementById("sslkeypasswd").value = "";
}
function SslFromTypeChanged(fromType)
{
var id = fromType.id;
if(id == "sslcacerttypefrom")
{
if(fromType.value == "pkcs12")
{
document.getElementById("pfxca").style.display = "";
}
else
{
document.getElementById("pfxca").style.display = "none";
}
}
if(id == "sslcerttypefrom")
{
if(fromType.value == "pkcs12")
{
document.getElementById("pfxcert").style.display = "";
}
else
{
document.getElementById("pfxcert").style.display = "none";
}
}
if(id == "sslkeytypefrom")
{
document.getElementById("pfxkey").style.display = "none";
if(fromType.value == "pkcs12")
{
document.getElementById("pfxkey").style.display = "";
}
if(fromType.value == "encrypted-pem")
{
document.getElementById("pfxkey").style.display = "";
}
}
}
function SslTrustedAuthUploadClearForm(xml)
{
document.getElementById("sslcapostform").reset();
document.getElementById("pfxca").style.display = "none";
}
function sslTrustedPasswordClearForm(xml)
{
document.getElementById("sslcapasswd").value = "";
}
function SslCreateCSRClearForm()
{
ajaxClearFormValues("csrform");
GetMessageDisplay('create_selfsigned_cert',"ssl",147);
GetMessageDisplay('country_code',"ssl",67);
GetMessageDisplay('province',"ssl",68);
GetMessageDisplay('locality',"ssl",69);
GetMessageDisplay('organization',"ssl",70);
GetMessageDisplay('ou_unit',"ssl",71);
GetMessageDisplay('common_name',"ssl",72);
GetMessageDisplay('key_length',"ssl",75);
GetMessageDisplay('2048_bit',"ssl",79);
GetMessageDisplay('4096_bit',"ssl",80);
document.getElementById('submit_cred').value=GetMessage("strings", 7);
document.getElementById("csr_output").style.display="none";
}
function SslCSRRender()
{
document.getElementById("csr_output").style.display="";
}
function SslCreateClearForm()
{
ajaxClearFormValues("sslform");
GetMessageDisplay('ssl_credential',"ssl", 61);
GetMessageDisplay('upload_cert',"ssl", 62);
GetMessageDisplay('new_cerificate',"ssl", 63);
GetMessageDisplay('new_cert_type',"ssl",64);
GetMessageDisplay('pfx_passwd',"strings",90);
GetMessageDisplay('str_show_cert_passw',"strings",136);
GetMessageDisplay('new_private_key',"ssl", 65);
GetMessageDisplay('new_key_type',"ssl",66);
GetMessageDisplay('key_passwd',"strings",90);
GetMessageDisplay('str_show_key_passw',"strings",136);
document.getElementById('submit_button').value=GetMessage("strings", 7);
GetMessageDisplay('create_selfsigned_cert',"ssl",123);
GetMessageDisplay('country_code',"ssl",67);
GetMessageDisplay('provinence',"ssl",68);
GetMessageDisplay('locality',"ssl",69);
GetMessageDisplay('organization',"ssl",70);
GetMessageDisplay('ou_unit',"ssl",71);
GetMessageDisplay('common_name',"ssl",72);
GetMessageDisplay('date_expiry',"ssl",73);
GetMessageDisplay('mm_dd_yyyy',"ssl",74);
GetMessageDisplay('type',"strings",52);
GetMessageDisplay('key_length',"ssl",75);
GetMessageDisplay('512_bit',"ssl",76);
GetMessageDisplay('768_bit',"ssl",77);
GetMessageDisplay('1024_bit',"ssl",78);
document.getElementById('submit_cred').value=GetMessage("strings", 7);
GetMessageDisplay('2048_bit',"ssl",79);
GetMessageDisplay('4096_bit',"ssl",80);
SetFxDisplay('2048bits_Display','',true);
SetFxDisplay('4096bits_Display','',true);
}
function SslCredentialChoicesRender(xml)
{
GetMessageDisplay('ssl_creds',"ssl",59);
GetMessageDisplay('create_new_cred',"ssl",60);
document.getElementById('submit_button').value=GetMessage("strings", 7);
var d = document.getElementById('sslcredentialtable');
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>"+GetMessage("ssl",95)+".</p>";
}
else
{
r += "<table class='table table-striped table-condensed'>";
r += '<thead><tr>';
r += '<td><b>'+GetMessage("strings",44)+':</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
r += '<td><b>'+GetMessage("strings",42)+':</b></td>';
r += '</tr></thead><tbody>';
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "c")
{
var name = GetXmlData(node, "n");
r += "<tr>";
r += "<td>";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "ajax_AddToHistory(";
r += "'SslCredentialPage',";
r += "[true, 'sslcredentialname=" + name + "']";
r += ");";
r += "return false;";
r += "\"";
r += ">";
r += '<img class="fsimage" src="/file.gif" />';
r += "</a>";
r += "&nbsp;";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "ajax_AddToHistory(";
r += "'SslCredentialPage',";
r += "[true, 'sslcredentialname=" + name + "']";
r += ");";
r += "return false;";
r += "\"";
r += ">";
r += name;
r += "</a>";
r += "&nbsp;&nbsp;&nbsp;&nbsp;";
r += "<br>";
var errors=parseInt(GetXmlData(node,"rsa_errors"));
r += "<table>";
for(var j=0;j<errors;j++)
{
var error=parseInt(GetXmlData(node,"rsa_error_"+j));
var str_error="";
switch(error)
{
case -1:
str_error=GetMessage('ssl',159,["RSA"]);
break;
case -2:
str_error=GetMessage('ssl',160,["RSA"]);
break;
case 2:
str_error=GetMessage('ssl',141,["RSA"]);
break;
case 20:
str_error=GetMessage('ssl',142,["RSA"]);
break;
case 18:
str_error=GetMessage('ssl',145,["RSA"]);
break;
case 9:
str_error=GetMessage('ssl',143,["RSA"]);
break;
case 10:
str_error=GetMessage('ssl',144,["RSA"]);
break;
default:
str_error=GetMessage('ssl',146,["RSA"]);
break;
}
if(str_error!="")
{
r += "<tr>";
r += "<td><span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span></td>";
r += "<td>&nbsp;<div style='color:red'>" + str_error + "</div></td>";
r += "</tr>";
}
}
errors=parseInt(GetXmlData(node,"dsa_errors"));
for(var j=0;j<errors;j++)
{
var error=parseInt(GetXmlData(node,"dsa_error_"+j));
var str_error="";
switch(error)
{
case -1:
str_error=GetMessage('ssl',159,["DSA"]);
break;
case -2:
str_error=GetMessage('ssl',160,["DSA"]);
break;
case 2:
str_error=GetMessage('ssl',141,["DSA"]);
break;
case 20:
str_error=GetMessage('ssl',142,["DSA"]);
break;
case 18:
str_error=GetMessage('ssl',145,["DSA"]);
break;
case 9:
str_error=GetMessage('ssl',143,["DSA"]);
break;
case 10:
str_error=GetMessage('ssl',144,["DSA"]);
break;
default:
str_error=GetMessage('ssl',146,["DSA"]);
break;
}
if(str_error!="")
{
r += "<tr>";
r += "<td><span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span></td>";
r += "<td>&nbsp;<div style='color:red'>" + str_error + "</div></td>";
r += "</tr>";
}
}
errors=parseInt(GetXmlData(node,"ecdsa_errors"));
for(var j=0;j<errors;j++)
{
var error=parseInt(GetXmlData(node,"ecdsa_error_"+j));
var str_error="";
switch(error)
{
case -1:
str_error=GetMessage('ssl',159,["ECDSA"]);
break;
case -2:
str_error=GetMessage('ssl',160,["ECDSA"]);
break;
case 2:
str_error=GetMessage('ssl',141,["ECDSA"]);
break;
case 20:
str_error=GetMessage('ssl',142,["ECDSA"]);
break;
case 18:
str_error=GetMessage('ssl',145,["ECDSA"]);
break;
case 9:
str_error=GetMessage('ssl',143,["ECDSA"]);
break;
case 10:
str_error=GetMessage('ssl',144,["ECDSA"]);
break;
default:
str_error=GetMessage('ssl',146,["ECDSA"]);
break;
}
if(str_error!="")
{
r += "<tr>";
r += "<td><span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span></td>";
r += "<td>&nbsp;<div style='color:red'>" + str_error + "</div></td>";
r += "</tr>";
}
}
r += "</table>";
r += "</td>";
r += "<td>";
r += "<a href='javascript:void(0)'";
r += " onclick=\"";
r += "var args = ['"+name+"'];var msg=GetConfirmationMessage('ssl',96,args);bootbox.confirm(msg,function(result){if(result==true){";
r += "ajax_SslCredentialClean([true, 'sslcredentialname="+name+"']);}});return false;\"";
r += ">";
r += '<img class="fsimage" src="/remove.gif" />';
r += "</a>";
r += "</td>";
r += "</tr>";
}
}
r += "</tbody></table>";
}
d.innerHTML = r;
}
function SslNavigationDisplay()
{
GetMessageDisplay('cred',"strings",43);
GetMessageDisplay('trusted_auth',"strings",57);
GetMessageDisplay('csr',"ssl",147);
}
