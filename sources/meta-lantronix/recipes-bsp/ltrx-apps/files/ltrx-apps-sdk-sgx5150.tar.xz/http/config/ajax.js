window.ajaxHistory =
{
storageHash: new Object(),
currentLocation: null,
listener: null,
iframe: null,
ignoreLocationChange: null,
WAIT_TIME: 200,
currentWaitTime: 0,
fireOnNewListener: null,
firstLoad: null,
ieAtomicLocationChange: null,
ieHackPage: null,
isInternetExplorer: function()
{
return (document.all && (navigator.userAgent.toLowerCase().indexOf('msie') != -1)) ? true : false;
},
isFirstLoad: function()
{
return (this.firstLoad == true) ? true : false;
},
removeHash: function(hashValue)
{
if ((hashValue == null) || (hashValue == undefined))
{
return null;
}
else if ((hashValue == "") ||
((hashValue.length == 1) && (hashValue.charAt(0) == "#")))
{
return "";
}
else if ((hashValue.length > 1) && (hashValue.charAt(0) == "#"))
{
return hashValue.substring(1);
}
else
{
return hashValue;
}
},
getCurrentData: function()
{
return this.storageHash[this.getCurrentLocation()];
},
getCurrentLocation: function()
{
return this.removeHash(window.location.hash);
},
create: function()
{
var initialHash = this.getCurrentLocation();
this.currentLocation = initialHash;
if (this.isInternetExplorer())
{
document.write("<iframe style='border: 0px; width: 1px; "
+ "height: 1px; position: absolute; bottom: 0px; "
+ "right: 0px; visibility: visible;' "
+ "name='ajaxHistoryFrame' id='ajaxHistoryFrame' "
+ "src='" + this.ieHackPage + "?" + initialHash + "'>"
+ "</iframe>");
this.WAIT_TIME = 400;
}
var self = this;
window.onunload = function()
{
self.firstLoad = null;
};
if (this.isInternetExplorer() == false)
{
if (!this.storageHash["ajaxHistory_pageLoaded"])
{
this.ignoreLocationChange = true;
this.firstLoad = true;
this.storageHash["ajaxHistory_pageLoaded"] = true;
}
else
{
this.ignoreLocationChange = false;
this.fireOnNewListener = true;
}
}
else
{
this.ignoreLocationChange = true;
}
if (this.isInternetExplorer())
{
this.iframe = document.getElementById("ajaxHistoryFrame");
}
var self = this;
var locationHandler = function()
{
self.checkLocation();
};
setInterval(locationHandler, 100);
},
fireHistoryEvent: function(newHash)
{
this.listener.call(null, newHash, this.storageHash[newHash]);
},
checkLocation: function()
{
if ((this.isInternetExplorer() == false) &&
(this.ignoreLocationChange == true))
{
this.ignoreLocationChange = false;
return;
}
if ((this.isInternetExplorer() == false) &&
(this.ieAtomicLocationChange == true))
{
return;
}
var hash = this.getCurrentLocation();
if (hash == this.currentLocation)
{
return;
}
this.ieAtomicLocationChange = true;
if (this.isInternetExplorer() && (this.getIFrameHash() != hash))
{
this.iframe.src = this.ieHackPage + "?" + hash;
}
else if (this.isInternetExplorer())
{
return;
}
this.currentLocation = hash;
this.ieAtomicLocationChange = false;
this.fireHistoryEvent(hash);
},
getIFrameHash: function()
{
var historyFrame = document.getElementById("ajaxHistoryFrame");
var doc = historyFrame.contentWindow.document;
var hash = new String(doc.location.search);
if ((hash.length == 1) && (hash.charAt(0) == "?"))
{
hash = "";
}
else if ((hash.length >= 2) && (hash.charAt(0) == "?"))
{
hash = hash.substring(1);
}
return hash;
},
iframeLoaded: function(newLocation)
{
if (this.ignoreLocationChange == true)
{
this.ignoreLocationChange = false;
return;
}
var hash = new String(newLocation.search);
if ((hash.length == 1) && (hash.charAt(0) == "?"))
{
hash = "";
}
else if ((hash.length >= 2) && (hash.charAt(0) == "?"))
{
hash = hash.substring(1);
}
if (this.pageLoadEvent != true)
{
window.location.hash = hash;
}
this.fireHistoryEvent(hash);
},
initialize: function(ieHackPage)
{
this.ieHackPage = ieHackPage;
if (this.isInternetExplorer() == false)
{
return;
}
if (!this.storageHash["ajaxHistory_pageLoaded"])
{
this.fireOnNewListener = false;
this.firstLoad = true;
this.storageHash["ajaxHistory_pageLoaded"] = true;
}
else
{
this.fireOnNewListener = true;
this.firstLoad = false;
}
},
addListener: function(callback)
{
this.listener = callback;
if (this.fireOnNewListener == true)
{
this.fireHistoryEvent(this.currentLocation);
this.fireOnNewListener = false;
}
},
add: function(newLocation, historyData)
{
var self = this;
var addImpl = function()
{
if (self.currentWaitTime > 0)
{
self.currentWaitTime = self.currentWaitTime - self.WAIT_TIME;
}
newLocation = self.removeHash(newLocation);
var idCheck = document.getElementById(newLocation);
if ((idCheck != undefined) || (idCheck != null))
{
var message = "ERROR: History locations can not have the same value as any ID's that might be in the document. The following ID has a conflict: " + newLocation;
throw message;
}
self.storageHash[newLocation] = historyData;
self.ignoreLocationChange = true;
self.ieAtomicLocationChange = true;
self.currentLocation = newLocation;
window.location.hash = newLocation;
if (self.isInternetExplorer())
{
self.iframe.src = self.ieHackPage + "?" + newLocation;
}
self.ieAtomicLocationChange = false;
};
window.setTimeout(addImpl, this.currentWaitTime);
this.currentWaitTime = this.currentWaitTime + this.WAIT_TIME;
}
};
window.ajaxHistory.create();
var postData;
function Ajax()
{
this.workId = 'ajaxWork' + new Date().getTime();
this.depth = 0;
this.TARGET = 0;
this.ATTR = 1;
this.DATA = 2;
this.SEARCH = 3;
this.TYPE = 4;
this.MAX = (this.TYPE + 1);
this.windowWidth = 0;
this.windowHeight = 0;
this.windowSize = function()
{
if (typeof(window.innerWidth) == 'number')
{
this.windowWidth = window.innerWidth;
this.windowHeight = window.innerHeight;
}
else if (document.documentElement &&
(document.documentElement.clientWidth ||
document.documentElement.clientHeight))
{
this.windowWidth = document.documentElement.clientWidth;
this.windowHeight = document.documentElement.clientHeight;
}
else if (document.body &&
(document.body.clientWidth ||
document.body.clientHeight))
{
this.windowWidth = document.body.clientWidth;
this.windowHeight = document.body.clientHeight;
}
}
this.getRequestObject = function()
{
var xmlreq = false;
if (window.XMLHttpRequest)
{
xmlreq = new XMLHttpRequest();
if (xmlreq.overrideMimeType)
{
xmlreq.overrideMimeType('text/xml');
}
}
else if (window.ActiveXObject)
{
try
{
xmlreq = new ActiveXObject("Msxml2.XMLHTTP");
}
catch(e)
{
try
{
xmlreq = new ActiveXObject("Microsoft.XMLHTTP");
}
catch(e)
{
}
}
}
if (!xmlreq)
{
alert('ERROR: Cannot create an XmlHttp instance.');
return false;
}
return xmlreq;
}
this.clearFormValues = function(formId)
{
var objForm = document.getElementById(formId);
var str = "";
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
if (formElements[i].type == 'submit')
{
continue;
}
else if ((formElements[i].type == 'radio') ||
(formElements[i].type == 'checkbox'))
{
formElements[i].checked = false;
}
else
{
formElements[i].value = '';
}
}
}
return str;
}
this.getFormValues = function(formId)
{
var objForm = document.getElementById(formId);
var str = "";
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
if (((formElements[i].type == 'radio') ||
(formElements[i].type == 'checkbox')) &&
(formElements[i].checked == false))
{
continue;
}
var name = formElements[i].name;
if (name)
{
if (str != "")
{
str += '&';
}
str += name + "=" + encodeURIComponent(formElements[i].value);
}
}
}
return str;
}
this.call = function(sFunction, queryArray)
{
var r;
var i;
var uri;
if (document.body)
{
document.body.style.cursor = 'wait';
}
var icon = document.getElementById("activity_icon");
if (icon)
{
this.windowSize();
icon.style.top = Math.round((this.windowHeight / 2) - 64) + "px";
icon.style.left = Math.round((this.windowWidth / 2) - 64) + "px";
icon.style.display = "block";
}
uri = ajaxUri;
uri = window.location.protocol+"//"+window.location.hostname+(window.location.port ? ':'+window.location.port : '');
if(window.location.protocol=="https:")
{
uri=uri.replace("http:","https:");
}
postData = "ajax=" + encodeURIComponent(sFunction);
if (queryArray)
{
if (queryArray[0] == true)
{
postData = postData + "&" + queryArray[1];
}
else
{
for (i = 1; i < queryArray.length; i++)
{
postData = postData + "&" + i + "=" + encodeURIComponent(queryArray[i]);
}
}
}
this.prepReq(uri);
return false;
}
this.prepReq = function(uri){
var r = this.getRequestObject();
r.open("POST", uri, true);
try
{
r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
}
catch(e)
{
alert("ERROR: Your browser does not support asynchronous POST requests.");
return false;
}
r.onreadystatechange = function()
{
var responseStatus;
try
{
responseStatus = r.status;
}
catch(e)
{
responseStatus = 0;
}
if (r.readyState == 4)
{
if (responseStatus == 200)
{
if (r.responseXML)
{
ajax.processResponse(r.responseXML);
}
}
else if(responseStatus == 301 || responseStatus == 307)
{
var locationHeader = r.getResponseHeader("Location");
if(locationHeader)
{
ajax.prepReq(locationHeader);
}
return false;
}
else
{
alert("ERROR: There was a problem with the request (Status " + responseStatus + ")");
return false;
}
var activityIconNone = function()
{
document.body.style.cursor = 'default';
var icon = document.getElementById("activity_icon");
if (icon)
{
icon.style.display = "none";
}
};
window.setTimeout(activityIconNone, 500);
}
}
r.send(postData);
delete r;
}
this.willChange = function(target, attribute, newData)
{
var oldData;
var tmp;
if (attribute == "innerHTML")
{
tmp = document.getElementById(this.workId);
if (tmp == null)
{
tmp = document.createElement("div");
tmp.setAttribute('id', this.workId);
tmp.style.display = "none";
tmp.style.visibility = "hidden";
document.body.appendChild(tmp);
}
tmp.innerHTML = newData;
newData = tmp.innerHTML;
}
eval("oldData = document.getElementById('" + target + "')." + attribute);
if (newData != oldData)
{
return true;
}
return false;
}
this.getXmlValues = function(node, vals, raw)
{
vals[this.TARGET] = "";
vals[this.ATTR] = "";
vals[this.DATA] = "";
vals[this.SEARCH] = "";
vals[this.TYPE] = "";
node.normalize();
for (j = 0; j < node.childNodes.length ; j++)
{
if ((node.childNodes[j].nodeName == "target") && node.childNodes[j].firstChild)
{
vals[this.TARGET] = node.childNodes[j].firstChild.nodeValue;
}
else if ((node.childNodes[j].nodeName == "attribute") && node.childNodes[j].firstChild)
{
vals[this.ATTR] = node.childNodes[j].firstChild.nodeValue;
}
else if ((node.childNodes[j].nodeName == "data") && node.childNodes[j].firstChild)
{
vals[this.DATA] =
(raw) ? node.childNodes[j] :
node.childNodes[j].firstChild.nodeValue;
}
else if ((node.childNodes[j].nodeName == "search") && node.childNodes[j].firstChild)
{
vals[this.SEARCH] = node.childNodes[j].firstChild.nodeValue;
}
else if ((node.childNodes[j].nodeName == "type") && node.childNodes[j].firstChild)
{
vals[this.TYPE] = node.childNodes[j].firstChild.nodeValue;
}
}
}
this.processResponse = function(xml)
{
if(xml==null)return;
var vals = new Array(this.MAX);
xml = xml.documentElement;
for (i = 0; i < xml.childNodes.length; i++)
{
if (xml.childNodes[i].nodeName == "alert")
{
if (xml.childNodes[i].firstChild)
{
alert(xml.childNodes[i].firstChild.nodeValue);
}
}
else if (xml.childNodes[i].nodeName == "xml")
{
this.getXmlValues(xml.childNodes[i].firstChild, vals, true);
eval(vals[this.TARGET] + "(vals[this.DATA]);");
}
else if (xml.childNodes[i].nodeName == "script")
{
this.getXmlValues(xml.childNodes[i], vals, false);
if(window.execScript)
{
window.execScript(vals[this.DATA]);
window.execScript("window." + vals[this.TARGET] + " = true;");
}
else
{
window.eval(vals[this.DATA]);
window.setTimeout(vals[this.DATA], 0);
window.eval("window." + vals[this.TARGET] + " = true;");
}
}
else if (xml.childNodes[i].nodeName == "assign")
{
this.getXmlValues(xml.childNodes[i], vals, false);
if(this.willChange(vals[this.TARGET], vals[this.ATTR], vals[this.DATA]))
{
eval("document.getElementById('" + vals[this.TARGET] + "')." + vals[this.ATTR] + " = vals[this.DATA];");
}
}
else if (xml.childNodes[i].nodeName == "append")
{
this.getXmlValues(xml.childNodes[i], vals, false);
eval("document.getElementById('" + vals[this.TARGET] + "')." + vals[this.ATTR] + " += vals[this.DATA];");
}
else if (xml.childNodes[i].nodeName == "prepend")
{
this.getXmlValues(xml.childNodes[i], vals, false);
eval("document.getElementById('" + vals[this.TARGET] + "')." + vals[this.ATTR] + " = vals[this.DATA] + document.getElementById('" + vals[this.TARGET] + "')." + vals[this.ATTR]);
}
else if (xml.childNodes[i].nodeName == "clear")
{
this.getXmlValues(xml.childNodes[i], vals, false);
eval("document.getElementById('" + vals[this.TARGET] + "')." + vals[this.ATTR] + " = '';");
}
else if (xml.childNodes[i].nodeName == "clearTBody")
{
this.getXmlValues(xml.childNodes[i], vals, false);
var tb = eval("document.getElementById('" + vals[this.TARGET] + "')");
while (tb.rows.length)
{
tb.deleteRow(0);
}
}
else if (xml.childNodes[i].nodeName == "addRowTBody")
{
this.getXmlValues(xml.childNodes[i], vals, false);
var tr = eval("document.getElementById('" + vals[this.TARGET] + "').insertRow(-1)");
tr.id = vals[this.ATTR];
}
else if (xml.childNodes[i].nodeName == "addColTBody")
{
this.getXmlValues(xml.childNodes[i], vals, false);
var td = eval("document.getElementById('" + vals[this.TARGET] + "').insertCell(-1)");
eval("td." + vals[this.ATTR] + " = vals[this.DATA]");
}
else if(xml.childNodes[i].nodeName == "remove")
{
this.getXmlValues(xml.childNodes[i], vals, false);
objElement = document.getElementById(vals[this.TARGET]);
if(objElement && objElement.parentNode && objElement.parentNode.removeChild)
{
objElement.parentNode.removeChild(objElement);
}
}
else if (xml.childNodes[i].nodeName == "replace")
{
this.getXmlValues(xml.childNodes[i], vals, false);
eval("var v = document.getElementById('" + vals[this.TARGET] +"')." + vals[this.ATTR]);
var v2 = v.indexOf(search) == -1 ? v : "";
while (v.indexOf(vals[this.SEARCH]) > -1)
{
x = v.indexOf(vals[this.SEARCH]) + vals[this.SEARCH].length + 1;
v2 += v.substr(0, x).replace(vals[this.SEARCH],data);
v = v.substr(x, v.length - x);
}
if (this.willChange(v[this.TARGET], v[this.ATTR], v2))
{
eval('document.getElementById("' + v[this.ATTR] + '").' + v[this.ATTR] + ' = v2;');
}
}
else if (xml.childNodes[i].nodeName == "create")
{
this.getXmlValues(xml.childNodes[i], vals, false);
var objParent = document.getElementById(vals[this.TARGET]);
objElement = document.createElement(vals[this.ATTR]);
objElement.setAttribute('id', vals[this.DATA]);
if (vals[this.TYPE] && vals[this.TYPE] != '')
{
objElement.setAttribute('type', vals[this.TYPE]);
}
objParent.appendChild(objElement);
if (objParent.tagName == "FORM")
{
}
}
}
}
}
var ajax = new Ajax();
function ajaxClearFormValues(formId)
{
return ajax.clearFormValues(formId);
}
function ajaxGetFormValuesWithoutClearingThem(formId)
{
return ajax.getFormValues(formId);
}
function ajaxGetFormValues(formId)
{
var str = ajax.getFormValues(formId);
ajaxClearFormValues(formId);
return str;
}
function ajaxHistoryChange(page, queryArray)
{
if(!document.getElementById('contentData'))
{
var r=ajax.getRequestObject();
r.open('GET', '/', false);
r.send();
document.body.innerHTML=r.responseText;
$('[data-toggle="offcanvas"]').click(function () { $('.row-offcanvas').toggleClass('active') } );
var params=new Array();
eval("ajax_StatusPage" + "(params);");
delete params;
delete r;
return;
}
$('html, body').animate({
scrollTop: 0
}, 0);
eval("ajax_" + page + "(queryArray);");
}
function ajax_AddToHistory(page, queryArray)
{
ajaxHistoryChange(page, queryArray);
ajaxHistory.add(page, queryArray);
return false;
}
function ajaxHistoryInitialize()
{
ajaxHistory.initialize(Array.apply(null,arguments)[0]);
ajaxHistory.addListener(ajaxHistoryChange);
if (ajaxHistory.isFirstLoad() && Array.apply(null,arguments)[1])
{
ajax_AddToHistory(Array.apply(null,arguments)[1], Array.apply(null,arguments).slice(2));
}
}
