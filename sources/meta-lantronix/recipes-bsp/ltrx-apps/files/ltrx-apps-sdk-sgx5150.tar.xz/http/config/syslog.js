function SetSyslogDisplay(xml)
{
GetMessageDisplay('syslog',"syslog",14);
GetMessageDisplay('config',"strings",37);
GetMessageDisplay('state',"strings",46);
GetMessageDisplay('syslog_enable',"strings",14);
GetMessageDisplay('syslog_disable',"strings",15);
GetMessageDisplay('host',"strings",45);
GetMessageDisplay('remote_port',"syslog",4);
GetMessageDisplay('severity_log_level',"syslog",5);
GetMessageDisplay('none',"strings",47);
GetMessageDisplay('emergency',"syslog",6);
GetMessageDisplay('alert',"syslog",7);
GetMessageDisplay('critical',"syslog",8);
GetMessageDisplay('error',"strings",48);
GetMessageDisplay('warning',"strings",49);
GetMessageDisplay('notice',"syslog",9);
GetMessageDisplay('info',"strings",134);
GetMessageDisplay('debug',"strings",50);
document.getElementById("submit_button").value=GetMessage("strings",7);
GetMessageDisplay('stats',"strings",36);
GetMessageDisplay('status',"strings",0);
GetMessageDisplay('messages_sent',"syslog",11);
GetMessageDisplay('messages_failed',"syslog",12)
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Syslog.State');
SetDisplaySelection('Syslog.Host');
SetDisplaySelection('Syslog.Remote_Port');
SetDisplaySelection('Syslog.Local_Port');
SetDisplaySelection('Syslog.Severity_Log_Level');
document.getElementById("syslogform").style.display = "block";
}
