function uploadXCR()
{
var _file=document.getElementById('fsuploadfile');
if(_file.files.length==0)
{
return;
}
var fname = _file.value.substring(_file.value.lastIndexOf('\\')+1);
var data=new FormData();
data.append("selectedfile",_file.files[0]);
var request=ajax.getRequestObject();
request.open("POST","/xmlimport");
request.onreadystatechange = function(){
var responseStatus;
try
{
responseStatus = request.status;
}
catch(e)
{
responseStatus = 0;
}
if(request.readyState == 4)
{
if (responseStatus == 200)
{
ajax.processResponse(request.responseXML);
}
}
}
request.send(data);
}
function SetAdmin_XMLDisplay()
{
var menu=document.getElementById('xml_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('xml_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function XmlLinesRender(xml)
{
var numSerialPorts = parseInt(GetXmlData(xml, "numSerialPorts"));
var numLinePorts = document.getElementById("numSerialPorts").innerHTML;
var numUSBPorts = document.getElementById('numUSBPorts').innerHTML;
var numBluetoothPorts = document.getElementById('numBluetoothPorts').innerHTML;
var d = document.getElementById('xmllines');
d.innerHTML = '';
var r = '';
{
var columns = 8;
r += "<table class=\"table table-condensed\">";
var i;
var col = 0;
var twoCols = false;
for(
i = 0;
i < numSerialPorts
+ 1
;
++i
)
{
var line = i < numSerialPorts ? i + 1 : 0;
var groupId = "lineselect" + line;
var group = (
line ?
"" + line
: "network"
);
var groupName = (
line ?
(
line <= parseInt(numLinePorts) ? "" + line :
line <= parseInt(numLinePorts)+parseInt(numUSBPorts) ? "usb " + (line-parseInt(numLinePorts)) :
"bluetooth serial "+ (line-parseInt(numLinePorts)-parseInt(numBluetoothPorts))
)
: "network"
);
var twoCols = (line == 0);
var nCols = (twoCols ? 2 : 1);
if(col + nCols > columns)
{
col = 0;
r += "</tr>";
}
if(col == 0)
{
r += "<tr>";
}
r += twoCols ? "<td colspan=\"2\">" : "<td>";
r += "<input ";
r += "name=\"" + groupId + "\" ";
r += "id=\"" + groupId + "\" ";
r += "type=\"checkbox\" ";
r += "value=\"" + encodeURIComponent(group) + "\" ";
r += "checked ";
r += "/> " + groupName;
r += "</td>";
col += (twoCols ? 2 : 1);
}
r += "</tr>";
r += "</table>";
}
d.innerHTML = r;
}
function XmlSetAllLines(x)
{
var max = 2 +1 +4;
for(var i = 0; i <= max; ++i)
{
var d = document.getElementById("lineselect" + i);
if(d != undefined)
{
d.checked = x;
}
}
}
function XmlSetAllGroups(x)
{
for(var i = 0; ; ++i)
{
var d = document.getElementById('xmlgroup' + i);
if(d == undefined)
{
break;
}
if(x)
{
d.checked = d.defaultChecked;
}
else
{
d.checked = false;
}
}
}
function XmlGroupsRenderCommon(xml, isExportXMLConfig)
{
var d = document.getElementById('xmlgroups');
if(d)
{
d.innerHTML = '';
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += GetMessage("xml",62);
}
else
{
r += "<table class=\"table table-condensed\">";
var columns = 3;
var i;
var colspan=0;
if(xml.childNodes.length%3)
{
colspan=(3-xml.childNodes.length%3+1);
}
for(i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
var groupId = node.nodeName.toLowerCase();
var group = node.firstChild.nodeValue;
var isConfigNetwork = (
group == "bridge" ||
(isExportXMLConfig && group.substring(0,7) == "bridge:") ||
group == "interface" ||
(isExportXMLConfig && group.substring(0,10) == "interface:")
);
var localizedGroup=group;
localizedGroup = LocalizeGroupName(localizedGroup);
r += i % columns == 0 ? "<tr>" : "";
r += "<td ";
if(i==xml.childNodes.length-1 && colspan)
{
r += " colspan='"+colspan+"' ";
}
r += "width=\"" + Math.floor(100 / columns) + "%\">";
r += "<input ";
r += "name=\"" + groupId + "\" ";
r += "id=\"" + "xmlgroup" + i + "\" ";
r += "type=\"checkbox\" ";
r += "value=\"" + encodeURIComponent(group) + "\" ";
r += isConfigNetwork ? "unchecked " : "checked ";
r += "/> " + localizedGroup;
r += "</td>";
r += i % columns == columns - 1 ? "</tr>" : "";
}
r += i % columns != 0 ? "</tr>" : "";
r += "</table>";
}
d.innerHTML = r;
}
SetAdmin_XMLDisplay();
}
function XmlGroupsRender(xml)
{
XmlGroupsRenderCommon(xml, false);
}
function XmlGroupsRenderForExportConfig(xml)
{
GetMessageDisplay('cloning',"xml",36);
GetMessageDisplay('exportconf',"xml",37);
GetMessageDisplay('browser',"xml",20);
GetMessageDisplay('localfile',"xml",21);
GetMessageDisplay('download_from_link',"xml",58);
GetMessageDisplay('comments',"xml",23);
GetMessageDisplay('groups_to_export',"xml",24);
GetMessageDisplay('clear_all',"xml",32);
GetMessageDisplay('select_all_but_nw',"xml",25);
document.getElementById('submit_export').value=GetMessage("xml",59);
XmlGroupsRenderCommon(xml, true);
}
function UpdateImportDisplay()
{
GetMessageDisplay('cloning',"xml",36);
GetMessageDisplay('importconf', "xml", 39);
var form = document.forms[0];
var externalxcr = false;
var filesystem = false;
var linetemplate = false;
GetMessageDisplay('import',"xml",26);
GetMessageDisplay('conf_ext_file',"xml",27);
GetMessageDisplay('conf_filesys',"xml",28);
GetMessageDisplay('filename',"xml",29);
GetMessageDisplay('groups_to_import',"xml",30);
GetMessageDisplay('group_clear',"xml",32);
GetMessageDisplay('group_select_except_nw',"xml",25);
GetMessageDisplay('text_list',"xml",31);
document.getElementById('submit_import').value=GetMessage("xml",26);
if(!form.importoption.length)
{
externalxcr = true;
}
else
{
for(var i = 0; i < form.importoption.length; ++i)
{
if(form.importoption[i].checked)
{
if(form.importoption[i].value == "externalxcr")
{
externalxcr = true;
}
if(form.importoption[i].value == "filesystem")
{
filesystem = true;
}
if(form.importoption[i].value == "linetemplate")
{
linetemplate = true;
}
}
}
}
GetMessageDisplay('import_configuation_from_external_xcr',"xml",34);
document.getElementById('ext_submit_import').value=GetMessage("xml",26);
document.forms[1].style.display = externalxcr ? "" : "none";
document.getElementById('filesystemtable').style.display = (
filesystem || linetemplate ? "" : "none"
);
document.getElementById('importfilter_Display').style.display = (
filesystem ? "" : "none"
);
document.getElementById('filesystemheading').innerHTML = (
filesystem ?
"<b>"+GetMessage("xml", 60)+":</b>" :
"<b>"+GetMessage("xml", 61)+":</b>"
);
SetAdmin_XMLDisplay();
}
function XmlXcrExportPostProcedure()
{
FileSystemMonitor();
return ajax_XmlExportPost(
[true, ajaxGetFormValuesWithoutClearingThem('xmlform')]
);
}
function XCRDownloadLinkDisplay(xml)
{
var d = document.getElementById('xcr_backup');
var r = '<i>'+GetMessage("xml",63)+'</i>';
if(xml)
{
var backup=xml.getElementsByTagName("xcr_backup");
if(backup && backup.length>0)
{
var backup_value=backup[0].firstChild.nodeValue;
r = "<img src=\"/file.gif\" />&nbsp;";
r += "<a href=\"javascript:void(0)\" onclick=\"bootbox.confirm(GetConfirmationMessage('xml',64), function(result) {";
r += "if(result==true){ajax_XmlCleanDownloadLink([true, '']);}});return false;\"><img src=\"/remove.gif\" /></a>&nbsp;";
r += "<a download='clone.xcr' href=\"/fs?file=";
r += encodeURIComponent(backup_value);
r += "\" target=\"_blank\">"+GetMessage("strings",40)+"</a>";
var backup_size=xml.getElementsByTagName("xcr_backup_size");
if(backup_size && backup_size.length>0)
{
var backup_size_value=backup_size[0].firstChild.nodeValue;
r += "</br>(" + backup_size_value + ")";
}
}
}
d.innerHTML=r;
}
function XmlXcrExport()
{
var form = document.getElementById('xmlform');
if(form.elements[0].checked)
{
form.target = '_blank';
form.action = '/xmlexport';
}
else
{
SetDisplayValue('confirms','');
confirmPostProcedure = 'XmlXcrExportPostProcedure();';
return XmlXcrExportPostProcedure();
}
SetAdmin_XMLDisplay();
}
function XmlXsrExportPostProcedure()
{
FileSystemMonitor();
return ajax_XSRExportPost(
[true, ajaxGetFormValuesWithoutClearingThem('xmlform')]
);
}
function XmlXsrExport()
{
var form = document.getElementById('xmlform');
if(form.elements[0].checked)
{
form.target = '_blank';
form.action = '/xsrexport';
}
else
{
SetDisplayValue('confirms','');
confirmPostProcedure = 'XmlXsrExportPostProcedure();';
return XmlXsrExportPostProcedure();
}
SetAdmin_XMLDisplay();
}
function XSRExportDisplay()
{
GetMessageDisplay('xml',"xml",36);
GetMessageDisplay('export_status',"xml",38);
GetMessageDisplay('browser',"xml",20);
GetMessageDisplay('localfile',"xml",21);
GetMessageDisplay('groups_to_export',"xml",24);
GetMessageDisplay('clear_all',"xml",32);
GetMessageDisplay('select_all',"xml",33);
document.getElementById('submit_export').value=GetMessage("xml",59);
}
