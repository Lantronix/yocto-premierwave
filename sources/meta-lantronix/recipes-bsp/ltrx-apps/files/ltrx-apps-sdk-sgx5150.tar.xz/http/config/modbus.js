function ModbusConnectionsRender(xml, id)
{
var d = document.getElementById(id);
d.innerHTML = '';
var r = '';
if(!xml || !xml.hasChildNodes())
{
r += "&lt;None&gt;";
}
else
{
var first = true;
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "c")
{
if(! first)
{
r += "<br/>";
}
first = false;
r += GetXmlData(node, "s");
r += " [<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "if(confirm('Are you SURE you want to kill this connection?'))";
r += "ajax_ModbusStatsClean(";
r += "[true, 'action=kill" + id + "&amp;id=" + GetXmlData(node, "i") + "']";
r += ");";
r += "return false;";
r += "\"";
r += ">Kill</a>]<br/>";
r += "Uptime: " + GetXmlData(node, "u") + "<br/>";
r += "PDUs In: " + GetXmlData(node, "pdui") + "<br/>";
r += "PDUs Out: " + GetXmlData(node, "pduo") + "<br/>";
}
}
}
d.innerHTML = r;
}
function SetAdmin_ModbusDisplay()
{
var menu=document.getElementById('modbus_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('modbus_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function modbusTcpConnectionsRender(xml)
{
ModbusConnectionsRender(xml, 'modbusconn');
}
function modbusaddTcpConnectionsRender(xml)
{
ModbusConnectionsRender(xml, 'modbusaddconn');
}
function SetModbusDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Modbus.TCP_Server_State');
ap = SetDisplaySelection('Modbus.Additional_Port');
SetDisplaySelection('Modbus.Response_Timeout');
SetDisplaySelection('Modbus.RSS.Trace_Input');
}
