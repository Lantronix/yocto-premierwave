function DHCPRelayStateChanged()
{
var state = document.getElementsByName("dhcp_relay_state")[0].checked;
document.getElementById('relay_ip_address').style.display = (state?'':'none');
document.getElementById('lease_time').style.display = (state?'none':'');
document.getElementById('start_ip_address').style.display = (state?'none':'');
document.getElementById('end_ip_address').style.display = (state?'none':'');
document.getElementById('start_ipv6_address').style.display = (state?'none':'');
document.getElementById('end_ipv6_address').style.display = (state?'none':'');
}
function DHCPDRender(xml)
{
var r = '';
var s = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve dhcpd settings.</p>";
var d = document.getElementById('dhcpd_contents');
d.innerHTML=r;
}
else
{
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><td colspan='2'><b>Configuration</b></td></tr><thead>";
s = "<table class='table table-striped table-condensed'>";
s += "<thead><tr><td><b>Delete</b></td><td><b>MAC Address</b></td><td><b>IP Address</b></td>";
s += "<td><b>IPv6 Address</b></td>";
s += "</tr><thead>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "dhcpd")
{
for(var j = 0; node && j < node.childNodes.length; ++j)
{
var node2 = node.childNodes[j];
if(node2.nodeName.toLowerCase() == "lease_time")
{
var lease_time=node2.firstChild.nodeValue;
r += "<tr id='lease_time'><td width='40%'><b>Lease Time:</b></td><td><input type='text' size='10' maxlength='10' name='dhcp_leaseTime' org_value='"+lease_time+"' value='"+lease_time+"' ";
r += "onkeyup='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'/> hours</td></tr>";
}
if(node2.nodeName.toLowerCase() == "state")
{
r += "</table>";
r += "<table class='table table-striped table-condensed'>"
r += "<thead><tr><td colspan='3'><b>DHCP Settings</b></td></tr></thead>";
var isEnabled=(node2.firstChild.nodeValue=='Enabled')?true:false;
r += "<tr><td width='40%'><b>State:</b></td><td>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'";
r += " name='dhcp_state' type='radio' value='Enabled'";
r += " org_state='"+isEnabled+"'";
if(isEnabled)r += " checked ";
r += "/>Enabled";
r += "</label>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'";
r += " name='dhcp_state' type='radio' value='Disabled'";
r += " org_state='"+!isEnabled+"'";
if(!isEnabled)r += " checked ";
r += "/>Disabled";
r += "</label>";
r += "</td></tr>";
}
if(node2.nodeName.toLowerCase() == "relay_state")
{
var isEnabled=(node2.firstChild.nodeValue=='Enabled')?true:false;
r += "<tr id='relay_state'><td width='40%'><b>DHCP Relay:</b></td><td>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='DHCPRelayStateChanged();updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'";
r += " name='dhcp_relay_state' type='radio' value='Enabled'";
r += " org_state='"+isEnabled+"'";
if(isEnabled)r += " checked ";
r += "/>Enabled";
r += "</label>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='DHCPRelayStateChanged();updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'";
r += " name='dhcp_relay_state' type='radio' value='Disabled'";
r += " org_state='"+!isEnabled+"'";
if(!isEnabled)r += " checked ";
r += "/>Disabled";
r += "</label>";
r += "</td></tr>";
}
if(node2.nodeName.toLowerCase() == "relay_ip_address")
{
var dhcpIP=node2.firstChild.nodeValue;
r += "<tr id='relay_ip_address'><td><b>DHCP Server IP Address:</b></td><td><input type='text' size='32' maxlength='64' name='dhcp_relayIP' org_value='"+dhcpIP+"' value='"+dhcpIP+"' ";
r += "onkeyup='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
}
if(node2.nodeName.toLowerCase() == "ip_address")
{
var routerIP=node2.firstChild.nodeValue;
r += "<tr id='router_ip'><td>IP Address:</td><td><input type='text' size='32' maxlength='64' name='dhcp_routerIP' org_value='"+routerIP+"' value='"+routerIP+"' ";
r += "onkeyup='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
}
if(node2.nodeName.toLowerCase() == "start_ip_address")
{
var startIP=node2.firstChild.nodeValue;
r += "<tr id='start_ip_address'><td><b>Start IP Address:</b></td><td><input type='text' size='32' maxlength='64' name='dhcp_startIP' org_value='"+startIP+"' value='"+startIP+"' ";
r += "onkeyup='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
}
if(node2.nodeName.toLowerCase() == "end_ip_address")
{
var endIP=node2.firstChild.nodeValue;
r += "<tr id='end_ip_address'><td><b>End IP Address:</b></td><td><input type='text' size='32' maxlength='64' name='dhcp_endIP' org_value='"+endIP+"' value='"+endIP+"' ";
r += "onkeyup='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
}
if(node2.nodeName.toLowerCase() == "ipv6_state")
{
r += "</table>";
r += "<table class='table table-striped table-condensed'>"
r += "<thead><tr><td colspan='3'><b>DHCPv6 Settings</b></td></tr></thead>";
var isEnabled=(node2.firstChild.nodeValue=='Enabled')?true:false;
r += "<tr><td width='40%'><b>State:</b></td><td>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'";
r += " name='ipv6_state' type='radio' value='Enabled'";
r += " org_state='"+isEnabled+"'";
if(isEnabled)r += " checked ";
r += "/>Enabled";
r += "</label>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'";
r += " name='ipv6_state' type='radio' value='Disabled'";
r += " org_state='"+!isEnabled+"'";
if(!isEnabled)r += " checked ";
r += "/>Disabled";
r += "</label>";
r += "</td></tr>";
}
if(node2.nodeName.toLowerCase() == "start_ipv6_address")
{
var startIP=node2.firstChild.nodeValue;
r += "<tr id='start_ipv6_address'><td><b>Start IPv6 Address:</b></td><td><input type='text' size='32' maxlength='64' name='dhcp_startIPv6' org_value='"+startIP+"' value='"+startIP+"' ";
r += "onkeyup='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
}
if(node2.nodeName.toLowerCase() == "end_ipv6_address")
{
var endIP=node2.firstChild.nodeValue;
r += "<tr id='end_ipv6_address'><td><b>End IPv6 Address:</b></td><td><input type='text' size='32' maxlength='64' name='dhcp_endIPv6' org_value='"+endIP+"' value='"+endIP+"' ";
r += "onkeyup='updateButtonVisibilities(\"dhcpd_config_form\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
}
if(node2.nodeName.toLowerCase() == "address_reservation")
{
var reservation_index=GetXmlData(node2,"index");
var mac=GetXmlData(node2,"mac");
var ip_address=GetXmlData(node2,"ip_address");
var ipv6_address=GetXmlData(node2,"ipv6_address");
s += "<tr>";
s += "<td>"
s += "<input type='checkbox' ";
s += " onclick='updateButtonVisibilities(\"dhcpd_reservation_form\",\"submit_staticlease_changes\",\"cancel_staticlease_changes\");' ";
s += " name='dhcp_staticlease.state." + reservation_index +"' org_state='false'/>";
s += "</td>";
s += "<td>";
s += "<input type='text' size='16' maxlength='64' name='dhcp_staticlease.mac."+reservation_index+"' org_value='"+mac+"' value='"+mac+"' ";
s += " onkeyup='updateButtonVisibilities(\"dhcpd_reservation_form\",\"submit_staticlease_changes\",\"cancel_staticlease_changes\");'/>";
s += "</td>";
s += "<td>";
s += "<input type='text' size='16' maxlength='64' name='dhcp_staticlease.ip."+reservation_index+"' org_value='"+ip_address+"' value='"+ip_address+"' ";
s += " onkeyup='updateButtonVisibilities(\"dhcpd_reservation_form\",\"submit_staticlease_changes\",\"cancel_staticlease_changes\");'/>";
s += "</td>";
s += "<td>";
s += "<input type='text' size='16' maxlength='64' name='dhcp_staticlease.ipv6."+reservation_index+"' org_value='"+ipv6_address+"' value='"+ipv6_address+"' ";
s += " onkeyup='updateButtonVisibilities(\"dhcpd_reservation_form\",\"submit_staticlease_changes\",\"cancel_staticlease_changes\");'/>";
s += "</td>";
s += "</tr>";
}
}
}
}
s += "</table>";
r += "</table>";
var d = document.getElementById('dhcpd_configuration');
if(d)d.innerHTML=r;
var d = document.getElementById('dhcpd_reservation_list');
if(d)d.innerHTML=s;
updateButtonVisibilities('dhcpd_config_form','submit_changes','cancel_changes');
updateButtonVisibilities('dhcpd_reservation_form','submit_staticlease_changes','cancel_staticlease_changes');
}
}
function SetAdmin_GatewayDisplay()
{
var menu=document.getElementById('gateway_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('gateway_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
var menu=document.getElementById('gatewayconf_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('gatewayconf_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function SetConfigDHCPDDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("dhcpd_config_form").style.display = "block";
document.getElementById("dhcpd_reservation_form").style.display = "block";
document.getElementById("dhcpd_addreservation").reset();
document.getElementById("dhcpd_addreservation").style.display = "block";
DHCPRelayStateChanged();
}
