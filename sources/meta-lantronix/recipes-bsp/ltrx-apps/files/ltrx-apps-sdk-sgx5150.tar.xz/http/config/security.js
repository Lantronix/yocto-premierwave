function SetSecurityDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Security.FIPS_140_2_Mode');
document.getElementById("securityform").style.display = "block";
}
