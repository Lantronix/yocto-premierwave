function UpdateGRENetworkSelection(xml)
{
var gre_network = GetDisplayValue("new_gre.Local_Network");
var x=document.getElementById('gre_local_networks');
for(var i=0;i<x.length;i++)
{
if(gre_network==x.options[i].value)
{
x.selectedIndex=i;
break;
}
}
Update();
}
function UpdateGRENetwork(xml)
{
var x=document.getElementById('gre_local_networks');
var gre_network = x.options[x.selectedIndex].value
SetDisplayValue('new_gre.Local_Network',gre_network);
Update();
}
function SetGREDisplay(xml)
{
displayElementRootNames = new Array();
SetDisplaySelection('gre.State');
SetDisplaySelection('gre.Name');
SetDisplaySelection('gre.Local_Network');
SetDisplaySelection('gre.Remote_Host');
SetDisplaySelection('gre.IP_Address');
SetDisplaySelection('gre.MTU');
SetDisplaySelection('gre.Remote_Network');
UpdateGRENetworkSelection();
SetSubmit(false);
document.getElementById("greform").style.display = "block";
}
