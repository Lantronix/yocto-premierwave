function showHide(obj,initialize)
{
if(initialize==0)return;
if(obj &&
obj.parentNode &&
obj.parentNode.parentNode &&
obj.parentNode.parentNode.parentNode &&
obj.parentNode.parentNode.parentNode.parentNode
)
{
var tbody = obj.parentNode.parentNode.parentNode.parentNode.getElementsByTagName("tbody")[0];
if(tbody)
{
var old = tbody.style.display;
if(old=="none")obj.innerHTML="[-]";
else obj.innerHTML="[+]";
tbody.style.display = (old == "none"?"":"none");
if(obj.id=='email_Display')
{
var stats=document.getElementById("email_stats");
stats.innerHTML='';
if(old=="")
{
var email1=document.getElementsByName("new_Action.Email.Alarm_Email")[0];
var email2=document.getElementsByName("new_Action.Email.Normal_Email")[0];
if(email1.value=='None' && email2.value=='None')
{
stats.innerHTML='&lt;Not Configured&gt;';
}
else
{
stats.innerHTML='&lt;Configured&gt;';
}
}
}
if(obj.id=='ftp_Display')
{
var stats=document.getElementById("ftp_stats");
stats.innerHTML='';
if(old=="")
{
var bConfigured=false;
var i;
for(i=1;i<=2;i++)
{
var elem=document.getElementsByName("new_Action.FTP_Put.Connection_"+i+".Host")[0];
if(elem.value!="")
{
bConfigured=true;
break;
}
}
if(bConfigured)
{
stats.innerHTML='&lt;Configured&gt;';
}
else
{
stats.innerHTML='&lt;Not Configured&gt;';
}
}
}
if(obj.id=='http_Display')
{
var stats=document.getElementById("http_stats");
stats.innerHTML='';
if(old=="")
{
var bConfigured=false;
var i;
for(i=1;i<=2;i++)
{
var elem=document.getElementsByName("new_Action.HTTP_Post.Connection_"+i+".Host")[0];
if(elem.value!="")
{
bConfigured=true;
break;
}
}
if(bConfigured)
{
stats.innerHTML='&lt;Configured&gt;';
}
else
{
stats.innerHTML='&lt;Not Configured&gt;';
}
}
}
if(obj.id=='snmp_Display')
{
var stats=document.getElementById("snmp_stats");
stats.innerHTML='';
if(old=="")
{
var i;
var bEnabled=false;
var arr=document.getElementsByName("new_Action.SNMP_Trap.State");
for(i=0;i<arr.length;i++)
{
if(arr[i].checked && arr[i].value=="Enabled")
{
bEnabled=true;
break;
}
}
var normal=document.getElementsByName("new_Action.SNMP_Trap.Normal_Message")[0];
var alarm=document.getElementsByName("new_Action.SNMP_Trap.Alarm_Message")[0];
if(bEnabled && (normal.value!='' || alarm.value!=''))
{
stats.innerHTML='&lt;Configured&gt;';
}
else
{
stats.innerHTML='&lt;Not Configured&gt;';
}
}
}
}
}
}
function UpdateAlarmDisplay(initial, optElement)
{
var i;
var alarmEmail = GetDisplayValue("new_Action.Email.Alarm_Email") != "None";
SetFxDisplay(
"email_alarm_message_Display", alarmEmail ? "" : "none", initial
);
SetFxDisplay(
"email_alarm_reminder_interval_Display", alarmEmail ? "" : "none", initial
);
var normalEmail = GetDisplayValue("new_Action.Email.Normal_Email") != "None";
SetFxDisplay(
"email_normal_message_Display", normalEmail ? "" : "none", initial
);
SetFxDisplay(
"email_normal_reminder_interval_Display", normalEmail ? "" : "none", initial
);
for(i = 1;i <= 2; ++i)
{
var alarmFTP = GetDisplayValue("new_Action.FTP_Put.Connection_"+i+".Host") != "";
SetFxDisplay(
"ftp_port"+i+"_Display", alarmFTP ? "" : "none", initial
);
SetFxDisplay(
"ftp_protocol"+i+"_Display", alarmFTP ? "" : "none", initial
);
SetFxDisplay(
"ftp_username"+i+"_Display", alarmFTP ? "" : "none", initial
);
SetFxDisplay(
"ftp_password"+i+"_Display", alarmFTP ? "" : "none", initial
);
SetFxDisplay(
"ftp_file"+i+"_Display", alarmFTP ? "" : "none", initial
);
SetFxDisplay(
"ftp_localport"+i+"_Display", alarmFTP ? "" : "none", initial
);
}
for(i = 1;i <= 2; ++i)
{
var alarmHTTP = GetDisplayValue("new_Action.HTTP_Post.Connection_"+i+".Host") != "";
SetFxDisplay(
"http_port"+i+"_Display", alarmHTTP ? "" : "none", initial
);
SetFxDisplay(
"http_url"+i+"_Display", alarmHTTP ? "" : "none", initial
);
SetFxDisplay(
"http_protocol"+i+"_Display", alarmHTTP ? "" : "none", initial
);
SetFxDisplay(
"http_username"+i+"_Display", alarmHTTP ? "" : "none", initial
);
SetFxDisplay(
"http_password"+i+"_Display", alarmHTTP ? "" : "none", initial
);
SetFxDisplay(
"http_localport"+i+"_Display", alarmHTTP ? "" : "none", initial
);
}
Update(optElement);
}
function SetAlarmDisplay(xml)
{
var i;
displayElementRootNames = new Array();
SetDisplaySelection('Action.Instance');
SetDisplaySelection('Action.Delay');
var initialize = GetXmlData(xml, "initializeDisplay");
{
var ids = new Array();
ids.push("alarm_email_Select");
ids.push("normal_email_Select");
for(var s; ids[0] && (s = document.getElementById(ids[0])); ids.shift())
{
s.length=0;
s.options[0] = new Option("None", "None");
for(i = 1; i <= 16; ++i)
{
var t = "Email " + i;
s.options[i] = new Option(t, t);
}
}
}
SetDisplaySelection('Action.Email.Alarm_Email');
SetDisplaySelection('Action.Email.Alarm_Message');
SetDisplaySelection('Action.Email.Alarm_Reminder_Interval');
SetDisplaySelection('Action.Email.Normal_Email');
SetDisplaySelection('Action.Email.Normal_Message');
SetDisplaySelection('Action.Email.Normal_Reminder_Interval');
showHide(document.getElementById("email_Display"),initialize);
SetDisplaySelection('Action.FTP_Put.Reminder_Interval');
SetDisplaySelection('Action.FTP_Put.Mode');
for(i = 1;i <= 2; ++i)
{
SetDisplaySelection('Action.FTP_Put.Connection_'+i+'.Host');
SetDisplaySelection('Action.FTP_Put.Connection_'+i+'.Port');
SetDisplaySelection('Action.FTP_Put.Connection_'+i+'.Protocol');
SetDisplaySelection('Action.FTP_Put.Connection_'+i+'.Username');
SetDisplaySelection('Action.FTP_Put.Connection_'+i+'.Password');
SetDisplaySelection('Action.FTP_Put.Connection_'+i+'.Filename');
SetDisplaySelection('Action.FTP_Put.Connection_'+i+'.Local_Port');
}
showHide(document.getElementById("ftp_Display"),initialize);
SetDisplaySelection('Action.HTTP_Post.Reminder_Interval');
SetDisplaySelection('Action.HTTP_Post.Mode');
for(i = 1;i <= 2; ++i)
{
SetDisplaySelection('Action.HTTP_Post.Connection_'+i+'.Host');
SetDisplaySelection('Action.HTTP_Post.Connection_'+i+'.Port');
SetDisplaySelection('Action.HTTP_Post.Connection_'+i+'.Protocol');
SetDisplaySelection('Action.HTTP_Post.Connection_'+i+'.URL');
SetDisplaySelection('Action.HTTP_Post.Connection_'+i+'.Username');
SetDisplaySelection('Action.HTTP_Post.Connection_'+i+'.Password');
SetDisplaySelection('Action.HTTP_Post.Connection_'+i+'.Local_Port');
}
showHide(document.getElementById("http_Display"),initialize);
SetDisplaySelection('Action.SNMP_Trap.State');
SetDisplaySelection('Action.SNMP_Trap.Reminder_Interval');
SetDisplaySelection('Action.SNMP_Trap.Alarm_Message');
SetDisplaySelection('Action.SNMP_Trap.Normal_Message');
showHide(document.getElementById("snmp_Display"),initialize);
SetSubmit(false);
UpdateAlarmDisplay(true);
document.getElementById("alarmform").style.display = "block";
}
function AlarmRender(xml)
{
var numberOfInstances = GetXmlData(xml, "numberOfInstances");
var instance = GetXmlData(xml, 'instance');
var title = GetXmlData(xml, 'title');
var name = GetXmlData(xml, 'name');
var id = GetXmlDataByZeroBasedIndex(xml, 'names', Number(instance));
document.getElementById("hiddenalarmidentifier").innerHTML = instance;
document.getElementById("alarmidentifier").innerHTML = (
id ? id : title +
(Number(numberOfInstances) ? " " + (Number(instance) + 1) : "")
);
var d = document.getElementById("alarm_selection");
if(d)
{
var r = "";
r += '<table id="Nav1" class="table table-striped table-condensed">';
r += "<thead><tr>";
if(numberOfInstances > 3)
{
r += "<td align='right'><b>Select Action:</b></td>";
r += "<td align='left'>";
r += "<table><tr><td>";
r += "<select class='form-control' name='navSelect' ";
r += "id='navSelect' ";
r += "onchange=\" ";
r += "var page = document.getElementById('hiddencurrentalarmpage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'alarmidentifier='+this.value]);";
r += " \" ";
r += ">";
for(var i = 0; i < numberOfInstances; ++i)
{
var n = GetXmlDataByZeroBasedIndex(xml, 'names', i);
var sel = (instance == i) ? " selected " : "";
r += "<option value='" + i + "' " + sel + ">";
r += n ? n : name + " " + (i + 1);
r += "</option>";
}
r += "</select></td></tr></table>";
r += "</td>";
}
else
{
for(var i = 1; i <= numberOfInstances; ++i)
{
var n = GetXmlDataByZeroBasedIndex(xml, 'names', i - 1);
r += "<td id='alarmnav" + i + "'>";
r += "<a ";
r += "href='javascript:void(0)'";
r += "onclick=\"";
r += "var page = document.getElementById('hiddencurrentalarmpage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'alarmidentifier=" + (i - 1) + "']);";
r += "\"";
r += ">";
r += n ? n : name + " " + i;
r += "</a>";
r += "</td>";
}
}
r += "</tr></thead>";
r += "</table>";
d.innerHTML = r;
HighlightElementInTable("Nav1", "alarmnav" + (Number(instance)+1));
}
}
function SetAdmin_AlarmDisplay()
{
var menu=document.getElementById('alarm_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('alarm_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
