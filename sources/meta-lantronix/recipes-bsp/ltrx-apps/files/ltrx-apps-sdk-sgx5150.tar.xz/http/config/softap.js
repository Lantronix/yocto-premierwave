function SoftAPSuiteUpdate()
{
var suite = GetInputElementValue(
document.forms[0].elements["new_SoftAP.Suite"]
);
if(suite=="None")
{
document.getElementById("passphrase_Display").style.display="none";
document.getElementById("key_Display").style.display="none";
document.getElementById("hex_Display").style.display="none";
}
else
{
document.getElementById("passphrase_Display").style.display="";
document.getElementById("key_Display").style.display="";
document.getElementById("hex_Display").style.display="";
SoftAPKeyUpdate();
}
Update();
}
function SoftAPKeyUpdate()
{
var kt = GetInputElementValue(
document.forms[0].elements["new_SoftAP.Key_Type"]
);
if(kt == "Hex")
{
document.getElementById("passphrase_Display").style.display="none";
document.getElementById("hex_Display").style.display="";
}
else
{
document.getElementById("passphrase_Display").style.display="";
document.getElementById("hex_Display").style.display="none";
}
Update();
}
function SoftAPTriggerModeUpdate()
{
var triggerMode = GetInputElementValue(
document.forms[0].elements["new_SoftAP.Mode"]
);
if(triggerMode=="Triggered")
{
document.getElementById("trigger_initial_uptime_Display").style.display="";
document.getElementById("trigger_reconnect_uptime_Display").style.display="";
document.getElementById("trigger_button_Display").style.display="";
}
else
{
document.getElementById("trigger_initial_uptime_Display").style.display="none";
document.getElementById("trigger_reconnect_uptime_Display").style.display="none";
document.getElementById("trigger_button_Display").style.display="none";
}
Update();
}
function SoftAPChannelSelectionUpdate()
{
var channelSelection = GetInputElementValue(
document.forms[0].elements["new_SoftAP.Channel_Selection"]
);
if(channelSelection=="Configured")
{
document.getElementById("channel_Display").style.display="";
}
else
{
document.getElementById("channel_Display").style.display="none";
}
Update();
}
function SetSoftAPDisplay(xml)
{
GetMessageDisplay('soft_ap', "softap", 0);
GetMessageDisplay('conf', "strings", 37);
GetMessageDisplay('network_state',"strings",46);
GetMessageDisplay('multicast_forward',"softap",19);
GetMessageDisplay('network_enabled',"strings",14);
GetMessageDisplay('network_disabled',"strings",15);
GetMessageDisplay('network_ip_address',"strings",101);
GetMessageDisplay('wlan_basic_conf_network_name_ssid',"net",152);
GetMessageDisplay('wlan_security_suite',"net",153);
GetMessageDisplay('wlan_passphrase',"net",167);
GetMessageDisplay('str_show_passw',"strings",136);
GetMessageDisplay('str_show_hex',"strings",136);
GetMessageDisplay('assoclist_section', "softap", 4);
GetMessageDisplay('status_section', "strings", 0);
GetMessageDisplay('stat_current',"net",141);
GetMessageDisplay('stat_after_reboot',"net",142);
GetMessageDisplay('stat_state',"strings",46);
document.getElementById("submit_button").value = GetMessage("strings", 7);
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('SoftAP.State');
SetDisplaySelection('SoftAP.Multicast_Forwarding');
SetDisplaySelection('SoftAP.IP_Address');
SetDisplaySelection('SoftAP.Network_Name');
SetDisplaySelection('SoftAP.DNS_Redirect');
SetDisplaySelection('SoftAP.SSID_Broadcast');
SetDisplaySelection('SoftAP.Suite');
document.getElementById("suite_none").text = GetMessage("strings", 47);
SetDisplaySelection('SoftAP.Key_Type');
SetDisplaySelection('SoftAP.Key');
SetDisplaySelection('SoftAP.Passphrase');
SoftAPSuiteUpdate();
document.getElementById("mode_always_up").text = GetMessage("softap", 6);
document.getElementById("mode_triggered").text = GetMessage("softap", 7);
GetMessageDisplay('soft_ap_trigger_mode',"softap",8);
GetMessageDisplay('soft_ap_trigger_initial_uptime',"softap",9);
GetMessageDisplay('soft_ap_timeout1_sec',"strings",39);
GetMessageDisplay('soft_ap_trigger_reconnect_uptime',"softap",10);
GetMessageDisplay('soft_ap_timeout2_sec',"strings",39);
GetMessageDisplay('soft_ap_trigger_button',"softap",13);
GetMessageDisplay('trigger_soft_ap_push',"softap",14);
SetDisplaySelection('SoftAP.Mode');
SetDisplaySelection('SoftAP.First_Client_Connect_Timeout');
SetDisplaySelection('SoftAP.Last_Client_Disconnect_Timeout');
SoftAPTriggerModeUpdate();
GetMessageDisplay('soft_ap_channel',"softap",15);
GetMessageDisplay('soft_ap_channel_info',"softap",16);
SetDisplaySelection('SoftAP.Channel_Selection');
SetDisplaySelection('SoftAP.Channel');
SoftAPChannelSelectionUpdate();
document.getElementById("softapform").style.display = "block";
}
function AssociatedListRender(xml)
{
var d = document.getElementById('assoclist');
if(d)
{
var r = "<table class='table table-striped table-condensed'><thead><tr><td width='40%'><b>"+GetMessage("strings",121)+"</b></td><td><b>"+GetMessage("strings",101)+"</b></td></tr></thead><tbody>";
if(! xml || ! xml.hasChildNodes())
{
r+="<tr><td colspan='2'>"+GetMessage("strings",47)+"</td></tr>";
}
else
{
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "assoclist")
{
var ip_address=GetXmlData(node,"ip_address");
var mac_address=GetXmlData(node,"mac_address");
r+="<tr><td>"+mac_address+"</td><td>"+ip_address+"</td></tr>";
}
}
}
r += "</tbody></table>";
d.innerHTML=r;
}
}
