function PingRender(xml)
{
var d = document.getElementById('ping_results');
if(d)
{
d.innerHTML = '';
var r = '';
r += "<div>";
r += "<h3 class='sub-header'>"+GetMessage("ping",16)+"</h3>";
r += "<table class=\"table table-striped table-condensed\">";
if(! xml || ! xml.hasChildNodes())
{
r += "<tr><td><b>"+GetMessage("strings",53)+"</b></td></tr>";
}
else
{
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "t")
{
r += "<tr>";
r += "<td>" + GetXmlData(node, "n") + "</td>";
r += "</tr>";
}
}
}
r += "</table>";
r += "</div>";
d.innerHTML = r;
}
}
function SetPingDisplay()
{
GetMessageDisplay('diag_ping',"ping",13);
GetMessageDisplay('diag_ping_host',"strings",45);
GetMessageDisplay('diag_ping_count',"ping",14);
GetMessageDisplay('diag_ping_timeout',"ping",15);
GetMessageDisplay('diag_ping_timeout_sec',"strings",39);
document.getElementById('submit_button').value=GetMessage("ping",17);
}
