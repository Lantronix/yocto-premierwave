function SetQueryServerDisplay(xml)
{
GetMessageDisplay('discovery_header',"discovery",16);
GetMessageDisplay('query_conf',"strings",37);
GetMessageDisplay('query_server_state',"discovery",3);
GetMessageDisplay('query_server_enable',"strings",14);
GetMessageDisplay('query_server_disable',"strings",15);
GetMessageDisplay('upnp_server_state',"discovery",4);
GetMessageDisplay('upnp_server_enable',"strings",14);
GetMessageDisplay('upnp_server_disable',"strings",15);
GetMessageDisplay('upnp_server_port',"discovery",5);
GetMessageDisplay('upnp_status',"discovery",23);
GetMessageDisplay('upnp_interface',"discovery",24);
document.getElementById("submit_button").value = GetMessage("strings",7);
GetMessageDisplay('query_statistics',"strings",36);
GetMessageDisplay('query_status',"discovery",6);
GetMessageDisplay('invalid_queries',"discovery",7);
GetMessageDisplay('unknown_queries',"discovery",8);
GetMessageDisplay('erraneous_packets',"discovery",9);
GetMessageDisplay('out_query_replies',"discovery",10);
GetMessageDisplay('out_errors',"discovery",11);
GetMessageDisplay('last_conn',"discovery",12);
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Query_Server.State');
SetDisplaySelection('Query_Server.UPnP_State');
SetDisplaySelection('Query_Server.UPnP_Port');
document.getElementById("queryform").style.display = "block";
}
