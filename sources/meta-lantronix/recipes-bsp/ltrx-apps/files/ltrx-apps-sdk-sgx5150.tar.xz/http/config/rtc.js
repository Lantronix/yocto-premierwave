function TimeZoneRender(xml)
{
var zone = GetXmlData(xml, "zone");
var r = "<form class='form-horizontal' id='timezoneform' method='POST'>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<tr><td width='40%'><b>"+GetMessage("rtc", 38)+":</b></td>";
r += "<td><table>";
var dir = GetXmlData(xml, "directory");
r += '<tr><td>'+GetMessage("strings", 63)+' ' + dir + '<td><tr>';
r += "<tr><td>\n";
r += "<select class='form-control' ";
r += 'name="new_zone" ';
r += 'onchange="';
r += "ajax_RtcPost([true, ajaxGetFormValues('timezoneform')]);";
r += '" ';
r += ">\n";
var matchedSelection = false;
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var zz = xml.getElementsByTagName("zn" + (i + 1));
if(!zz || !zz.length)
{
break;
}
if(zz[0].firstChild)
{
var zv = zz[0].firstChild.nodeValue;
if(zv == zone)
{
matchedSelection = true;
}
}
}
if(! matchedSelection)
{
r += '<option value="" selected>';
r += GetMessage("rtc", 39);
r += "</option>\n";
}
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var zz = xml.getElementsByTagName("zn" + (i + 1));
if(!zz || !zz.length)
{
break;
}
if(zz[0].firstChild)
{
var zv = zz[0].firstChild.nodeValue;
r += '<option value="' + zv + '" ';
r += (zv == zone) ? " selected" : "";
r += ">";
var z = zv;
var j;
while((j = z.indexOf("/")) >= 0)
{
z = z.substring(j+1,z.length);
}
r += replaceString(z, "_", " ");
r += "</option>\n";
}
}
r += "</select>\n";
r += "</td></tr></table>";
r += "</td></tr></table>";
r += "</form>"
return r;
}
function updateSelectOptions(input,from,to)
{
var select = document.getElementsByName(input)[0];
if(select)
{
var optionslength = select.length;
for(var i=0;i<optionslength;i++)
select.remove(0);
for(var i=from;i<=to;i++)
{
var new_option = document.createElement("option");
new_option.value = i;
new_option.text = i<10?('0'+i):i;
try
{
select.add(new_option,x.options[null]);
}
catch (e)
{
select.add(new_option,null);
}
}
}
}
function TimeRender(xml)
{
updateSelectOptions("new_hour",0,23);
updateSelectOptions("new_minute",0,59);
updateSelectOptions("new_second",0,59);
return;
}
function DateRender(xml)
{
var yr = Number(GetXmlData(xml, "year"));
var yrsBack=2007;
updateSelectOptions("new_year",yrsBack,2037);
updateSelectOptions("new_month",1,12);
updateSelectOptions("new_day",1,31);
return;
}
function DateTimeRender(xml)
{
if(GetXmlData(xml, "year"))
{
document.getElementById('current_year').innerHTML = GetXmlData( xml, "year" );
document.getElementById('current_month').innerHTML = GetXmlData( xml, "month" );
document.getElementById('current_day').innerHTML = GetXmlData( xml, "day" );
document.getElementById('current_hour').innerHTML = GetXmlData( xml, "hour" );
document.getElementById('current_minute').innerHTML = GetXmlData( xml, "minute" );
document.getElementById('current_second').innerHTML = GetXmlData( xml, "second" );
DateRender(xml);
TimeRender(xml);
}
d = document.getElementById("TimeZoneRenderSection");
if(d && GetXmlData(xml, "zone")) {
var r = TimeZoneRender(xml);
d.innerHTML = "";
d.innerHTML = r;
}
return;
}
function SetRTCDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
GetMessageDisplay('rtc-header-display', "rtc", 40);
GetMessageDisplay('rtc-sub-header-display', "rtc", 21);
GetMessageDisplay('rtc-method-display', "rtc", 22);
GetMessageDisplay('rtc-sntp-display', "rtc", 24);
GetMessageDisplay('rtc-date-display', "rtc", 25);
GetMessageDisplay('rtc-year-display', "rtc", 26);
GetMessageDisplay('rtc-month-display', "rtc", 27);
GetMessageDisplay('rtc-day-display', "rtc", 28);
GetMessageDisplay('rtc-time-display', "rtc", 29);
GetMessageDisplay('rtc-24hour-display', "rtc", 30);
GetMessageDisplay('rtc-hour-display', "rtc", 31);
GetMessageDisplay('rtc-minute-display', "rtc", 32);
GetMessageDisplay('rtc-second-display', "rtc", 33);
document.getElementById('submit_button').value = GetMessage("strings",7);
document.getElementById("rtc_manual").text = GetMessage("rtc", 23);
GetMessageDisplay('rtc-timezonerender-display', "rtc", 34);
GetMessageDisplay('rtc-currenttime-display', "rtc", 35);
GetMessageDisplay('rtc-zone-display', "rtc", 36);
GetMessageDisplay('rtc-offset-display', "rtc", 37);
GetMessageDisplay('rtc-current-date-display', "rtc", 25);
GetMessageDisplay('rtc-current-time-display', "rtc", 29);
SetDisplaySelection('Clock.Synchronization_Method');
SetDisplaySelection('Clock.NTP.Server');
SetDisplaySelection('year');
SetDisplaySelection('month');
SetDisplaySelection('day');
SetDisplaySelection('hour');
SetDisplaySelection('minute');
SetDisplaySelection('second');
UpdateDateTimeDisplay(true);
enableDateAndTimeEdit();
document.getElementById("rtcform").style.display = "block";
}
function UpdateDateTimeDisplay(initial, optElement)
{
var methodManual = true;
var methodNTP = GetDisplayValue("new_Clock.Synchronization_Method") == "SNTP";
var methodNetwork = GetDisplayValue("new_Clock.Synchronization_Method") == "Network";
methodManual = GetDisplayValue("new_Clock.Synchronization_Method") == "Manual";
SetFxDisplay("sntp_Display", methodNTP ? "" : "none", initial);
SetFxDisplay("date_Display", methodManual ? "" : "none", initial);
SetFxDisplay("time_Display", methodManual ? "" : "none", initial);
if(methodManual)
{
enableDateAndTimeEdit();
}
Update(optElement);
}
function dateAndTimeDisable(input,disable)
{
var element = document.getElementsByName("new_"+input)[0];
if(element)
{
if(disable)
{
SetDisplayValue("new_"+input,GetDivValueById("current_"+input));
}
element.disabled=disable;
}
}
function enableDateAndTimeEdit()
{
var methodManual = true;
methodManual = GetDisplayValue("new_Clock.Synchronization_Method") == "Manual";
if(methodManual)
{
dateAndTimeDisable('year',false);
dateAndTimeDisable('month',false);
dateAndTimeDisable('day',false);
dateAndTimeDisable('hour',false);
dateAndTimeDisable('minute',false);
dateAndTimeDisable('second',false);
}
else
{
dateAndTimeDisable('year',true);
dateAndTimeDisable('month',true);
dateAndTimeDisable('day',true);
dateAndTimeDisable('hour',true);
dateAndTimeDisable('minute',true);
dateAndTimeDisable('second',true);
Update();
}
}
