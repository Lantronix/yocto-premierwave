var forceApplyButtonToBeVisible = false;
var forceSubmitButtonToBeVisible = false;
var forceTestButtonToBeVisible = false;
function IsApplyButtonForcedToBeVisible()
{
return forceApplyButtonToBeVisible;
}
function IsSubmitButtonForcedToBeVisible()
{
return forceSubmitButtonToBeVisible;
}
function IsTestButtonForcedToBeVisible()
{
return forceTestButtonToBeVisible;
}
function SetButtonVisibilities(xml)
{
forceTestButtonToBeVisible=true;
if(xml && xml.hasChildNodes)
{
for(var i = 0; i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "state")
{
forceApplyButtonToBeVisible = (
GetXmlData(node, "changes") == "pending"
);
forceSubmitButtonToBeVisible = (
GetXmlData(node, "flash") == "unsaved"
);
}
}
}
}
function InitializeSubmitButton(xml)
{
SetButtonVisibilities(xml);
if(document.getElementById('apply_button'))
{
if(! forceApplyButtonToBeVisible)
{
document.getElementById('apply_button').style.display='none';
}
}
if(document.getElementById('submit_button'))
{
if(! forceSubmitButtonToBeVisible)
{
document.getElementById('submit_button').style.display='none';
}
}
if(document.getElementById('reassert_button'))
{
document.getElementById('reassert_button').style.display='none';
}
if(document.getElementById('test_button'))
{
document.getElementById('test_button').style.display='none';
}
}
function SetFxDisplay(id, setting, init)
{
var element = document.getElementById(id);
if(element)
{
element.style.display=(setting != '')?'none':'';
}
}
function IsFxDisplayVisible(id)
{
var element = document.getElementById(id);
if(element)
{
return ((element.style.display!='none')?true:false);
}
}
