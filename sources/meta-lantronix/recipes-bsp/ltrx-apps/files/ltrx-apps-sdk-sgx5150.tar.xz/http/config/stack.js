function PrintArpCachePostResults(xml) { PrintMsg(xml, 'arpcacheresults'); }
function SetProtocolStackDisplay()
{
var menu=document.getElementById('protocol_stacks');
if(menu)menu.style.display='block';
var icon=document.getElementById('protocol_stack_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function SetIcmpDisplay(xml)
{
GetMessageDisplay('icmp_configuration',"strings",37);
GetMessageDisplay('icmp_state',"strings",46);
GetMessageDisplay('icmp_state_enabled',"strings",14);
GetMessageDisplay('icmp_state_disabled',"strings",15);
document.getElementById('submit_button').value=GetMessage("strings",7);
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Icmp.State');
document.getElementById("icmpform").style.display = "block";
SetProtocolStackDisplay();
}
function SetIpDisplay(xml)
{
GetMessageDisplay('ip_configuration',"strings",37);
GetMessageDisplay('ip_time_to_live',"stack",18);
GetMessageDisplay('ip_time_to_live_hops',"stack",19);
GetMessageDisplay('ip_multicast_time_to_live',"stack",20);
GetMessageDisplay('ip_multicast_time_to_live_hops',"stack",19);
document.getElementById('submit_button').value=GetMessage("strings",7);
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Ip.IP_Time_To_Live');
SetDisplaySelection('Ip.Multicast_Time_To_Live');
document.getElementById("ipform").style.display = "block";
SetProtocolStackDisplay();
}
function SetARPInterfaces(xml)
{
var parentForm = document.getElementById('arpcacheform');
parentForm.arpif.length = 0;
var i = 0;
if(xml)
{
var interfaces = xml.getElementsByTagName("interfaces");
for(i = 0; interfaces && i < interfaces.length; ++i)
{
var interface = interfaces[i].firstChild.nodeValue;
parentForm.arpif.options[i] = new Option(
interface, interface, false, false
);
}
}
}
function ArpCacheRender(xml)
{
GetMessageDisplay('arp_cache',"stack",15);
GetMessageDisplay('current_arp_cache',"stack",30);
GetMessageDisplay('arp_clear',"strings",120);
GetMessageDisplay('arp_add_a_new_entry',"stack",31);
GetMessageDisplay('arp_ip_address',"strings",101);
GetMessageDisplay('arp_mac_addres',"strings",121);
document.getElementById('arp_add_button').value=GetMessage("stack",17);
var d = document.getElementById('arpcachedata');
d.innerHTML = '';
var r = '';
var numIps = 0;
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead>";
r += "<tr>";
r += "<th>"+GetMessage("stack",32)+"</th>";
r += "<th>"+GetMessage("strings",121)+"</th>";
r += "<th>"+GetMessage("strings", 52)+"</th>";
r += "<th>"+GetMessage("strings",54)+"</th>";
r += "</tr>";
r += "</thead>";
r += "<tbody>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "a")
{
numIps++;
var ip = GetXmlData(node, "i");
var mac = GetXmlData(node, "m");
var dyn = GetXmlData(node, "d");
var iface = GetXmlData(node, "f");
r += "<tr>";
r += "<td>";
r += ip + " [<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "if(confirm('"+GetMessage("stack",25)+"'))";
r += "{";
r += "ajax_ArpCacheClean(";
r += "[true, 'action=delete&amp;ip=" + ip + "&amp;if=" + iface +"']";
r += ");";
r += "}";
r += "return false;";
r += "\"";
r += ">"+GetMessage("stack",26)+"";
r += "</a>]";
r += "</td>";
r += "<td>" + mac + "</td>";
r += "<td>" + dyn + "</td>";
r += "<td>" + iface + "</td>";
r += "</tr>";
}
}
r += "</tbody>";
r += "</table>";
if(! numIps)
{
d.innerHTML = ""+GetMessage("stack",27)+"<br/>";
}
else
{
d.innerHTML = r;
}
SetProtocolStackDisplay();
}
function SetSmtpDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Smtp.From_Address');
SetDisplaySelection('Smtp.Server_Address');
SetDisplaySelection('Smtp.Server_Port');
SetDisplaySelection('Smtp.Username');
SetDisplaySelection('Smtp.Password');
SetDisplaySelection('Smtp.Overriding_Domain');
SetDisplaySelection('Smtp.Local_Port');
document.getElementById("smtpform").style.display = "block";
}
