function SetRssDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Rss.Feed');
SetDisplaySelection('Rss.Persist');
SetDisplaySelection('Rss.Max_Entries');
document.getElementById("rssform").style.display = "block";
}
