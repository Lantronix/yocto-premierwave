function SetSftpServerDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('SFTP_Server.SFTP_State');
document.getElementById("sftpform").style.display = "block";
}
