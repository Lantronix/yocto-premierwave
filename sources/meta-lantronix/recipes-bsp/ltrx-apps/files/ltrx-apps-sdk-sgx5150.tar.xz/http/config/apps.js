function SetAppsDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Applications.Reserved_Start_Port');
SetDisplaySelection('Applications.Reserved_Ports');
document.getElementById("portsform").style.display = "block";
}
function Python_RunningScripts_Render(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr>";
r += "<td><b>Running scripts</b></td>";
r += "</tr></thead>";
r += "<tr>";
r += "<td><p>None</p></td>";
r += "</tr>";
r += "</table>";
var d = document.getElementById('running_python_scripts');
d.innerHTML=r;
}
else
{
var s="";
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr>";
r += "<td colspan='2'><b>Running scripts</b></td>";
r += "<td align='right'>";
r += "<input id='stop_all' ";
r += " onclick=\"if(confirm('Are you SURE you want to stop all python processes?')){ajax_AddToHistory('AppsPage',[true, 'kill_all_pid=true']);}return false;\"";
r += " type='button' class='btn btn-primary btn-sm' name='submit' value='Kill All'/>";
r += "</td>";
r += "</tr></thead>";
r += "<tr>";
r += "<td width='40%'><b>Script</b></td>";
r += "<td><b>% CPU</b></td>";
r += "<td><b>PID</b></td>";
r += "</tr>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
var installedPackages=0;
if(node.nodeName.toLowerCase() == "process")
{
var identifier=GetXmlData(node,"index");
var pid=GetXmlData(node,"pid");
var script=GetXmlData(node,"script");
s += "<tr>";
s += "<td>"+script+"</td>";
s += "<td>"+GetXmlData(node,"cpu_usage")+"</td>";
s += "<td>"+pid;
s += "&nbsp;&nbsp;";
s += "<a class=\"btn btn-primary btn-sm\" href=\"javascript:void(0)\" onclick=\"if(confirm('Are you SURE you want to stop this python processes?')){ajax_AddToHistory('AppsPage',[true, 'kill_pid="+pid+"']);}return false;\"";
s += ">";
s += "Kill";
s += "</a>";
s += "</td>";
s += "</tr>";
}
}
r += s;
r += "</table>";
var d = document.getElementById('running_python_scripts');
d.innerHTML=r;
}
}
function appsAddScriptRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve python scripts.</p>";
var d = document.getElementById('installed_python_scripts');
d.innerHTML=r;
}
else
{
var definedPythonScripts=0;
var p="";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "python_scripts_add")
{
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var add = node.childNodes[j];
if(add.nodeName.toLowerCase() == "script")
{
var identifier=GetXmlData(add,"index");
var state=GetXmlData(add,"state");
var onstart=GetXmlData(add,"onstart");
var onshutdown=GetXmlData(add,"onshutdown");
var filename=GetXmlData(add,"filename");
var parameters=GetXmlData(add,"parameters");
var output=GetXmlData(add,"output");
p += "<tr>";
p += "<td>"+(parseInt(identifier)+1)+"</td> ";
p += "<td>";
p += "<input id='run'";
p += " onclick=\"if(confirm('Are you SURE you want to run this script?')){this.blur();FileSystemMonitor();return ajax_AppsRun([true,'type=python&amp;instance="+identifier+"']);}return false;\"";
p += " class='btn btn-primary btn-sm' type='button' name='submit' value='Run'/> ";
p += "<input class='form-check-input' type='checkbox' ";
p += "onclick='updateButtonVisibilities(\"pythonform\",\"submit_changes\",\"cancel_changes\");' name='script_state." + identifier +"' org_state='"+state+"' ";
if(state=="true")p += " checked ";
p += "/>";
p += "</td>";
p += "<td>";
p += "<input class='form-check-input' type='checkbox' ";
p += "onclick='updateButtonVisibilities(\"pythonform\",\"submit_changes\",\"cancel_changes\");' name='script_delete." + identifier +"' org_state='false'/>";
p += "</td>";
p += "<td>";
p += "<input class='form-check-input' type='checkbox' ";
p += "onclick='updateButtonVisibilities(\"pythonform\",\"submit_changes\",\"cancel_changes\");' name='script_onstart." + identifier +"' org_state='"+onstart+"' ";
if(onstart=="true")p += " checked ";
p += "/>";
p += "</td>";
p += "<td>";
p += "<input class='form-check-input' type='checkbox' ";
p += "onclick='updateButtonVisibilities(\"pythonform\",\"submit_changes\",\"cancel_changes\");' name='script_onshutdown." + identifier +"' org_state='"+onshutdown+"' ";
if(onshutdown=="true")p += " checked ";
p += "/>";
p += "</td>";
p += "<td>";
p += "<a href=\"javascript:void(0)\" ";
p += " onclick=\"";
p += "ajax_AddToHistory(";
p += "'AppsPage',";
p += "[true, '&amp;menu=Python&amp;python_edit_identifier=" + identifier + "']";
p += ");";
p += "return false;";
p += "\"";
p += ">";
p += '<img class="fsimage" src="edit-icon.gif" width="20" height="20"/><br/>';
p += filename;
p += "</a>";
p += "</td>";
p += "<td>"+parameters+"</td> ";
p += "<td>"+output+"</td>";
p += "</tr>";
definedPythonScripts++;
}
}
}
}
if(definedPythonScripts==0)
{
p = "<tr><td colspan='8'><i>No scripts are defined </i></td></tr>";
}
r = "<table class='table table-striped table-condensed'>";
r += "<thead><tr><th width='10%'><b>Instance</b></th><th width='10%'><b>Enabled</b></th><th width='10%'><b>Delete</b></th><th width='10%'><b>Run on startup</b></th><th width='10%'><b>Run on shutdown</b></th><th><b>Script</b></th><th><b>Parameters</b></th><th><b>Output</b></th></tr></thead>";
r += p;
r += "</table>";
var d = document.getElementById('installed_python_scripts');
d.innerHTML=r;
updateButtonVisibilities('pythonform','submit_changes','cancel_changes');
document.getElementById("pythonform").style.display = "block";
r = '';
}
}
function appsEditScriptRender(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Invalid Python Script.</p>";
var d = document.getElementById('results');
d.innerHTML=r;
}
else
{
var definedPythonScripts=0;
var s="";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "python_scripts_add")
{
for(var j = 0; node && node.childNodes && j < node.childNodes.length; ++j)
{
var add = node.childNodes[j];
if(add.nodeName.toLowerCase() == "script")
{
s += "<table class='table table-striped table-condensed'>";
var identifier=GetXmlData(add,"index");
var state=GetXmlData(add,"state");
var onstart=GetXmlData(add,"onstart");
var onshutdown=GetXmlData(add,"onshutdown");
var filename=GetXmlData(add,"filename");
var parameters=GetXmlData(add,"parameters");
var output=GetXmlData(add,"output");
s += "<tr><td><b>Script</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='script_filename."+identifier+"' org_value='"+filename+"' value='"+filename+"' ";
s += "onkeyup='updateButtonVisibilities(\"scripts_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Parameters</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='script_parameters."+identifier+"' org_value='"+parameters+"' value='"+parameters+"' ";
s += "onkeyup='updateButtonVisibilities(\"scripts_edit\",\"submit_changes\",\"cancel_changes\");'/></td></tr>";
s += "<tr><td><b>Output</b></td>";
s += "<td><input type='text' size='32' maxlength='64' name='script_output."+identifier+"' org_value='"+output+"' value='"+output+"' ";
s += "onkeyup='updateButtonVisibilities(\"scripts_edit\",\"submit_changes\",\"cancel_changes\");'/></td>";
s += "</tr>";
s += "</table>";
definedPythonScripts++;
}
}
}
}
if(
definedPythonScripts==0
)
{
s = "<tr><td colspan='2'><i>Invalid Scripts.</i></td></tr>";
}
r += s;
var d = document.getElementById('scripts_edit_content');
d.innerHTML=r;
updateButtonVisibilities('scripts_edit','submit_changes','cancel_changes');
document.getElementById("scripts_edit").style.display = "block";
}
}
function SetAppsScriptAddDisplay()
{
document.getElementById("pythonaddform").reset();
document.getElementById("pythonaddform").style.display = "block";
document.getElementById("importform").reset();
updateButtonVisibilities('importform','install','uninstall');
document.getElementById("importform").style.display = "block";
document.getElementById("uninstallform").style.display = "block";
}
function SetAppsScriptEditDisplay()
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("scripts_edit").style.display = "block";
}
function Python_InstalledApps_Render(xml)
{
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += "<p>No installed packages</p>";
var d = document.getElementById('installed_python_packages');
d.innerHTML=r;
}
else
{
var s='';
var installedPackages=0;
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "package")
{
s += "<table class='table table-striped table-condensed'>";
var remove=GetXmlData(node,"remove");
var file=GetXmlData(node,"file");
var type=GetXmlData(node,"type");
s += "<thead>";
s += "<tr><td colspan='2' width='40%'>";
s += "<b>Package:</b>";
s += "</td></tr>";
s += "</thead>";
s += "<tbody>";
s += "<tr><td width='40%'><b>File</b></td><td>"+file;
if(remove=="yes")
{
s += "&nbsp;&nbsp;<input id='uninstall'";
s += " onclick=\"if(confirm('Are you SURE you want to uninstall this package?')){this.blur();FileSystemMonitor();return ajax_AppsInstall([true,'package="+file+"&amp;type=python&amp;mode="+type+"&amp;action=uninstall']);}return false;\"";
s += " class='btn btn-primary btn-sm' type='submit' name='submit' value='Uninstall'/>";
}
s += "</td></tr>";
var name=GetXmlData(node,"name");
if(name)s += "<tr><td width='40%'><b>Name</b></td><td>"+name+"</td></tr>";;
var version=GetXmlData(node,"version");
if(version)s += "<tr><td width='40%'><b>Version</b></td><td>"+version+"</td></tr>";
var summary=GetXmlData(node,"summary");
if(summary)s += "<tr><td width='40%'><b>Summary</b></td><td>"+summary+"</td></tr>";
s += "</tbody>";
s += "</table>";
installedPackages++;
}
if(node.nodeName.toLowerCase() == "python")
{
var installed=GetXmlData(node,"installed");
var remove=GetXmlData(node,"remove");
if(installed=="true")
{
var version=GetXmlData(node,"version");
s += "<table class='table table-striped table-condensed'>";
s += "<thead>";
s += "<tr><td width='40%'>";
s += "<b>Package:</b>";
s += "</td>";
s += "<td align='right'>";
s += "</td></tr>";
s += "</thead>";
s += "<tbody>";
s += "<tr><td width='40%'><b>File</b></td><td>Python";
if(remove=="yes")
{
s += "&nbsp;&nbsp;<input id='uninstall'";
s += " onclick=\"if(confirm('Are you SURE you want to uninstall python and all packages?')){this.blur();FileSystemMonitor();return ajax_AppsInstall([true,'package=python&amp;type=python&amp;mode=python&amp;action=uninstall']);}return false;\"";
s += " class='btn btn-primary btn-sm' type='submit' name='submit' value='Uninstall'/>";
}
s += "</td></tr>";
s += "<tr><td width='40%'><b>Version</b></td><td>"+version+"</td></tr>";
s += "</tbody>";
s += "</table>";
installedPackages++;
}
}
}
r += s;
if(installedPackages==0)
{
r = "<p>Python package not installed</p>";
}
else
{
r += "<input id='uninstall'";
r += " onclick=\"if(confirm('Are you SURE you want to uninstall all packages?')){this.blur();FileSystemMonitor();return ajax_AppsInstall([true,'package=python&amp;type=python&amp;mode=python&amp;action=uninstall']);}return false;\"";
r += " class='btn btn-primary btn-sm' type='submit' name='submit' value='Remove all'/>";
}
var d = document.getElementById('installed_python_packages');
d.innerHTML=r;
}
}
