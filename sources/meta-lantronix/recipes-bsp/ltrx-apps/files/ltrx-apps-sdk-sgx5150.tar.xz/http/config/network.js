function IPv6AddressRender(xml)
{
var r="";
var numAddresses=0
if(xml && xml.hasChildNodes())
{
var numAddresses=GetXmlData(xml, "numIPv6");
for(var ip=0;ip<numAddresses;ip++)
{
address=GetXmlData(xml, "net6ip"+ip);
r += address;
r += "<br>";
}
}
if(numAddresses==0)
{
r = "<"+GetMessage("strings",47)+">";
}
var e=document.getElementById('net6ip');
if(e)
{
e.innerHTML=r;
}
}
function IPv6GatewayRender(xml)
{
var r="";
var numAddresses=0
if(xml && xml.hasChildNodes())
{
var numAddresses=GetXmlData(xml, "numGateway");
for(var ip=0;ip<numAddresses;ip++)
{
address=GetXmlData(xml, "net6gw"+ip);
r += address;
r += "<br>";
}
}
if(numAddresses==0)
{
r = "<"+GetMessage("strings",47)+">";
}
var e=document.getElementById('net6gateway');
if(e)
{
e.innerHTML=r;
}
}
function EnableSubmitButton(xml)
{
if(document.getElementById('apply_button'))
{
document.getElementById('apply_button').disabled=false;
}
if(document.getElementById('test_button'))
{
document.getElementById('test_button').disabled=false;
}
if(document.getElementById('submit_button'))
{
document.getElementById('submit_button').disabled=false;
}
}
function EnableTestConnectionButton(enable)
{
if(document.getElementById('test_button'))
{
document.getElementById('test_button').disabled=!enable;
}
}
function SetNetworkLinks(xml)
{
if(xml && xml.hasChildNodes())
{
document.getElementById('netdhcpD').style.display=((GetXmlData(xml,"ipv4_dhcp")=="true")?"inline":"none");
document.getElementById('netdhcpD6').style.display=((GetXmlData(xml,"ipv6_dhcp")=="true")?"inline":"none");
}
}
function ScanningLatencyUpdate()
{
var suite = GetInputElementValue(
document.forms[0].elements["new_WLAN.Scanning_Latency"]
);
if(suite == "Standard")
{
document.getElementById("Scanning_Channel_List").style.display="";
}
else
{
document.getElementById("Scanning_Channel_List").style.display="none";
}
Update();
}
function SetInterfaceDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
GetMessageDisplay('interface_configuration',"net",127);
GetMessageDisplay('network_state',"strings",46);
GetMessageDisplay('network_enabled',"strings",14);
GetMessageDisplay('network_disabled',"strings",15);
SetDisplaySelection('Interface.State');
SetDisplaySelection('Interface.DHCP');
GetMessageDisplay('dhcp_client',"net",130);
GetMessageDisplay('dhcp_client_on',"net",129);
GetMessageDisplay('dhcp_client_off',"strings",74);
GetMessageDisplay('network_priority',"net",131);
SetDisplaySelection('Interface.Priority');
GetMessageDisplay('network_ip_address',"strings",101);
GetMessageDisplay('network_default_gateway',"strings",99);
GetMessageDisplay('network_hostname',"strings",103);
GetMessageDisplay('network_domain',"strings",75);
GetMessageDisplay('dhcp_client_id',"net",133);
GetMessageDisplay('primary_dns',"strings",61);
GetMessageDisplay('secondary_dns',"strings",62);
document.getElementById('submit_button').value=GetMessage("strings",7);
SetDisplaySelection('Interface.Domain');
SetDisplaySelection('Interface.Hostname');
SetDisplaySelection('Interface.DHCP_Client_ID');
SetDisplaySelection('Interface.Default_Gateway');
SetDisplaySelection('Interface.IP_Address');
SetDisplaySelection('Interface.Primary_DNS');
SetDisplaySelection('Interface.Secondary_DNS');
GetMessageDisplay('ipv4_state',"strings",46);
GetMessageDisplay('ipv4_enabled',"strings",14);
GetMessageDisplay('ipv4_disabled',"strings",15);
SetDisplaySelection('Interface.IPv4_State');
GetMessageDisplay('ipv6_state',"strings",46);
GetMessageDisplay('ipv6_enabled',"strings",14);
GetMessageDisplay('ipv6_disabled',"strings",15);
SetDisplaySelection('Interface.IPv6_State');
GetMessageDisplay('dhcp6_client',"net",130);
GetMessageDisplay('dhcp6_client_on',"net",129);
GetMessageDisplay('dhcp6_client_off',"strings",74);
SetDisplaySelection('Interface.IPv6_DHCP');
GetMessageDisplay('autoconf_on',"net",129);
GetMessageDisplay('autoconf_off',"strings",74);
SetDisplaySelection('Interface.IPv6_Auto_Configure');
GetMessageDisplay('network6_ip_address',"strings",101);
SetDisplaySelection('Interface.IPv6_Address');
GetMessageDisplay('network6_default_gateway',"strings",99);
SetDisplaySelection('Interface.IPv6_Default_Gateway');
GetMessageDisplay('network6_domain',"strings",75);
SetDisplaySelection('Interface.IPv6_Domain');
GetMessageDisplay('primary_dns6',"strings",61);
GetMessageDisplay('secondary_dns6',"strings",62);
SetDisplaySelection('Interface.IPv6_Primary_DNS');
SetDisplaySelection('Interface.IPv6_Secondary_DNS');
SetDisplaySelection('Interface.MTU');
document.getElementById("networkform").style.display = "block";
}
function NetworkStatsDisplay()
{
GetMessageDisplay('interface_status',"net",140);
GetMessageDisplay('stat_interface_current',"net",141);
GetMessageDisplay('stat_interface_after_reboot',"net",142);
GetMessageDisplay('stat_interface_state',"strings",46);
GetMessageDisplay('stat_interface_dhcp_client',"net",130);
GetMessageDisplay('stat_interface_renew',"net",143);
GetMessageDisplay('stat_interface_priority',"net",131);
GetMessageDisplay('stat_interface_ip_address',"strings",101);
GetMessageDisplay('stat_interface_network_mask',"strings",102);
GetMessageDisplay('stat_interface_default_gateway',"strings",99);
GetMessageDisplay('stat_interface_hostname',"strings",103);
GetMessageDisplay('stat_interface_domain',"strings",75);
GetMessageDisplay('stat_interface_dns_suffix',"net",132);
GetMessageDisplay('stat_interface_dhcp_client_id',"net",133);
GetMessageDisplay('stat_interface_primary_dns',"strings",61);
GetMessageDisplay('stat_secondary_dns',"strings",62);
GetMessageDisplay('stat_interface_ipv4_state',"strings",46);
GetMessageDisplay('stat_interface_ipv6_state',"strings",46);
GetMessageDisplay('stat_interface_dhcp6_client',"net",130);
GetMessageDisplay('stat_interface_ip_address6',"strings",101);
GetMessageDisplay('stat_interface_default_gateway6',"strings",99);
GetMessageDisplay('stat_interface_domain6',"strings",75);
GetMessageDisplay('stat_interface_primary_dns6',"strings",61);
GetMessageDisplay('stat_secondary_dns6',"strings",62);
GetMessageDisplay('stat_interface_stats',"strings",36);
GetMessageDisplay('stat_interface_received',"net",144);
GetMessageDisplay('stat_interface_rx_bytes',"strings",55);
GetMessageDisplay('stat_interface_transmitted',"net",145);
GetMessageDisplay('stat_interface_tx_bytes',"strings",55);
}
function SetNetworkFailoverDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Network_Failover.State');
SetDisplaySelection('Network_Failover.Hostname');
SetDisplaySelection('Network_Failover.Method');
SetDisplaySelection('Network_Failover.Timeout');
SetDisplaySelection('Network_Failover.Interval');
SetDisplaySelection('Network_Failover.Failover_Threshold');
SetDisplaySelection('Network_Failover.Failback_Threshold');
SetDisplaySelection('Network_Failover.Failover_Interface');
document.getElementById("networkfailoverform").style.display = "block";
var parentForm = document.getElementById('networkfailoverform');
parentForm.selectedFailoverInterface.length = 0;
var i = 0;
if(xml)
{
var selected=xml.getElementsByTagName("selected");
if(selected && selected.length>0)
{
var selectedInterface=selected[0].firstChild.nodeValue;
document.getElementById("new_Network_Failover.Failover_Interface").value=selectedInterface;
}
var interfaces = xml.getElementsByTagName("interface");
for(i = 0; interfaces && i < interfaces.length; ++i)
{
var interface = interfaces[i].firstChild.nodeValue;
parentForm.selectedFailoverInterface.options[i] = new Option(
interface, interface, false, false
);
if(interface==selectedInterface)
{
parentForm.selectedFailoverInterface.selectedIndex=i;
}
}
}
}
function updateFilterType()
{
var type=document.getElementById("filter_type").value;
if(document.getElementById("mac_Display"))
{
document.getElementById("mac_Display").style.display='none';
document.getElementById("mac_help_display").style.display='';
}
else
{
document.getElementById("mac_help_display").style.display='none';
}
document.getElementById("network_Display").style.display='none';
document.getElementById("port_Display").style.display='none';
if(type=="mac")
{
if(document.getElementById("mac_Display"))
document.getElementById("mac_Display").style.display='';
}
if(type=="network")
{
document.getElementById("network_Display").style.display='';
}
if(type=="ports")
{
document.getElementById("port_Display").style.display='';
}
}
function QoSStatsRender(xml)
{
var s= "";
if(!xml || !xml.hasChildNodes())
{
s += "<p>QoS statistics are not available</p>";
}
else
{
s = "<table class='table table-striped table-condensed'>";
s += "<thead><tr><td width='20%'>Priority</td><td width='40%'>Sent</td><td width='40%'>Rate</td></tr></thead><tbody>";
var sent=GetXmlData(xml,"sent_1");
var rate=GetXmlData(xml,"rate_1");
var percent=GetXmlData(xml,"percent_1");
s += "<tr><td>Network Control</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_2");
rate=GetXmlData(xml,"rate_2");
percent=GetXmlData(xml,"percent_2");
s += "<tr><td>Internetwork Control</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_3");
rate=GetXmlData(xml,"rate_3");
percent=GetXmlData(xml,"percent_3");
s += "<tr><td>Voice</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_4");
rate=GetXmlData(xml,"rate_4");
percent=GetXmlData(xml,"percent_4");
s += "<tr><td>Video</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_5");
rate=GetXmlData(xml,"rate_5");
percent=GetXmlData(xml,"percent_5");
s += "<tr><td>Critical Applications</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_6");
rate=GetXmlData(xml,"rate_6");
percent=GetXmlData(xml,"percent_6");
s += "<tr><td>Excellent Effort</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_7");
rate=GetXmlData(xml,"rate_7");
percent=GetXmlData(xml,"percent_7");
s += "<tr><td>Best Effort</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_8");
rate=GetXmlData(xml,"rate_8");
percent=GetXmlData(xml,"percent_8");
s += "<tr><td>Background</td><td>"+sent+"</td><td>"+rate+" ("+percent+")</td></tr>";
sent=GetXmlData(xml,"sent_0");
rate=GetXmlData(xml,"rate_0");
s += "<tr><td><b>Total</b></td><td>"+sent+"</td><td>"+rate+"</td></tr>";
s += "</tbody></table>";
}
var d = document.getElementById('qos_statistics');
if(d)d.innerHTML=s;
}
function QoSRender(xml)
{
var c = "";
var m = "";
var n = "";
var p = "";
if(! xml || ! xml.hasChildNodes())
{
c = "<p>Failed to retrieve QoS settings.</p>";
var d = document.getElementById('qos_configuration');
d.innerHTML=c;
}
else
{
c = "<table class='table table-striped table-condensed'>";
c += "<tbody>";
m = "<table class='table table-striped table-condensed'>";
m += "<thead><tr><td><b>Delete</b></td><td width='40%'><b>MAC Address</b></td><td><b>Priority</b></td></tr></thead><tbody>";
n = "<table class='table table-striped table-condensed'>";
n += "<thead><tr><td><b>Delete</b></td><td width='40%'><b>Network</b></td><td><b>Priority</b></td></tr></thead><tbody>";
p = "<table class='table table-striped table-condensed'>";
p += "<thead><tr><td><b>Delete</b></td><td width='40%'><b>Port or Port Range</b></td><td><b>Priority</b></td></tr></thead><tbody>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "qos")
{
for(var j = 0; node && j < node.childNodes.length; ++j)
{
var node2 = node.childNodes[j];
if(node2.nodeName.toLowerCase() == "state")
{
var isEnabled=(node2.firstChild.nodeValue=='Enabled')?true:false;
c += "<tr><td width='40%'><b>State:</b></td><td>";
c += "<label class='radio-inline'>";
c += "<input ";
c += "onclick='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'";
c += " name='qos_state' type='radio' value='Enabled'";
c += " org_state='"+isEnabled+"'";
if(isEnabled)c += " checked ";
c += "/>Enabled";
c += "</label>";
c += "<label class='radio-inline'>";
c += "<input ";
c += "onclick='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'";
c += " name='qos_state' type='radio' value='Disabled'";
c += " org_state='"+!isEnabled+"'";
if(!isEnabled)c += " checked ";
c += "/>Disabled";
c += "</label>";
c += "</td></tr>";
}
if(node2.nodeName.toLowerCase() == "import_filters")
{
var isEnabled=(node2.firstChild.nodeValue=='Enabled')?true:false;
c += "<tr><td width='40%'><b>Import filters:</b></td><td>";
c += "<label class='radio-inline'>";
c += "<input ";
c += "onclick='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'";
c += " name='import_filters' type='radio' value='Enabled'";
c += " org_state='"+isEnabled+"'";
if(isEnabled)c += " checked ";
c += "/>Enabled";
c += "</label>";
c += "<label class='radio-inline'>";
c += "<input ";
c += "onclick='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'";
c += " name='import_filters' type='radio' value='Disabled'";
c += " org_state='"+!isEnabled+"'";
if(!isEnabled)c += " checked ";
c += "/>Disabled";
c += "</label>";
c += "</td></tr>";
}
if(node2.nodeName.toLowerCase() == "uplink_speed")
{
var uplink_speed=node2.firstChild.nodeValue;
c += "<tr><td width='40%'><b>Uplink Speed:</b></td><td><input type='text' size='10' maxlength='10' name='uplink_speed' org_value='"+uplink_speed+"' value='"+uplink_speed+"' ";
c += "onkeyup='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'/> kbps</td></tr>";
}
if(node2.nodeName.toLowerCase() == "filter")
{
var index=GetXmlData(node2,"index");
var priority=GetXmlData(node2,"priority");
var mac=GetXmlData(node2,"mac");
if(mac)
{
m += "<tr>";
m += "<td>"
m += "<input type='checkbox' ";
m += " onclick='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");' ";
m += " name='filter_" + index +".state' org_state='false'/>";
m += "</td>";
m += "<td width='40%'>";
m += "<input type='text' size='16' maxlength='64' name='filter_"+index+".mac' org_value='"+mac+"' value='"+mac+"' ";
m += " onkeyup='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'/>";
m += "</td>";
m += "<td><table><tr><td><select class='form-control'  name='filter_"+index+".priority' org_value='"+priority+"' onchange='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'>";
m += "<option value='Network Control'";
if(priority=='Network Control')
{
m += " selected";
}
m += ">Network Control</option>";
m += "<option value='Internetwork Control'";
if(priority=='Internetwork Control')
{
m += " selected";
}
m += ">Internetwork Control</option>";
m += "<option value='Voice'";
if(priority=='Voice')
{
m += " selected";
}
m += ">Voice</option>";
m += "<option value='Video'";
if(priority=='Video')
{
m += " selected";
}
m += ">Video</option>";
m += "<option value='Critical Applications'";
if(priority=='Critical Applications')
{
m += " selected";
}
m += ">Critical Applications</option>";
m += "<option value='Excellent Effort'";
if(priority=='Excellent Effort')
{
m += " selected";
}
m += ">Excellent Effort</option>";
m += "<option value='Best Effort'";
if(priority=='Best Effort')
{
m += " selected";
}
m += ">Best Effort</option>";
m += "<option value='Background'";
if(priority=='Background')
{
m += " selected";
}
m += ">Background</option>";
m += "</select></td></tr></table></td>";
m += "</tr>";
}
var network=GetXmlData(node2,"network");
if(network)
{
n += "<tr>";
n += "<td>"
n += "<input type='checkbox' ";
n += " onclick='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");' ";
n += " name='filter_" + index +".state' org_state='false'/>";
n += "</td>";
n += "<td width='40%'>";
n += "<input type='text' size='16' maxlength='64' name='filter_"+index+".network' org_value='"+network+"' value='"+network+"' ";
n += " onkeyup='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'/>";
n += "</td>";
n += "<td><table><tr><td><select class='form-control' name='filter_"+index+".priority' org_value='"+priority+"' onchange='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'>";
n += "<option value='Network Control'";
if(priority=='Network Control')
{
n += " selected";
}
n += ">Network Control</option>";
n += "<option value='Internetwork Control'";
if(priority=='Internetwork Control')
{
n += " selected";
}
n += ">Internetwork Control</option>";
n += "<option value='Voice'";
if(priority=='Voice')
{
n += " selected";
}
n += ">Voice</option>";
n += "<option value='Video'";
if(priority=='Video')
{
n += " selected";
}
n += ">Video</option>";
n += "<option value='Critical Applications'";
if(priority=='Critical Applications')
{
n += " selected";
}
n += ">Critical Applications</option>";
n += "<option value='Excellent Effort'";
if(priority=='Excellent Effort')
{
n += " selected";
}
n += ">Excellent Effort</option>";
n += "<option value='Best Effort'";
if(priority=='Best Effort')
{
n += " selected";
}
n += ">Best Effort</option>";
n += "<option value='Background'";
if(priority=='Background')
{
n += " selected";
}
n += ">Background</option>";
n += "</select></td></tr></table></td>";
n += "</tr>";
}
var ports=GetXmlData(node2,"ports");
if(ports)
{
p += "<tr>";
p += "<td>"
p += "<input type='checkbox' ";
p += " onclick='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");' ";
p += " name='filter_" + index +".state' org_state='false'/>";
p += "</td>";
p += "<td width='40%'>";
p += "<input type='text' size='16' maxlength='64' name='filter_"+index+".ports' org_value='"+ports+"' value='"+ports+"' ";
p += " onkeyup='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'/>";
p += "</td>";
p += "<td><table><tr><td><select class='form-control'  name='filter_"+index+".priority' org_value='"+priority+"' onchange='updateButtonVisibilities(\"networkqosform\",\"submit_changes\",\"cancel_changes\");'>";
p += "<option value='Network Control'";
if(priority=='Network Control')
{
p += " selected";
}
p += ">Network Control</option>";
p += "<option value='Internetwork Control'";
if(priority=='Internetwork Control')
{
p += " selected";
}
p += ">Internetwork Control</option>";
p += "<option value='Voice'";
if(priority=='Voice')
{
p += " selected";
}
p += ">Voice</option>";
p += "<option value='Video'";
if(priority=='Video')
{
p += " selected";
}
p += ">Video</option>";
p += "<option value='Critical Applications'";
if(priority=='Critical Applications')
{
p += " selected";
}
p += ">Critical Applications</option>";
p += "<option value='Excellent Effort'";
if(priority=='Excellent Effort')
{
p += " selected";
}
p += ">Excellent Effort</option>";
p += "<option value='Best Effort'";
if(priority=='Best Effort')
{
p += " selected";
}
p += ">Best Effort</option>";
p += "<option value='Background'";
if(priority=='Background')
{
p += " selected";
}
p += ">Background</option>";
p += "</select></td></tr></table></td>";
p += "</tr>";
}
}
}
}
}
c += "</tbody></table>";
var d = document.getElementById('qos_configuration');
if(d)d.innerHTML=c;
m += "</tbody></table>";
d = document.getElementById('mac_filter_configuration');
if(d)d.innerHTML=m;
n += "</tbody></table>";
d = document.getElementById('network_filter_configuration');
if(d)d.innerHTML=n;
p += "</tbody></table>";
d = document.getElementById('ports_filter_configuration');
if(d)d.innerHTML=p;
updateButtonVisibilities('networkqosform','submit_changes','cancel_changes');
}
}
function SetNetworkQoSDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
document.getElementById("networkqosform").style.display = "block";
document.getElementById("new_filter").reset();
updateFilterType();
document.getElementById("new_filter").style.display = "block";
}
function EthernetSpeedChange(value)
{
if(value == "Auto")
{
SetFxDisplay("ethernetduplexauto_Display", "");
SetFxDisplay("ethernetduplexhalf_Display", "");
SetFxDisplay("ethernetduplexfull_Display", "none");
}
else
{
SetFxDisplay("ethernetduplexauto_Display", "none");
SetFxDisplay("ethernetduplexhalf_Display", "");
SetFxDisplay("ethernetduplexfull_Display", "");
}
Update();
}
function BuildEapolConfigPage(xml)
{
GetMessageDisplay('ethernet_link_configuration',"net",139);
GetMessageDisplay('link_config_speed',"strings",60);
GetMessageDisplay('speed_auto',"net",135);
GetMessageDisplay('speed_10_mbps',"net",136);
GetMessageDisplay('speed_100_mbps',"net",136);
GetMessageDisplay('link_config_duplex',"net",134);
GetMessageDisplay('duplex_auto',"net",135);
GetMessageDisplay('duplex_half',"net",137);
GetMessageDisplay('duplex_full',"net",138);
GetMessageDisplay('link_config_eapol',"net",319);
GetMessageDisplay('eapol_enable',"strings",14);
GetMessageDisplay('eapol_disable',"strings",15);
GetMessageDisplay('eapol_security_configuration',"net",320);
GetMessageDisplay('eapol_validate_certificate_enabled',"strings",14);
GetMessageDisplay('eapol_validate_certificate_disabled',"strings",15);
document.getElementById('submit_button').value=GetMessage("strings",7);
var d = document.getElementById('select_eapol_credential1');
d.options.length = 0;
var unlistedStr="<"+GetMessage("strings",163)+">";
d.options[0] = new Option(unlistedStr, "", true);
d.options[1] = new Option("device-certificate", "device-certificate", true);
for(var i = 0; xml && xml.hasChildNodes() && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "ssl_credential")
{
var name = GetXmlData(node, "name");
d.options[d.options.length] = new Option(name, name);
}
}
SetFxDisplay(
"select_eapol_credential_Display1",
d.options.length > 1 ? "" : "none",
true
);
}
function EthernetEapol_TogglePasswordType(checkbox,target)
{
if(document.getElementById(checkbox).checked)
document.getElementById(target).type='text';
else
document.getElementById(target).type='password';
}
function EthernetEapolChange()
{
SetFxDisplay("etherneteapolenable_Display", "");
SetFxDisplay("etherneteapoldisable_Display", "");
}
function EthernetEapolConfigUpdate(initial, optElement)
{
var eapol_state = GetInputElementValue(
document.forms[0].elements["new_Ethernet.EAPoL"]
);
var show = eapol_state == "Enabled";
var init = true;
var ieee802_1x_option = GetInputElementValue(
document.forms[0].elements["new_Ethernet.IEEE_802_1X"]
);
SetFxDisplay("eapol_security_configuration", show ? "": "none", init);
SetFxDisplay("eapol_ieee_802_1x_Display", show ? "" : "none", init);
SetFxDisplay(
"eapol_eap_ttls_option_Display",
show && ieee802_1x_option == "EAP-TTLS" ? "" : "none", init);
SetFxDisplay(
"eapol_eap_ttls_option",
show && ieee802_1x_option == "EAP-TTLS" ? "" : "none", init);
SetFxDisplay(
"eapol_peap_option_Display",
show && ieee802_1x_option == "PEAP" ? "" : "none", init);
SetFxDisplay(
"eapol_peap_option",
show && ieee802_1x_option == "PEAP" ? "" : "none", init);
SetFxDisplay(
"eapol_fast_option_Display",
show && ieee802_1x_option == "FAST" ? "" : "none", init);
SetFxDisplay(
"eapol_fast_option",
show && ieee802_1x_option == "FAST" ? "" : "none", init);
var fast_option = GetInputElementValue(
document.forms[0].elements["new_Ethernet.Fast_Option"]
);
SetFxDisplay(
"eapol_fast_provisioning_Display",
show && ieee802_1x_option == "FAST" && fast_option == "MSCHAPV2" ? "" : "none", init);
SetFxDisplay(
"eapol_fast_provisioning",
show && ieee802_1x_option == "FAST" && fast_option == "MSCHAPV2" ? "" : "none", init);
var Username = show ? "" : "none";
var Password = show && ieee802_1x_option != "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_username_Display", Username, init);
SetFxDisplay("eapol_password_Display", Password, init);
var validate_cert = show && ieee802_1x_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_validate_certificate_Display", validate_cert, init);
SetFxDisplay("eapol_validate_certificate", validate_cert, init);
var credentials = show && ieee802_1x_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_credentials_Display", credentials, init);
SetFxDisplay("eapol_credentials", credentials, init);
var n = GetInputElementValue(
document.forms[0].elements["new_Ethernet.Credentials"]
);
SetFxDisplay("eapol_credentials_selection_Display1", n == "" ? "" : "none", init);
var peap_option = GetInputElementValue(
document.forms[0].elements["new_Ethernet.PEAP_Option"]
);
var inner_credentials =
show && ieee802_1x_option == "PEAP" && peap_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_inner_credentials_Display", inner_credentials, init);
SetFxDisplay("eapol_inner_credentials", inner_credentials, init);
Update(optElement);
}
function SetEthernetDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
var speed = SetDisplaySelection('Ethernet.Speed');
EthernetSpeedChange(speed);
SetDisplaySelection('Ethernet.Duplex');
EthernetEapolChange();
SetDisplaySelection('Ethernet.EAPoL');
var eapol_state = SetDisplaySelection('Ethernet.EAPoL');
var show = eapol_state == "Enabled";
var init = true;
var ieee802_1x_option = SetDisplaySelection('Ethernet.IEEE_802_1X');
SetFxDisplay("eapol_security_configuration", show ? "": "none", init);
SetFxDisplay("eapol_ieee_802_1x_Display", show ? "" : "none", init);
SetFxDisplay(
"eapol_eap_ttls_option_Display",
show && ieee802_1x_option == "EAP-TTLS" ? "" : "none", init);
SetFxDisplay(
"eapol_peap_option_Display",
show && ieee802_1x_option == "PEAP" ? "" : "none", init);
SetFxDisplay(
"eapol_fast_option_Display",
show && ieee802_1x_option == "FAST" ? "" : "none", init);
var fast_option = SetDisplaySelection('Ethernet.Fast_Option');
SetFxDisplay(
"eapol_fast_provisioning_Display",
show && ieee802_1x_option == "FAST" && fast_option == "MSCHAPV2" ? "" : "none", init);
var Username = show ? "" : "none";
var Password = show && ieee802_1x_option != "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_username_Display", Username, init);
SetFxDisplay("eapol_password_Display", Password, init);
var validate_cert = show && ieee802_1x_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_validate_certificate_Display", validate_cert, init);
var credentials = show && ieee802_1x_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_credentials_Display", credentials, init);
var c = SetDisplaySelection('Ethernet.Credentials');
SetDisplayValue('new_Ethernet.Select_Credentials', c);
SetFxDisplay("eapol_credentials_selection_Display1", c == "" ? "" : "none", init);
var peap_option = SetDisplaySelection('Ethernet.PEAP_Option');
var inner_credentials =
show && ieee802_1x_option == "PEAP" && peap_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("eapol_inner_credentials_Display", inner_credentials, init);
SetDisplaySelection('Ethernet.IEEE_802_1X');
SetDisplaySelection('Ethernet.EAP_TTLS_Option');
SetDisplaySelection('Ethernet.PEAP_Option');
SetDisplaySelection('Ethernet.Fast_Option');
SetDisplaySelection('Ethernet.Fast_Provisioning');
SetDisplaySelection('Ethernet.Username');
SetDisplaySelection('Ethernet.Password');
SetDisplaySelection('Ethernet.Validate_Certificate');
SetDisplaySelection('Ethernet.Credentials');
SetDisplaySelection('Ethernet.Inner_Credentials');
document.getElementById("networkethform").style.display = "block";
}
function EthernetLinkConfigDisplay(xml)
{
GetMessageDisplay('ethernet_link_configuration',"net",139);
GetMessageDisplay('link_config_speed',"strings",60);
GetMessageDisplay('speed_auto',"net",135);
GetMessageDisplay('speed_10_mbps',"net",136);
GetMessageDisplay('speed_100_mbps',"net",136);
GetMessageDisplay('link_config_duplex',"net",134);
GetMessageDisplay('duplex_auto',"net",135);
GetMessageDisplay('duplex_half',"net",137);
GetMessageDisplay('duplex_full',"net",138);
document.getElementById('submit_button').value=GetMessage("strings",7);
}
function EthernetLinkStatsDisplay()
{
GetMessageDisplay('ethernet_link',"strings",58);
GetMessageDisplay('link_stat_speed',"strings",60);
GetMessageDisplay('link_stat_duplex',"net",134);
GetMessageDisplay('link_stat_eapol',"net",319);
}
function EthernetConfigPostProcedure()
{
FileSystemMonitor();
return ajax_EthernetConfPost(
[
true,
ajaxGetFormValuesWithoutClearingThem('networkethform')
]
);
}
function NetworkRender(xml)
{
var netno = Number(document.getElementById("hiddennetwork").innerHTML);
var menu=document.getElementById('networknav'+(netno+1)+'_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('networknav'+(netno+1)+'_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
if(netno>=(1 +1) && netno<((1 +1)+0))
{
var failoverLink=document.getElementById("networknavfailover");
if(failoverLink)
{
failoverLink.style.visibility='hidden';
var secondLevelMenu=document.getElementById("hiddennetworkinterfacelink");
if(secondLevelMenu)
{
if(secondLevelMenu.innerHTML=='failover')
{
secondLevelMenu.innerHTML='interface';
var thirdLevelMenu= document.getElementById('hiddennetworkstatusconfig');
if(thirdLevelMenu)
{
if(thirdLevelMenu.innerHTML!='1')
{
thirdLevelMenu.innerHTML='1';
}
}
}
}
}
}
if(netno>=(1) && netno<(1 +1))
{
var navlink = document.getElementById("networknavlink_3");
if(navlink)
{
navlink.style.visibility='visible';
}
}
else
{
var navlink = document.getElementById("networknavlink_3");
if(navlink)
{
navlink.style.visibility='hidden';
}
}
var d = document.getElementById("multinetworkdropdown");
if(d)
{
var r = "<table><tr><td><select class='form-control' name='navSelect' ";
r += "id='navSelect' ";
r += "onchange=\" ";
r += "var netno=this.value";
r += "if(netno<MAX_NETS_ETHERNET + MAX_NETS_WLAN + MAX_NETS_CELLULAR + MAX_NETS_USB)";
r += "{";
r += "var nav2 = document.getElementById('hiddennetworkinterfacelink').innerHTML;";
r += "var nav3 = document.getElementById('hiddennetworkstatusconfig').innerHTML;";
r += "document.getElementById('hiddennetwork').innerHTML = this.value;";
r += "return ajax_AddToHistory(";
r += "'NetworkPage', ";
r += "[true, 'netnumber=' + this.value + '&2=' + nav2 + '&3=' + nav3]";
r += ");";
r += "}";
r += ">";
for(var i = 0; i < 1 + 1 + 0 + 1; ++i)
{
var sel;
if(netno == i)
{
sel = " SELECTED ";
}
else
{
sel = "";
}
r += "<option value='" + i + "' " + sel + ">";
r += ""+GetMessage("strings", 1)+" " + (i + 1);
r += "</option>";
}
r += "</select></td></tr></table>";
d.innerHTML = "";
d.innerHTML = r;
}
UpdateScanTable(xml);
return;
}
function WLANLinkStatusDisplay()
{
GetMessageDisplay('wlan_link_status',"net",180);
GetMessageDisplay('wlan_link_stat_property_name',"net",181);
GetMessageDisplay('wlan_link_stat_property_value',"strings",0);
}
function WLANScanDisplay()
{
GetMessageDisplay('wlan_link_scan',"net",177);
GetMessageDisplay('wlan_link_network_name',"net",178);
document.getElementById('wlan_scan_submit_button').value=GetMessage("net",231);
GetMessageDisplay('wlan_scan_autorefresh',"net",179);
}
function UpdateScanTable(xml)
{
var scanResultTable = document.getElementById("wlanScanTable");
if(scanResultTable && scanResultTable.rows.length>1)
{
var row=scanResultTable.rows[1];
while(row && row.getElementsByTagName('td').length>3)
{
ch=row.getElementsByTagName('td')[2];
var channel=parseInt(ch.innerHTML);
rssi=row.getElementsByTagName('td')[3];
var strength=parseInt(rssi.innerHTML);
var originalContent=rssi.innerHTML;
rssi.innerHTML=GenerateSignalStrengthIndicator(channel,strength)+originalContent;
row=row.nextSibling;
}
}
}
function SetWLANScanSSID(xml)
{
var d = document.getElementById('ssid');
if(d){
d.value=GetXmlData(xml, "value").replace(/&#(\d{0,4});/, function(input, str) { return String.fromCharCode(str); });
}
}
var configUnsaved=false;
function clearWLANProfileUpdates(formId)
{
var objForm = document.getElementById(formId);
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
var name = formElements[i].name;
if (name)
{
if(0==formElements[i].name.indexOf('wlan_profile_delete.') && formElements[i].type == 'checkbox')
formElements[i].checked=false;
if(0==formElements[i].name.indexOf('wlan_profile_state.') && formElements[i].type == 'checkbox')
{
formElements[i].checked = (formElements[i].getAttribute('wlan_profile_state')=="true");
}
}
}
}
updateWLANProfileApplyAndSubmit(formId);
return;
}
function getWLANProfileUpdates(formId)
{
var objForm = document.getElementById(formId);
var str = "";
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
var name = formElements[i].name;
if (name)
{
if (formElements[i].type == 'submit')
{
continue;
}
if (formElements[i].name == 'iehack')
{
continue;
}
var value=formElements[i].value;
if ((0==formElements[i].name.indexOf('wlan_profile_state.') ||
0==formElements[i].name.indexOf('wlan_profile_delete.')) &&
formElements[i].type == 'checkbox')
{
value=formElements[i].checked;
}
if (str != "")
{
str += '&';
}
str += encodeURIComponent(name) + "=" + encodeURIComponent(value);
}
}
}
if (str != "")
{
str += '&';
}
str += "iehack=";
return str;
}
function updateWLANProfileApplyAndSubmit(formId,force)
{
var bApplyButtonVisible=false;
var bSubmitButtonVisible=false;
if(formId!=null)
{
var objForm = document.getElementById(formId);
if (objForm && objForm.tagName == 'FORM')
{
var formElements = objForm.elements;
for (var i = 0; i < formElements.length; i++)
{
var name = formElements[i].name;
if (name)
{
if (formElements[i].type == 'submit')
{
continue;
}
if (formElements[i].name == 'iehack')
{
continue;
}
if (0==formElements[i].name.indexOf('wlan_profile_state.') &&
formElements[i].type == 'checkbox')
{
var oldState=formElements[i].getAttribute('wlan_profile_state');
var newState=formElements[i].checked;
if(newState.toString()!=oldState)
{
bApplyButtonVisible=true;
bSubmitButtonVisible=true;
}
}
if (0==formElements[i].name.indexOf('wlan_profile_delete.') &&
formElements[i].type == 'checkbox')
{
if(formElements[i].checked)
{
bApplyButtonVisible=true;
bSubmitButtonVisible=true;
}
}
}
}
}
}
if(force!=null)
{
SetSubmit(false);
configUnsaved=(force.toString()=="true")?true:false;
}
if(document.getElementById('wlanprofile_cancel_button'))
{
document.getElementById('wlanprofile_cancel_button').disabled=false;
document.getElementById('wlanprofile_cancel_button').style.visibility=bApplyButtonVisible?"visible":"hidden";
}
if(document.getElementById('wlanprofile_apply_button'))
{
document.getElementById('wlanprofile_apply_button').disabled=false;
document.getElementById('wlanprofile_apply_button').style.visibility=bApplyButtonVisible?"visible":"hidden";
}
if(document.getElementById('wlanprofile_submit_button'))
{
document.getElementById('wlanprofile_submit_button').disabled=false;
document.getElementById('wlanprofile_submit_button').style.visibility=(bSubmitButtonVisible || configUnsaved)?"visible":"hidden";
}
}
function SetNewProfileName(xml)
{
var d = document.getElementById('networkprofilename');
d.innerHTML = GetXmlData(xml, "value");
}
var timer=null;
function Rescan()
{
var d=document.getElementById('wlanScan');
if(d)
{
var nav3 = '3';
var netno = document.getElementById('hiddenwlanindex').innerHTML;
var nav2 = document.getElementById('hiddennetworkinterfacelink').innerHTML;
document.getElementById('hiddennetworkstatusconfig').innerHTML = nav3;
var e = document.getElementById('scan_progress');
e.innerHTML= GetMessage("net",259);
e.style.visibility='visible';
e.style.display = 'block';
ajax_WLANScanSSID([true, ajaxGetFormValuesWithoutClearingThem('ssidform') + '&netnumber=' + netno + '&2=' + nav2 + '&3=' + nav3]);
}
}
function UpdateRescan()
{
var d = document.getElementById('autorefresh');
clearTimeout(timer);
timer=null;
if(d && d.checked)
{
timer=setTimeout("Rescan()",60*1000);
}
document.getElementById('hiddennetworkscanautorefresh').innerHTML = d.checked.toString();
}
function SetAutoRefresh(xml)
{
clearTimeout(timer);
timer=null;
var d = document.getElementById('autorefresh');
if(d)
{
d.checked = document.getElementById('hiddennetworkscanautorefresh').innerHTML=="true"?true:false;
if(d.checked)
{
timer=setTimeout("Rescan()",60*1000);
}
}
}
function GenerateSignalStrengthIndicator(channel,strength)
{
var table="";
var cell="";
var count=0;
if(strength>=-60)
{
cell="<td style='background-color:green; padding: 5px' height='5' width='5'></td>";
count=3;
}
else if(strength>=((channel<5000)?-70:-65))
{
cell="<td style='background-color:yellow; padding: 5px' height='5' width='5'></td>";
count=2;
}
else if(strength>=((channel<5000)?-80:-70))
{
cell="<td style='background-color:red; padding: 5px' height='5' width='5'></td>";
count=1;
}
else
{
cell="<td style='background-color:red; padding: 5px' height='5' width='5'></td>";
count=0;
}
if(count>0)
{
table+="<table style='border-collapse: separate; border-spacing: 1px'>";
for(row=0;row<1;row++)
{
table+="<tr>";
for(col=0;col<count;col++)
{
table+=cell;
}
table+="</tr>";
}
table+="</table>";
}
return table;
}
function UpdateWLANConfig()
{
Update();
var cvalue = GetDivValueById("current_WLAN.WiFi_Direct_GO_Mode");
var ie = document.forms[0].elements["new_WLAN.WiFi_Direct_GO_Mode"];
if(! ie)ie = FindElement("new_WLAN.WiFi_Direct_GO_Mode");
if(ie)
{
var nvalue = GetInputElementValue(ie);
if(cvalue != nvalue)
{
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
var cvalue = GetDivValueById("current_WLAN.Band");
var ie = document.forms[0].elements["new_WLAN.Band"];
if(! ie)ie = FindElement("new_WLAN.Band");
if(ie)
{
var nvalue = GetInputElementValue(ie);
if(cvalue != nvalue)
{
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
var cvalue = GetDivValueById("current_WLAN.Scanning_Latency");
var ie = document.forms[0].elements["new_WLAN.Scanning_Latency"];
if(! ie)ie = FindElement("new_WLAN.Scanning_Latency");
if(ie)
{
var nvalue = GetInputElementValue(ie);
if(cvalue != nvalue)
{
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
ScanningLatencyUpdate();
var ccvalue = GetDivValueById("current_WLAN.Scanning_Channel_List");
var iie = document.forms[0].elements["new_WLAN.Scanning_Channel_List"];
if(! iie)iie = FindElement("new_WLAN.Scanning_Channel_List");
if(iie)
{
var nnvalue = GetInputElementValue(iie);
if(ccvalue != nnvalue)
{
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
}
function WLANConfigRender(xml)
{
var d = document.getElementById('wlan_new_values');
var e = document.getElementById('wlan_current_values');
var r = '';
var s = '';
r += '<table class="table table-striped table-condensed">';
for(var i = 1; i <= 4; ++i)
{
r += "<tr>";
r += "<td width='40%'><b>"+GetMessage("net", 182)+" " + i + " "+GetMessage("net", 183)+": </b></td>";
r += "<td>";
r += "<input ";
r += 'name="new_WLAN.Choice_' + i + '.Profile"';
r += 'type="text" size="30" maxlength="30" value=""';
r += 'onkeyup="UpdateWLANConfig();"';
r += 'onblur="UpdateWLANConfig();"';
r += 'onclick="UpdateWLANConfig();"';
r += "/>";
r += "</td>";
r += "</tr>";
s += '<div id="current_WLAN.Choice_' + i + '.Profile"></div>';
}
r+= '<tr>';
r+= '<td><b>'+GetMessage("net",278)+':</b></td>';
r+= '<td><table><tr><td><select class="form-control" onchange="UpdateWLANConfig();" name="new_WLAN.Antenna_Diversity">';
r+= '<option value="Enabled">'+GetMessage("strings",14)+'</option>';
r+= '<option value="Antenna 1">'+GetMessage("net",279)+'</option>';
r+= '<option value="Antenna 2">'+GetMessage("net",280)+'</option>';
r+= '</select></td></tr></table></td></tr>';
r+= '<tr>';
r+= '<td><b>'+GetMessage("net", 184)+':</b></td>';
r+= '<td><table><tr><td><select class="form-control"  onchange="UpdateWLANConfig();" name="new_WLAN.Debugging_Level">';
r+= '<option value="Dump">'+GetMessage("net",185)+'</option>';
r+= '<option value="Debug">'+GetMessage("strings",50)+'</option>';
r+= '<option value="Info">'+GetMessage("net",186)+'</option>';
r+= '<option value="Warning">'+GetMessage("strings",49)+'</option>';
r+= '<option value="Error">'+GetMessage("strings",48)+'</option>';
r+= '</select></td></tr></table></td></tr>';
r += "<tr>";
r += "<td><b>"+GetMessage("net",235)+":</b></td>";
r += "<td>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='UpdateWLANConfig();'";
r += "name='new_WLAN.WiFi_Direct_GO_Mode' type='radio' value='Enabled'";
r += "/>"+GetMessage("strings",14)+"";
r += "</label>";
r += "<label class='radio-inline'>";
r += "<input ";
r += "onclick='UpdateWLANConfig();'";
r += "name='new_WLAN.WiFi_Direct_GO_Mode' type='radio' value='Disabled'";
r += "/>"+GetMessage("strings",15)+"";
r += "</label>";
r += "</td>";
r += "</tr>";
r+= '<tr>';
r+= '<td><b>'+GetMessage("net",304)+':</b></td>';
r+= '<td><table><tr><td><select class="form-control" onchange="UpdateWLANConfig();" name="new_WLAN.Band">';
r+= '<option value="Auto">'+GetMessage("net",305)+'</option>';
r+= '<option value="2.4 GHz Only">'+GetMessage("net",306)+'</option>';
r+= '<option value="5 GHz Only">'+GetMessage("net",307)+'</option>';
r+= '</select></td></tr></table></td></tr>';
r+= '<tr>';
r+= '<td><b>'+GetMessage("net",313)+':</b></td>';
r+= '<td><table><tr><td><select class="form-control"  onchange="UpdateWLANConfig();" name="new_WLAN.Scanning_Latency">';
r+= '<option value="Standard">'+GetMessage("net",314)+'</option>';
r+= '<option value="Enhanced Throughput">'+GetMessage("net",315)+'</option>';
r+= '</select></td></tr></table></td></tr>';
r+= '<tr id=\"Scanning_Channel_List\" >';
r+= '<td><b>'+GetMessage("net",316)+':</b></td>';
r+= '<td>';
r+= "<input ";
r+= 'name="new_WLAN.Scanning_Channel_List"';
r+= 'type="text" size="256" maxlength="256" value=""';
r+= 'onkeyup="UpdateWLANConfig();"';
r+= 'onblur="UpdateWLANConfig();"';
r+= 'onclick="UpdateWLANConfig();"';
r+= "/>";
r+= '</td>'
r+= '</tr>';
s += '<div id="current_WLAN.Antenna_Diversity"></div>';
s += '<div id="current_WLAN.Band"></div>';
s += '<div id="current_WLAN.Scanning_Latency"></div>';
s += '<div id="current_WLAN.Scanning_Channel_List"></div>';
s += '<div id="current_WLAN.Debugging_Level"></div>';
s += '<div id="current_WLAN.WiFi_Direct_GO_Mode"></div>';
r += '</table>';
d.innerHTML = r;
e.innerHTML = s;
}
function WLANLinkConfigDisplay()
{
GetMessageDisplay('wlan_link_configuration',"net",146);
document.getElementById('apply_button').value=GetMessage("strings",9);
document.getElementById('submit_button').value=GetMessage("strings",7);
}
function SetWLANDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false, xml);
for(var i = 1; i <= 4; ++i)
{
SetDisplaySelection('WLAN.Choice_' + i + '.Profile');
}
SetDisplaySelection('WLAN.Antenna_Diversity');
SetDisplaySelection('WLAN.Band');
SetDisplaySelection('WLAN.Scanning_Latency');
SetDisplaySelection('WLAN.Scanning_Channel_List');
ScanningLatencyUpdate();
SetDisplaySelection('WLAN.Debugging_Level');
SetDisplaySelection('WLAN.WiFi_Direct_GO_Mode');
UpdateWlanDisplay(true);
EnableSubmitButton(xml);
document.getElementById("wlanform").style.display = "block";
}
function UpdateWlanDisplay(initialize)
{
Update();
}
function CreateNewProfile(ssid,bssid,channel,rssi,flags)
{
var netno = document.getElementById('hiddennetwork').innerHTML;
var nav2 = document.getElementById('hiddennetworkinterfacelink').innerHTML;
var nav3 = '3';
document.getElementById('hiddennetworkstatusconfig').innerHTML = nav3;
var params="1=1&netprofilename=New Profile&netnumber=" + netno + "&2=" + nav2 + "&3=" + nav3+"&ssid=" + ssid +"&bssid="+bssid+"&channel="+encodeURIComponent(channel)+"&rssi=" + rssi + "&flags="+encodeURIComponent(flags);
ajax_AddToHistory('WLANProfilePage',
[true, params]
);
}
function WLANNetworkChoicesRender(xml)
{
var d = document.getElementById('wlanScan');
if(d==null)return;
var e = document.getElementById('scan_progress');
if(e)
{
e.innerHTML = "";
e.style.visibility='hidden';
e.style.display = 'none';
}
var r = '';
var count=0;
r += "<table class=\"table table-striped table-condensed\" id=\"wlanScanTable\">";
r += "<thead><tr>          <td><b>SSID</b></td>          <td><b>BSSID</b></td>          <td><b>Ch</b></td>          <td width='60px'><b>RSSI</b></td>          <td><b>";
r += GetMessage("net",153);
r += "</b></td>          </tr>          </thead>";
if(xml && xml.hasChildNodes())
{
r += "<tbody id=\"wlanScanEntries\">";
var nav3 = '3';
var netno = document.getElementById('hiddennetwork').innerHTML;
var nav2 = document.getElementById('hiddennetworkinterfacelink').innerHTML;
document.getElementById('hiddennetworkstatusconfig').innerHTML = nav3;
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "network")
{
count++;
r += "<tr>";
var ssid=GetXmlData(node, "ssid");
var current=GetXmlData(node, "current");
var flags=GetXmlData(node, "flags");
var translated_flags=flags;
flags=flags.replace("[ESS]","").split("][").join(" ").replace("[","").replace("]","");
translated_flags=flags;
if(flags=="")
{
flags="None";
translated_flags=GetMessage("strings",47);
}
var rssi=GetXmlData(node, "rssi");
var bssid=GetXmlData(node, "bssid");
var channel=GetXmlData(node, "channel");
if(ssid=="")
{
r += "<td>"+ssid;
if(current=="1")
{
r +="&nbsp;&nbsp;<img class='fsimage' src='/wifi.png' width='20' height='22' />";
}
r += "</td>";
r += "<td>";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "clearTimeout(timer);timer=null;";
r += "ajax_AddToHistory(";
r += "'WLANProfilePage',";
r += "[true, '1=1&amp;netprofilename=New Profile&netnumber=" + netno + "&2=" + nav2 + "&3=" + nav3+"&ssid=" + ssid +"&bssid="+bssid+"&channel="+encodeURIComponent(channel)+"&rssi=" + rssi + "&flags="+encodeURIComponent(flags)+"']";
r += ");";
r += "return false;";
r += "\"";
r += ">";
r += bssid;
r += "</a>";
r += "</td>";
}
else
{
r += "<td>";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick='clearTimeout(timer);timer=null; CreateNewProfile(\""+ssid+"\",\""+bssid+"\",\""+channel+"\",\""+rssi+"\",\""+flags+"\"); return false;'";
r += ">";
r += ssid;
r += "</a>";
if(current=="1")
{
r +="&nbsp;&nbsp;<img class='fsimage' src='/wifi.png' width='20' height='22' />";
}
r += "</td>";
r += "<td>"+bssid+"</td>";
}
r += "<td>"+channel+"</td>";
r += "<td>"+rssi+"</td>";
r += "<td>"+translated_flags+"</td>";
r += "</tr>";
}
}
r+="</tbody>";
}
r += "</table>";
if(count==0)
{
r = "<p><i>"+GetMessage("net",187)+"</i></p>";
}
d.innerHTML = r;
$('#wlanScanTable').on( 'order.dt', function() { UpdateScanTable(); } );
$('#wlanScanTable').on( 'page.dt', function() { UpdateScanTable(); } );
$('#wlanScanTable').on( 'search.dt', function() { UpdateScanTable(); } );
$('#wlanScanTable').DataTable( {
order: [[ 3, 'desc' ]]
} );
}
function WLANProfileChoicesRender(xml)
{
var d = document.getElementById('wlanprofiletable');
var flash_state=null;
var r = '';
var count=0;
if(! xml || ! xml.hasChildNodes())
{
r += "<p><i>"+GetMessage("net",188)+"</i></p>";
}
else
{
r += "<table class='table table-striped table-condensed'>";
r += "<thead><tr>";
r += '<td><b>'+GetMessage("strings", 14)+'</b></td>';
r += '<td><b>'+GetMessage("strings", 42)+'</b></td><td><b>'+GetMessage("strings", 65)+'</b></td>';
r += '</tr></thead>';
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "c")
{
count++;
var name = GetXmlData(node, "n");
var type = GetXmlData(node, "t");
var is_active = GetXmlData(node,"a");
r += "<tr>";
var state = GetXmlData(node, "s");
r += "<td>";
r += "<input type=\"checkbox\" ";
r += "onclick=updateWLANProfileApplyAndSubmit('wlanprofilesupdateform',null); ";
r += 'name="wlan_profile_state.' + name +'" ';
r += 'wlan_profile_state="' + state +'"';
if(state=="true")
{
r += 'checked/>';
}
else
{
r += '/>';
}
r += "</td>";
r += "<td>";
r += "<input type=\"checkbox\" ";
r += "onclick=updateWLANProfileApplyAndSubmit('wlanprofilesupdateform',null); ";
r += 'name="wlan_profile_delete.' + name +'" ';
r += '/>';
r += "</td>";
r += "<td>";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "ajax_AddToHistory(";
r += "'WLANProfilePage',";
r += "[true, '1=1&amp;netprofilename=" + name + "']";
r += ");";
r += "return false;";
r += "\"";
r += ">";
r += '<img class="fsimage" src="/file.gif" />';
r += "</a>";
r += "&nbsp;";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "ajax_AddToHistory(";
r += "'WLANProfilePage',";
r += "[true, '1=1&amp;netprofilename=" + name + "']";
r += ");";
r += "return false;";
r += "\"";
r += ">";
r += name;
r += "</a>";
r += "&nbsp;&nbsp;";
r += type!=null?"<i>"+type+"</i>":"";
if(is_active!=null && is_active=="true")
{
r += "&nbsp;&nbsp;";
r +="<img class='fsimage' src='/wifi.png' width='20' height='22' />";
}
r += "&nbsp;&nbsp;&nbsp;&nbsp;";
r += "</td>";
var priority = GetXmlData(node, "p");
r += "</tr>";
}
}
r += "</table>";
flash_state=GetXmlData(xml, "flash");
}
if(!count)
{
r = "<p><i>"+GetMessage("net",188)+"</i></p>";
}
d.innerHTML = r;
updateWLANProfileApplyAndSubmit(null,(flash_state && flash_state=="unsaved")?true:false);
}
function TopologyChange(v, initial)
{
SetFxDisplay("channel_Display",
"none", initial);
var e = document.forms[0].elements["new_WLAN_Profile_Security.Suite"];
var value = GetInputElementValue(e);
if(v == "Adhoc" && value != "None" && value != "WEP")
{
value = "None";
}
e.length = 0;
e.options[0] = new Option(
"None", "None", false, value == "None"
);
e.options[1] = new Option(
"WEP", "WEP", false, value == "WEP"
);
if(v == "Infrastructure")
{
e.options[2] = new Option(
"WPA2/WPA Mixed Mode", "WPA2-WPA Mixed", false, value == "WPA2-WPA Mixed"
);
}
}
function WlanProfileDisplay()
{
GetMessageDisplay('wlan_profiles',"net",126);
document.getElementById('wlanprofile_cancel_button').value=GetMessage("strings",8);
document.getElementById('wlanprofile_apply_button').value=GetMessage("strings",9);
document.getElementById('wlanprofile_submit_button').value=GetMessage("strings",7);
GetMessageDisplay('wlan_add_a_new_profile',"net",176);
GetMessageDisplay('wlan_profile_name',"strings",65);
document.getElementById('submit_button').value=GetMessage("strings",7);
}
function BuildWlanHtml(xml)
{
var d = document.getElementById('select_wpax_credential');
d.options.length = 0;
d.options[0] = new Option("<Unlisted>", "", true);
for(var i = 0; xml && xml.hasChildNodes() && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "ssl_credential")
{
var name = GetXmlData(node, "name");
d.options[d.options.length] = new Option(name, name);
}
}
SetFxDisplay(
"select_wpax_credential_Display",
d.options.length > 1 ? "" : "none",
true
);
var di = document.getElementById('select_wpax_inner_credential');
di.options.length = 0;
di.options[0] = new Option("<Unlisted>", "", true);
for(var i = 0; xml && xml.hasChildNodes() && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "ssl_credential")
{
var name = GetXmlData(node, "name");
di.options[di.options.length] = new Option(name, name);
}
}
SetFxDisplay(
"select_wpax_inner_credential_Display",
di.options.length > 1 ? "" : "none",
true
);
}
function SetWLANProfileDisplay(xml)
{
GetMessageDisplay('wlan_profile',"net",150);
GetMessageDisplay('wlan_connect_to',"net",151);
GetMessageDisplay('wlan_network_name_ssid',"net",152);
GetMessageDisplay('wlan_security_suite_q',"net",153);
GetMessageDisplay('wlan_signal_strength',"net",154);
GetMessageDisplay('wlan_basic_configuration',"net",155);
GetMessageDisplay('wlan_basic_conf_network_name_ssid',"net",152);
GetMessageDisplay('wlan_state',"strings",46);
GetMessageDisplay('wlan_state_enabled',"strings",14);
GetMessageDisplay('wlan_state_disabled',"strings",15);
GetMessageDisplay('wlan_channel',"net",157);
GetMessageDisplay('wlan_security_configuration',"net",159);
GetMessageDisplay('wlan_security_suite',"net",160);
GetMessageDisplay('wlan_wep_authentication',"strings",56);
GetMessageDisplay('wlan_security_open',"net",161);
GetMessageDisplay('wlan_security_shared',"net",162);
GetMessageDisplay('wlan_wpa_authentication',"strings",56);
GetMessageDisplay('wlan_key_type',"net",163);
GetMessageDisplay('wlan_security_passphrase',"net",167);
GetMessageDisplay('wlan_security_pmf',"net",282);
GetMessageDisplay('security_pmf_disabled',"strings",15);
GetMessageDisplay('security_pmf_optional',"net",284);
GetMessageDisplay('security_pmf_required',"net",285);
GetMessageDisplay('wlan_key_hex',"net",168);
GetMessageDisplay('wlan_key_size',"net",164);
GetMessageDisplay('wlan_key_40_bits',"net",165);
GetMessageDisplay('wlan_key_104_bits',"net",166);
GetMessageDisplay('wlan_tx_key_index',"net",169);
GetMessageDisplay('wlan_wep_key_1',"net",170);
GetMessageDisplay('wlan_wep_key_2',"net",170);
GetMessageDisplay('wlan_wep_key_3',"net",170);
GetMessageDisplay('wlan_wep_key_4',"net",170);
GetMessageDisplay('wlan_passphrase',"net",167);
GetMessageDisplay('str_show_passphrase',"strings",136);
GetMessageDisplay('wlan_wpax_key',"net",170);
GetMessageDisplay('str_show_key',"strings",136);
GetMessageDisplay('wlan_eap_ttls_option',"net",171);
GetMessageDisplay('wlan_wpax_peap_option',"net",172);
GetMessageDisplay('wlan_wpax_fast_option',"net",299);
GetMessageDisplay('wlan_wpax_username',"strings",89);
GetMessageDisplay('wlan_wpax_password',"strings",90);
GetMessageDisplay('str_show_user_password',"strings",136);
GetMessageDisplay('wlan_wpax_validate_certificate',"net",174);
GetMessageDisplay('wlan_wpax_validate_certificate_enabled',"strings",14);
GetMessageDisplay('wlan_wpax_validate_certificate_disabled',"strings",15);
GetMessageDisplay('wlan_wpax_credentials',"strings",43);
GetMessageDisplay('wlan_wpax_inner_credentials',"strings",167);
GetMessageDisplay('wlan_advanced_configuration',"net",214);
GetMessageDisplay('wlan_tx_power_maximum',"net",223);
GetMessageDisplay('wlan_power_management',"strings",119);
GetMessageDisplay('wlan_power_mangement_enabled',"strings",14);
GetMessageDisplay('wlan_power_management_disabled',"strings",15);
GetMessageDisplay('wlan_beacons_100ms_each',"net",228);
document.getElementById('apply_button').value=GetMessage("strings",9);
document.getElementById('test_button').value=GetMessage("net",189);
document.getElementById('submit_button').value=GetMessage("strings",7);
displayElementRootNames = new Array();
SetSubmit(false, xml);
var isQuickConnect=false;
var enableTestButton=true;
SetFxDisplay("settings_Display", "none", true);
SetFxDisplay("basicConfiguration_Display", "", true);
$("#advancedConfiguration_Display").hide();
if(xml && xml.hasChildNodes)
{
for(var i = 0; i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "state")
{
var created=GetXmlData(node,"created");
if(created=="false")isQuickConnect=true;
var ssid=GetXmlData(node, "ssid");
if(isQuickConnect || (ssid && ssid!=""))
{
isQuickConnect=true;
if(ssid && ssid!="")
{
SetFxDisplay("basicConfiguration_Display", "none", true);
}
$("#advancedConfiguration_Display").hide();
toggleAdvancedConfigDisplay(ssid);
SetFxDisplay("settings_Display", "", true);
var d = document.getElementById('settings_SSID');
if(d)
{
d.innerHTML=ssid;
}
}
var bssid=GetXmlData(node, "bssid");
if(bssid != null)
{
var d = document.getElementById('settings_BSSID');
if(d)
{
d.innerHTML=bssid;
}
}
var flags=GetXmlData(node,"flags");
if(flags != null)
{
flags=flags.replace("WPS","");
if(flags=="")flags="None"
var d = document.getElementById('settings_Flags');
if(d)
{
d.innerHTML=flags;
}
}
var rssi=GetXmlData(node, "rssi");
if(rssi)
{
var d = document.getElementById('settings_RSSI');
if(d)
{
d.innerHTML=rssi;
}
}
var wlanEnabled=GetXmlData(node, "wlan_enabled");
if(wlanEnabled && wlanEnabled==0)enableTestButton=false;
}
}
}
SetDisplaySelection('WLAN_Profile_Basic.Network_Name');
var topology =
"Infrastructure"
;
SetDisplaySelection('WLAN_Profile_Basic.Channel');
TopologyChange(topology, true);
SetDisplaySelection('WLAN_Profile_Basic.State');
SetDisplaySelection('WLAN_Profile_Advanced.TX_Power_Maximum');
var power_mgmt = SetDisplaySelection('WLAN_Profile_Advanced.Power_Management');
SetDisplaySelection('WLAN_Profile_Security.Suite');
SetDisplaySelection('WLAN_Profile_Security.Key_Type');
SetDisplaySelection('WLAN_Profile_Security.Passphrase');
SetDisplaySelection('WLAN_Profile_Security.WEP.Authentication');
SetDisplaySelection('WLAN_Profile_Security.WEP.Key_Size');
SetDisplaySelection('WLAN_Profile_Security.WEP.TX_Key_Index');
SetDisplaySelection('WLAN_Profile_Security.WEP.Key_1.Key');
SetDisplaySelection('WLAN_Profile_Security.WEP.Key_2.Key');
SetDisplaySelection('WLAN_Profile_Security.WEP.Key_3.Key');
SetDisplaySelection('WLAN_Profile_Security.WEP.Key_4.Key');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Authentication');
SetDisplaySelection('WLAN_Profile_Security.WPAx.PMF');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Key');
SetDisplaySelection('WLAN_Profile_Security.WPAx.IEEE_802_1X');
SetDisplaySelection('WLAN_Profile_Security.WPAx.EAP_TTLS_Option');
SetDisplaySelection('WLAN_Profile_Security.WPAx.PEAP_Option');
SetDisplaySelection('WLAN_Profile_Security.WPAx.FAST_Option');
SetDisplaySelection('WLAN_Profile_Security.WPAx.FAST_Provisioning');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Username');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Password');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Validate_Certificate');
var credentialName = SetDisplaySelection('WLAN_Profile_Security.WPAx.Credentials');
SetDisplayValue('new_WLAN_Profile_Security.WPAx.Selected_Credential', credentialName);
var innerCredentialName = SetDisplaySelection('WLAN_Profile_Security.WPAx.Inner_Credentials');
SetDisplayValue('new_WLAN_Profile_Security.WPAx.Selected_Inner_Credential', innerCredentialName);
WLANSecuritySetFx(true, isQuickConnect);
document.getElementById("networkwlanform").style.display = "block";
EnableSubmitButton(xml);
EnableTestConnectionButton(enableTestButton);
}
function WLANSecuritySetFx(initialize, quickConnect)
{
var suite = GetInputElementValue(
document.forms[0].elements["new_WLAN_Profile_Security.Suite"]
);
var suiteDispStyle = !quickConnect ? "" : "none";
SetFxDisplay("suite_Display", suiteDispStyle, initialize);
var isWEP = suite == "WEP";
var isWPAx = suite == "WPA2-WPA Mixed";
var securityConfigDispStyle = !quickConnect || (quickConnect && (isWEP || isWPAx)) ? "" : "none";
SetFxDisplay("securityConfiguration_Display", securityConfigDispStyle, initialize);
var kt = GetInputElementValue(
document.forms[0].elements["new_WLAN_Profile_Security.Key_Type"]
);
var wpaxAuth = GetInputElementValue(
document.forms[0].elements[
"new_WLAN_Profile_Security.WPAx.Authentication"
]
);
var isIEEE802_1x = isWPAx && wpaxAuth == "802.1X";
var ieee802_1x_option = GetInputElementValue(
document.forms[0].elements[
"new_WLAN_Profile_Security.WPAx.IEEE_802_1X"
]
);
var fast_option = GetInputElementValue(
document.forms[0].elements[
"new_WLAN_Profile_Security.WPAx.FAST_Option"
]
);
var keyTypeStyle = (isWEP || (isWPAx && ! isIEEE802_1x)) ? "" : "none";
SetFxDisplay("key_type_Display", keyTypeStyle, initialize);
SetFxDisplay("wep_authentication_Display", isWEP ? "" : "none", initialize);
var wepDispStyle = isWEP ? "" : "none";
SetFxDisplay("wep_key_size_Display", wepDispStyle, initialize);
var wepKeyDispStyle = isWEP && kt == "Hex" ? "" : "none";
SetFxDisplay("wep_tx_key_index_Display", wepKeyDispStyle, initialize);
SetFxDisplay("wep_key_1_Display", wepKeyDispStyle, initialize);
SetFxDisplay("wep_key_2_Display", wepKeyDispStyle, initialize);
SetFxDisplay("wep_key_3_Display", wepKeyDispStyle, initialize);
SetFxDisplay("wep_key_4_Display", wepKeyDispStyle, initialize);
var wpaxDispStyle = !quickConnect && isWPAx ? "" : "none";
SetFxDisplay("wpax_authentication_Display", wpaxDispStyle, initialize);
var pmfDispStyle = isWPAx ? "" : "none";
SetFxDisplay("wpax_pmf_Display", pmfDispStyle, initialize);
SetFxDisplay(
"wpax_key_Display",
isWPAx && wpaxAuth == "PSK" && kt == "Hex" ? "" : "none",
initialize
);
var wpax802_1xDispStyle = isIEEE802_1x ? "" : "none";
SetFxDisplay("wpax_ieee_802_1x_Display", wpax802_1xDispStyle, initialize);
SetFxDisplay(
"wpax_eap_ttls_option_Display",
isIEEE802_1x && ieee802_1x_option == "EAP-TTLS" ? "" : "none",
initialize
);
SetFxDisplay(
"wpax_peap_option_Display",
isIEEE802_1x && ieee802_1x_option == "PEAP" ? "" : "none",
initialize
);
SetFxDisplay(
"wpax_fast_option_Display",
isIEEE802_1x && ieee802_1x_option == "FAST" ? "" : "none",
initialize
);
SetFxDisplay(
"wpax_fast_provisioning_Display",
isIEEE802_1x && ieee802_1x_option == "FAST" && fast_option == "MSCHAPV2" ? "" : "none",
initialize
);
var wpaxUsernameDispStyle = isIEEE802_1x ? "" : "none";
var wpaxPasswordDispStyle = isIEEE802_1x && ieee802_1x_option != "EAP-TLS" ? "" : "none";
SetFxDisplay("wpax_username_Display", wpaxUsernameDispStyle, initialize);
SetFxDisplay("wpax_password_Display", wpaxPasswordDispStyle, initialize);
var wpaxCredentialsDispStyle = isIEEE802_1x && ieee802_1x_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("wpax_validate_certificate_Display", wpaxCredentialsDispStyle, initialize);
SetFxDisplay("wpax_credentials_Display", wpaxCredentialsDispStyle, initialize);
var credential = GetDisplayValue("new_WLAN_Profile_Security.WPAx.Selected_Credential");
SetFxDisplay(
"wpax_credentials_selection_Display",
credential == "" ? "" : "none",
initialize
);
var wpax_peap_option = GetInputElementValue(
document.forms[0].elements[
"new_WLAN_Profile_Security.WPAx.PEAP_Option"
]
);
var wpaxInnerCredentialsDispStyle = isIEEE802_1x && ieee802_1x_option == "PEAP" && wpax_peap_option == "EAP-TLS" ? "" : "none";
SetFxDisplay("wpax_inner_credentials_Display", wpaxInnerCredentialsDispStyle, initialize);
var innerCredential = GetDisplayValue("new_WLAN_Profile_Security.WPAx.Selected_Inner_Credential");
SetFxDisplay(
"wpax_inner_credentials_selection_Display",
innerCredential == "" ? "" : "none",
initialize
);
SetFxDisplay(
"passphrase_Display",
kt == "Passphrase" && (isWEP || (isWPAx && wpaxAuth == "PSK")) ? "" : "none",
initialize
);
if(quickConnect)
{
document.getElementById('securityConfiguration_Display').style.borderStyle="solid";
document.getElementById('securityConfiguration_Display').style.borderColor= "red";
}
else
{
document.getElementById('securityConfiguration_Display').style.borderStyle="none";
}
}
function WLANSecurityDisplayUpdate(optElement)
{
Update(optElement);
var quickConnectSsid = "";
var elem = document.getElementById("settings_Display");
if(elem && elem.style.display=="")quickConnectSsid = GetDivValueById('settings_SSID');
WLANSecuritySetFx(false, quickConnectSsid != "");
}
function toggleAdvancedConfigDisplay(quickConnectSsid)
{
if (quickConnectSsid == null || !quickConnectSsid)
return;
var table = document.getElementById("advancedConfiguration_Display");
if (table) {
var trs = table.getElementsByTagName("tr");
var tr = null;
for (var i = 0; i < trs.length; i++) {
if (i > 0) {
if (IsFxDisplayVisible(trs[i].id)) {
SetFxDisplay(trs[i].id, "none", false);
}
else {
SetFxDisplay(trs[i].id, "", false);
}
}
}
}
}
function WlanProfile_TogglePasswordType(checkbox,target)
{
if(document.getElementById(checkbox).checked)document.getElementById(target).type='text';
else document.getElementById(target).type='password';
}
function UpdateWPSButtonState()
{
var submitButton=getFormElementById("wpsform","submit_external_buttons");
var somethingChanged=false;
if(GetDivValueById("current_CPFunctions.WPS_PushButton_CP") != GetDisplayValue("new_CPFunctions.WPS_PushButton_CP"))
{
somethingChanged=true;
}
submitButton.disabled=false;
submitButton.style.visibility=somethingChanged?"visible":"hidden";
submitButton.style.display=somethingChanged?"block":"none";
}
function SetWPSDisplay(xml)
{
GetMessageDisplay('wps',"net",253);
GetMessageDisplay('wps_pbc',"net",254);
GetMessageDisplay('wps_pin',"net",255);
document.getElementById('wps_method_pin').disabled=false;
document.getElementById('wps_method_push').disabled=false;
if(xml && xml.hasChildNodes())
{
var state=GetXmlData(xml, "state");
if(state=="1")
{
document.getElementById('wps_method_pin').disabled=true;
document.getElementById('wps_method_push').disabled=true;
}
}
SetDisplayValue("new_CPFunctions.Reset_to_Factory_Defaults_CP", GetDivValueById("current_CPFunctions.Reset_to_Factory_Defaults_CP"));
SetDisplayValue("new_CPFunctions.WPS_PushButton_CP", GetDivValueById("current_CPFunctions.WPS_PushButton_CP"));
UpdateWPSButtonState();
document.getElementById("wpsform").style.display = "block";
}
function UpdateSmartRoamDisplay(xml)
{
var nvalue2 = GetDivValueById("current_Smart_Roam.Level");
var interval;
var delta24;
var delta5;
var threshold24;
var threshold5;
var set = 0;
if (nvalue2 == "Low") {
interval = 15;
delta24 = 20;
delta5 = 20;
threshold24 = "-75";
threshold5 = "-75";
} else if (nvalue2 == "Medium") {
interval = 10;
delta24 = 10;
delta5 = 10;
threshold24 = "-60";
threshold5 = "-60";
} else if (nvalue2 == "High") {
interval = 5;
delta24 = 5;
delta5 = 5;
threshold24 = "-50";
threshold5 = "-50";
} else {
set = 1;
}
if (set == 0) {
$('input[id="new_Smart_Roam.Scan_Interval"]').slider('setValue', interval);
$('input[id="new_Smart_Roam.RSSI_Delta_2_4GHz"]').slider('setValue', delta24);
$('input[id="new_Smart_Roam.RSSI_Delta_5GHz"]').slider('setValue', delta5);
$('input[id="new_Smart_Roam.Scan_Threshold_2_4GHz"]').slider('setValue', threshold24);
$('input[id="new_Smart_Roam.Scan_Threshold_5GHz"]').slider('setValue', threshold5);
}
}
function SetSmartRoamDisplay(xml)
{
$('input[id="new_Smart_Roam.Scan_Interval"]').slider({
formatter: function(value) {
return '' + value;
}
});
$('input[id="new_Smart_Roam.Scan_Interval"]').css('background','#BABABA');
$('input[id="new_Smart_Roam.RSSI_Delta_2_4GHz"]').slider({
formatter: function(value) {
return '' + value;
}
});
$('input[id="new_Smart_Roam.RSSI_Delta_2_4GHz"]').css('background','#BABABA');
$('input[id="new_Smart_Roam.RSSI_Delta_5GHz"]').slider({
formatter: function(value) {
return '' + value;
}
});
$('input[id="new_Smart_Roam.RSSI_Delta_5GHz"]').css('background','#BABABA');
$('input[id="new_Smart_Roam.Scan_Threshold_2_4GHz"]').slider({
formatter: function(value) {
return '' + value;
}
});
$('input[id="new_Smart_Roam.Scan_Threshold_2_4GHz"]').css('background','#BABABA');
$('input[id="new_Smart_Roam.Scan_Threshold_5GHz"]').slider({
formatter: function(value) {
return '' + value;
}
});
$('input[id="new_Smart_Roam.Scan_Threshold_5GHz"]').css('background','#BABABA');
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Smart_Roam.Roaming');
SetDisplaySelection('Smart_Roam.Level');
SetDisplaySelection('Smart_Roam.Scan_Interval');
SetDisplaySelection('Smart_Roam.RSSI_Delta_2_4GHz');
SetDisplaySelection('Smart_Roam.RSSI_Delta_5GHz');
SetDisplaySelection('Smart_Roam.Scan_Threshold_2_4GHz');
SetDisplaySelection('Smart_Roam.Scan_Threshold_5GHz');
UpdateSmartRoamDisplay();
var scan_interval = document.getElementById('new_Smart_Roam.Scan_Interval').value;
$('input[id="new_Smart_Roam.Scan_Interval"]').slider('setValue', scan_interval);
var rssi_delta_2ghz = document.getElementById('new_Smart_Roam.RSSI_Delta_2_4GHz').value
$('input[id="new_Smart_Roam.RSSI_Delta_2_4GHz"]').slider('setValue', rssi_delta_2ghz);
var rssi_delta_5ghz = document.getElementById('new_Smart_Roam.RSSI_Delta_5GHz').value
$('input[id="new_Smart_Roam.RSSI_Delta_5GHz"]').slider('setValue', rssi_delta_5ghz);
var threshold = document.getElementById('new_Smart_Roam.Scan_Threshold_2_4GHz').value
$('input[id="new_Smart_Roam.Scan_Threshold_2_4GHz"]').slider('setValue', threshold);
threshold = document.getElementById('new_Smart_Roam.Scan_Threshold_5GHz').value
$('input[id="new_Smart_Roam.Scan_Threshold_5GHz"]').slider('setValue', threshold);
document.getElementById("smartroamform").style.display = "block";
}
function UpdateSmartRoamConfig(optElement)
{
Update(optElement);
var cvalue = GetDivValueById("current_Smart_Roam.Roaming");
var ie = document.forms[0].elements["new_Smart_Roam.Roaming"];
if(ie)
{
var nvalue = GetInputElementValue(ie);
if(cvalue != nvalue)
{
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
}
function UpdateSmartRoamConfig2(optElement)
{
Update(optElement);
var cvalue2 = GetDivValueById("current_Smart_Roam.Scan_Interval");
var ie2 = document.forms[0].elements["new_Smart_Roam.Scan_Interval"];
if(ie2)
{
var nvalue2 = GetInputElementValue(ie2);
if(cvalue2 != nvalue2)
{
document.getElementById('new_Smart_Roam.Level').value = 'Custom';
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
var cvalue3 = GetDivValueById("current_Smart_Roam.RSSI_Delta_2_4GHz");
var ie3 = document.forms[0].elements["new_Smart_Roam.RSSI_Delta_2_4GHz"];
if(ie3)
{
var nvalue3 = GetInputElementValue(ie3);
if(cvalue3 != nvalue3)
{
document.getElementById('new_Smart_Roam.Level').value = 'Custom';
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
var cvalue5 = GetDivValueById("current_Smart_Roam.RSSI_Delta_5GHz");
var ie5 = document.forms[0].elements["new_Smart_Roam.RSSI_Delta_5GHz"];
if(ie5)
{
var nvalue5 = GetInputElementValue(ie5);
if(cvalue5 != nvalue5)
{
document.getElementById('new_Smart_Roam.Level').value = 'Custom';
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
var cvalue4 = GetDivValueById("current_Smart_Roam.Scan_Threshold_2_4GHz");
var ie4 = document.forms[0].elements["new_Smart_Roam.Scan_Threshold_2_4GHz"];
if(ie4)
{
var nvalue4 = GetInputElementValue(ie4);
if(cvalue4 != nvalue4)
{
document.getElementById('new_Smart_Roam.Level').value = 'Custom';
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
var cvalue6 = GetDivValueById("current_Smart_Roam.Scan_Threshold_5GHz");
var ie6 = document.forms[0].elements["new_Smart_Roam.Scan_Threshold_5GHz"];
if(ie6)
{
var nvalue6 = GetInputElementValue(ie6);
if(cvalue6 != nvalue6)
{
document.getElementById('new_Smart_Roam.Level').value = 'Custom';
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
}
function UpdateSmartRoamCustomConfig(optElement)
{
Update(optElement);
var cvalue2 = GetDivValueById("current_Smart_Roam.Level");
var ie2 = document.forms[0].elements["new_Smart_Roam.Level"];
if(ie2)
{
var nvalue2 = GetInputElementValue(ie2);
var interval;
var delta24;
var delta5;
var threshold24;
var threshold5;
if (nvalue2 == "Low") {
interval = 15;
delta24 = 20;
delta5 = 20;
threshold24 = "-75";
threshold5 = "-75";
} else if (nvalue2 == "Medium") {
interval = 10;
delta24 = 10;
delta5 = 10;
threshold24 = "-60";
threshold5 = "-60";
} else if (nvalue2 == "High") {
interval = 5;
delta24 = 5;
delta5 = 5;
threshold24 = "-50";
threshold5 = "-50";
}
if( nvalue2 != "Custom" )
{
document.getElementById('new_Smart_Roam.Scan_Interval').value = interval;
var scan_interval = document.getElementById('new_Smart_Roam.Scan_Interval').value;
$('input[id="new_Smart_Roam.Scan_Interval"]').slider('setValue', scan_interval);
document.getElementById('new_Smart_Roam.RSSI_Delta_2_4GHz').value = delta24;
var rssi_delta_2ghz = document.getElementById('new_Smart_Roam.RSSI_Delta_2_4GHz').value
$('input[id="new_Smart_Roam.RSSI_Delta_2_4GHz"]').slider('setValue', rssi_delta_2ghz);
document.getElementById('new_Smart_Roam.RSSI_Delta_5GHz').value = delta5;
var rssi_delta_5ghz = document.getElementById('new_Smart_Roam.RSSI_Delta_5GHz').value
$('input[id="new_Smart_Roam.RSSI_Delta_5GHz"]').slider('setValue', rssi_delta_5ghz);
document.getElementById('new_Smart_Roam.Scan_Threshold_2_4GHz').value = threshold24;
var threshold = document.getElementById('new_Smart_Roam.Scan_Threshold_2_4GHz').value
$('input[id="new_Smart_Roam.Scan_Threshold_2_4GHz"]').slider('setValue', threshold);
document.getElementById('new_Smart_Roam.Scan_Threshold_5GHz').value = threshold5;
var threshold2 = document.getElementById('new_Smart_Roam.Scan_Threshold_5GHz').value
$('input[id="new_Smart_Roam.Scan_Threshold_5GHz"]').slider('setValue', threshold2);
}
if(cvalue2 != nvalue2)
{
var apply_button=document.getElementById('apply_button');
if(apply_button)
{
apply_button.style.display='none';
}
}
}
}
