function SetThreadsDisplay()
{
GetMessageDisplay('diag_threads',"threads",0);
}
