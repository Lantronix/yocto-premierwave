function UpdateDHCP()
{
if(document.forms[0].elements["new_Interface.DHCP"].value=="Enabled")
{
document.getElementById("ip_Display").style.display="none";
document.getElementById("default_gateway_Display").style.display="none";
document.getElementById("domain_Display").style.display="none";
document.getElementById("dns_Display").style.display="none";
}
else
{
document.getElementById("ip_Display").style.display="";
document.getElementById("default_gateway_Display").style.display="";
document.getElementById("domain_Display").style.display="";
document.getElementById("dns_Display").style.display="";
}
Update();
}
function UpdateDHCP6()
{
if(document.forms[0].elements["new_Interface.IPv6_DHCP"].value=="Enabled")
{
document.getElementById("ip6_Display").style.display="none";
document.getElementById("default_gateway6_Display").style.display="none";
document.getElementById("domain6_Display").style.display="none";
document.getElementById("primary_dns6_Display").style.display="none";
document.getElementById("secondary_dns6_Display").style.display="none";
}
else
{
document.getElementById("ip6_Display").style.display="";
document.getElementById("default_gateway6_Display").style.display="";
document.getElementById("domain6_Display").style.display="";
document.getElementById("primary_dns6_Display").style.display="";
document.getElementById("secondary_dns6_Display").style.display="";
}
Update();
}
function QuickSetup_EnableSubmitButton(xml)
{
if(document.getElementById('cancel_button'))
{
document.getElementById('cancel_button').disabled=false;
}
if(document.getElementById('submit_button'))
{
document.getElementById('submit_button').disabled=false;
}
}
function QuickSetup_Disable(elements)
{
for(var i=0;i<elements.length;i++)
{
elements[i].style.visibility='hidden';
QuickSetup_Disable(elements[i].children);
}
}
function QuickSetup_DisableNavigation(xml)
{
if(document.getElementById('navbar-collapse-1') &&
document.getElementById('navbar-collapse-1').children
)
{
QuickSetup_Disable(document.getElementById('navbar-collapse-1').children);
}
if( document.getElementById('sidebar') &&
document.getElementById('sidebar').children
)
{
QuickSetup_Disable(document.getElementById('sidebar').children);
}
if(
document.getElementById('xs_toggle_btn')
)
{
document.getElementById('xs_toggle_btn').style.visibility='hidden';
}
if(
document.getElementById('xs_icon_bars')
)
{
document.getElementById('xs_icon_bars').style.visibility='hidden';
}
}
function QuickSetup_Enable(elements)
{
for(var i=0;i<elements.length;i++)
{
elements[i].style.visibility='visible';
QuickSetup_Enable(elements[i].children);
}
}
function QuickSetup_EnableNavigation(xml)
{
if( document.getElementById('navbar-collapse-1') &&
document.getElementById('navbar-collapse-1').children
)
{
QuickSetup_Enable(document.getElementById('navbar-collapse-1').children);
}
if( document.getElementById('sidebar') &&
document.getElementById('sidebar').children
)
{
QuickSetup_Enable(document.getElementById('sidebar').children);
}
if(
document.getElementById('xs_toggle_btn')
)
{
document.getElementById('xs_toggle_btn').style.visibility='visible';
}
if(
document.getElementById('xs_icon_bars')
)
{
document.getElementById('xs_icon_bars').style.visibility='visible';
}
}
function QuickSetupExit(xml)
{
window.location.href='/';
}
function QuickSetupDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
QuickSetup_EnableSubmitButton();
GetMessageDisplay('quick_setup',"qsetup",1);
GetMessageDisplay('bridge_config',"strings",37);
GetMessageDisplay('bridge_state',"strings",46);
GetMessageDisplay('bridge_enabled',"strings",14);
GetMessageDisplay('bridge_disabled',"strings",15);
GetMessageDisplay('bridge_transparentmode',"bridge",22);
GetMessageDisplay('bridge_transparentmode_enabled',"strings",14);
GetMessageDisplay('bridge_transparentmode_disabled',"strings",15);
GetMessageDisplay('bridging_mac_address',"bridge",14);
GetMessageDisplay('bridging_ip_address',"bridge",20);
GetMessageDisplay('bridging_auto_ip',"bridge",23);
GetMessageDisplay('bridge_autoip_enabled',"strings",14);
GetMessageDisplay('bridge_autoip_disabled',"strings",15);
GetMessageDisplay('bridging_ipv6_address',"bridge",21);
GetMessageDisplay('bridging_auto_ip6',"bridge",24);
GetMessageDisplay('bridge_autoip6_enabled',"strings",14);
GetMessageDisplay('bridge_autoip6_disabled',"strings",15);
document.getElementById('submit_button').value=GetMessage("strings",7);
document.getElementById('cancel_button').value=GetMessage("strings",120);
document.getElementById('advanced_button').value=GetMessage("qsetup",3);
SetDisplaySelection('admin_username');
SetDisplaySelection('admin_password');
SetDisplaySelection('Bridge.State');
SetDisplaySelection('Bridge.Bridging_Mode');
document.getElementById('dhcpshortcut').style.display=(GetInputElementValue(document.forms[0].elements['new_Bridge.Bridging_Mode'])!='Network')?'none':'';
SetDisplaySelection('Bridge.Transparent_Mode');
SetDisplaySelection('Bridge.Network_Access_for_Gateway');
document.getElementById('bridge_networkaccess_Display').style.display=(GetInputElementValue(document.forms[0].elements['new_Bridge.Transparent_Mode'])=='Disabled')?'none':'';
SetDisplaySelection('Bridge.Ethernet_Interface');
SetDisplaySelection('Bridge.Bridging_MAC_Address');
SetDisplaySelection('Bridge.Bridging_Initial_Scan_Interval');
SetDisplaySelection('Bridge.Bridging_Scan_Interval');
SetDisplaySelection('Bridge.Bridging_IP_Address');
SetDisplaySelection('Bridge.Auto_Detect_IP_Address');
document.getElementById("configure_bridge_ipv4_address").style.display=(document.forms[0].elements["new_Bridge.Auto_Detect_IP_Address"].value=="Enabled")?"none":"";
SetDisplaySelection('Bridge.Bridging_IPv6_Address');
SetDisplaySelection('Bridge.Auto_Detect_IPv6_Address');
document.getElementById("configure_bridge_ipv6_address").style.display=(document.forms[0].elements["new_Bridge.Auto_Detect_IPv6_Address"].value=="Enabled")?"none":"";
SetDisplaySelection('DHCP.State');
SetDisplaySelection('DHCP.DHCP_Relay');
SetDisplaySelection('DHCP.DHCP_Server_IP_Address');
SetDisplaySelection('DHCP.Start_IP_Address');
SetDisplaySelection('DHCP.End_IP_Address');
SetDisplaySelection('DHCP.IPv6_State');
SetDisplaySelection('DHCP.Start_IPv6_Address');
SetDisplaySelection('DHCP.End_IPv6_Address');
SetDisplaySelection('DHCP.Lease_Time');
SetDisplaySelection('DHCP.Static_Leases_1.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_1.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_1.IPv6_Address');
SetDisplaySelection('DHCP.Static_Leases_2.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_2.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_2.IPv6_Address');
SetDisplaySelection('DHCP.Static_Leases_3.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_3.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_3.IPv6_Address');
SetDisplaySelection('DHCP.Static_Leases_4.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_4.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_4.IPv6_Address');
SetDisplaySelection('DHCP.Static_Leases_5.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_5.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_5.IPv6_Address');
SetDisplaySelection('DHCP.Static_Leases_6.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_6.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_6.IPv6_Address');
SetDisplaySelection('DHCP.Static_Leases_7.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_7.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_7.IPv6_Address');
SetDisplaySelection('DHCP.Static_Leases_8.MAC_Address');
SetDisplaySelection('DHCP.Static_Leases_8.IP_Address');
SetDisplaySelection('DHCP.Static_Leases_8.IPv6_Address');
GetMessageDisplay('wlan_configuration1',"net",123);
GetMessageDisplay('wlan_configuration2',"strings",1);
GetMessageDisplay('wlan_configuration3',"strings",37);
GetMessageDisplay('qsetup_wps',"net",253);
GetMessageDisplay('qsetup_current_network',"strings",40);
GetMessageDisplay('qsetup_network_name',"net",152);
GetMessageDisplay('connectTo__Display',"net",151);
GetMessageDisplay('wlan_basic_conf_network_name_ssid',"net",152);
GetMessageDisplay('wlan_passphrase',"net",167);
GetMessageDisplay('str_show_user_password',"strings",136);
GetMessageDisplay('wlan_wpax_username',"strings",89);
GetMessageDisplay('wlan_wpax_password',"strings",90);
GetMessageDisplay('str_show_passphrase',"strings",136);
GetMessageDisplay('qsetup_scan_networks',"qsetup",2);
GetMessageDisplay('wlan_scan_autorefresh',"net",179);
document.getElementById('qsetup_scan').value=GetMessage("net",231);
SetDisplaySelection('WLAN_Profile_Basic.Network_Name');
SetDisplaySelection('WLAN_Profile_Security.Suite');
GetMessageDisplay('eap_tls_Note',"qsetup",8);
SetDisplaySelection('WLAN_Profile_Security.Passphrase');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Username');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Password');
GetMessageDisplay('wlan_security_pmf',"net",282);
GetMessageDisplay('security_pmf_disabled',"strings",15);
GetMessageDisplay('security_pmf_optional',"net",284);
GetMessageDisplay('security_pmf_required',"net",285);
SetDisplaySelection('WLAN_Profile_Security.WPAx.PMF');
GetMessageDisplay('wlan_eap_ttls_option',"net",171);
GetMessageDisplay('wlan_wpax_peap_option',"net",172);
SetDisplaySelection('WLAN_Profile_Security.WPAx.IEEE_802_1X');
SetDisplaySelection('WLAN_Profile_Security.WPAx.EAP_TTLS_Option');
SetDisplaySelection('WLAN_Profile_Security.WPAx.PEAP_Option');
SetDisplaySelection('WLAN_Profile_Security.WPAx.Validate_Certificate');
GetMessageDisplay('wlan_wpax_fast_option',"net",299);
SetDisplaySelection('WLAN_Profile_Security.WPAx.FAST_Option');
SetDisplaySelection('WLAN_Profile_Security.WPAx.FAST_Provisioning');
GetMessageDisplay('network_ip_address',"strings",101);
GetMessageDisplay('network_default_gateway',"strings",99);
GetMessageDisplay('network_domain',"strings",75);
GetMessageDisplay('primary_dns',"strings",61);
GetMessageDisplay('network_state',"strings",46);
GetMessageDisplay('network_enabled',"strings",14);
GetMessageDisplay('network_disabled',"strings",15);
SetDisplaySelection('Interface.State');
SetDisplaySelection('Interface.DHCP');
GetMessageDisplay('dhcp_client',"net",130);
GetMessageDisplay('dhcp_client_on',"net",129);
GetMessageDisplay('dhcp_client_off',"strings",74);
SetDisplaySelection('Interface.IP_Address');
SetDisplaySelection('Interface.Default_Gateway');
SetDisplaySelection('Interface.Domain');
SetDisplaySelection('Interface.Primary_DNS');
UpdateDHCP();
GetMessageDisplay('ipv4_state',"strings",46);
GetMessageDisplay('ipv4_enabled',"strings",14);
GetMessageDisplay('ipv4_disabled',"strings",15);
SetDisplaySelection('Interface.IPv4_State');
GetMessageDisplay('ipv6_state',"strings",46);
GetMessageDisplay('ipv6_enabled',"strings",14);
GetMessageDisplay('ipv6_disabled',"strings",15);
SetDisplaySelection('Interface.IPv6_State');
GetMessageDisplay('dhcp6_client',"net",130);
GetMessageDisplay('dhcp6_client_on',"net",129);
GetMessageDisplay('dhcp6_client_off',"strings",74);
SetDisplaySelection('Interface.IPv6_DHCP');
GetMessageDisplay('autoconf_on',"net",129);
GetMessageDisplay('autoconf_off',"strings",74);
SetDisplaySelection('Interface.IPv6_Auto_Configure');
GetMessageDisplay('network6_ip_address',"strings",101);
SetDisplaySelection('Interface.IPv6_Address');
GetMessageDisplay('network6_default_gateway',"strings",99);
SetDisplaySelection('Interface.IPv6_Default_Gateway');
GetMessageDisplay('network6_domain',"strings",75);
SetDisplaySelection('Interface.IPv6_Domain');
GetMessageDisplay('primary_dns6',"strings",61);
GetMessageDisplay('secondary_dns6',"strings",62);
SetDisplaySelection('Interface.IPv6_Primary_DNS');
SetDisplaySelection('Interface.IPv6_Secondary_DNS');
UpdateDHCP6();
document.getElementById('wireless_network__Display').style.display='none';
document.getElementById('connectTo__Display').style.display='none';
document.getElementById('wlanScanResults').style.display='';
document.getElementById('toggle_menu').innerHTML=GetMessage("strings",66);
document.getElementById('text_logout').innerHTML=GetMessage("logout",0);
document.getElementById('text_help').innerHTML=GetMessage("strings",115);
document.title=GetMessage("strings",137);
document.getElementById('key_copyright').innerHTML=GetMessage("strings",138);
document.getElementById("quicksetupform").style.display = "block";
}
function QuickSetup_TogglePasswordType(checkbox,target)
{
if(document.getElementById(checkbox).checked)document.getElementById(target).type='text';
else document.getElementById(target).type='password';
}
function QuickSetup_GenerateSignalStrengthIndicator(channel,strength)
{
var table="";
var cell="";
var count=0;
if(strength>=-60)
{
cell="<td style='background-color:green; padding: 5px' height='5' width='5'></td>";
count=3;
}
else if(strength>=((channel<5000)?-70:-65))
{
cell="<td style='background-color:yellow; padding: 5px' height='5' width='5'></td>";
count=2;
}
else if(strength>=((channel<5000)?-80:-70))
{
cell="<td style='background-color:red; padding: 5px' height='5' width='5'></td>";
count=1;
}
else
{
cell="<td style='background-color:red; padding: 5px' height='5' width='5'></td>";
count=0;
}
if(count>0)
{
table+="<table style='border-collapse: separate; border-spacing: 1px'>";
for(row=0;row<1;row++)
{
table+="<tr>";
for(col=0;col<count;col++)
{
table+=cell;
}
table+="</tr>";
}
table+="</table>";
}
return table;
}
function QuickSetup_UpdateScanTable(xml)
{
var scanResultTable = document.getElementById("wlanScanTable");
if(scanResultTable && scanResultTable.rows.length>1)
{
var row=scanResultTable.rows[1];
while(row && row.getElementsByTagName('td').length>3)
{
ch=row.getElementsByTagName('td')[2];
var channel=parseInt(ch.innerHTML);
rssi=row.getElementsByTagName('td')[3];
var strength=parseInt(rssi.innerHTML);
var originalContent=rssi.innerHTML;
rssi.innerHTML=QuickSetup_GenerateSignalStrengthIndicator(channel,strength)+originalContent;
row=row.nextSibling;
}
}
}
var scan_timer=null;
function QuickSetup_WLANNetworkChoicesRender(xml)
{
var d = document.getElementById('wlanScanQ');
if(d==null)return;
var e = document.getElementById('scan_progress');
if(e)
{
e.innerHTML = "";
e.style.visibility='hidden';
e.style.display = 'none';
}
var r = '';
var count=0;
r += "<table class=\"table table-striped table-condensed\" id=\"wlanScanTable\">";
r += "<thead><tr>          <td><b>SSID</b></td>          <td><b>BSSID</b></td>          <td><b>Ch</b></td>          <td width='60px'><b>RSSI</b></td>          <td><b>";
r += GetMessage("net",153);
r += "</b></td>          </tr>          </thead>";
if(xml && xml.hasChildNodes())
{
r += "<tbody id=\"wlanScanEntries\">";
var nav3 = '3';
var netno = document.getElementById('hiddenwlanindex').innerHTML;
var nav2 = document.getElementById('hiddennetworkinterfacelink').innerHTML;
document.getElementById('hiddennetworkstatusconfig').innerHTML = nav3;
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "network")
{
var current=GetXmlData(node, "current");
var ssid=GetXmlData(node, "ssid");
var flags=GetXmlData(node, "flags");
var translated_flags=flags;
flags=flags.replace("[ESS]","").split("][").join(" ").replace("[","").replace("]","");
translated_flags=flags;
if(flags!="" && flags!="WPS" && flags.indexOf("WPA")==-1)
{
continue;
}
if(flags=="")
{
flags="None";
translated_flags=GetMessage("strings",47);
}
var rssi=GetXmlData(node, "rssi");
var bssid=GetXmlData(node, "bssid");
var channel=GetXmlData(node, "channel");
count++;
r += "<tr>";
if(ssid=="")
{
r += "<td>"+ssid;
if(current=="1")
{
r +="&nbsp;&nbsp;<img class='fsimage' src='/wifi.png' width='20' height='22' />";
}
r += "</td>";
r += "<td>";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick=\"";
r += "clearTimeout(scan_timer);scan_timer=null;QuickSetup_UpdateWirelessNetwork('"+ssid+"','"+bssid+"','"+flags+"');";
r += "return false;";
r += "\"";
r += ">";
r += bssid;
r += "</a>";
r += "</td>";
}
else
{
r += "<td>";
r += "<a ";
r += "href=\"javascript:void(0)\" ";
r += "onclick='clearTimeout(scan_timer);scan_timer=null;QuickSetup_UpdateWirelessNetwork(\""+ssid+"\",\""+bssid+"\",\""+flags+"\");return false;'";
r += ">";
r += ssid;
r += "</a>";
if(current=="1")
{
r +="&nbsp;&nbsp;<img class='fsimage' src='/wifi.png' width='20' height='22' />";
}
r += "</td>";
r += "<td>"+bssid+"</td>";
}
r += "<td>"+channel+"</td>";
r += "<td>"+rssi+"</td>";
r += "<td>"+translated_flags+"</td>";
r += "</tr>";
}
}
r+="</tbody>";
}
r += "</table>";
if(count==0)
{
r = "<p><i>"+GetMessage("net",187)+"</i></p>";
}
d.innerHTML = r;
$('#wlanScanTable').on( 'order.dt', function() { QuickSetup_UpdateScanTable(); } );
$('#wlanScanTable').on( 'page.dt', function() { QuickSetup_UpdateScanTable(); } );
$('#wlanScanTable').on( 'search.dt', function() { QuickSetup_UpdateScanTable(); } );
$('#wlanScanTable').DataTable( {
order: [[ 3, 'desc' ]]
} );
}
function QuickSetup_UpdateIEE8021X()
{
if(document.forms[0].elements["new_WLAN_Profile_Security.WPAx.IEEE_802_1X"].value=="LEAP")
{
document.getElementById("wpax_eap_ttls_option_Display").style.display="none";
document.getElementById("wpax_peap_option_Display").style.display="none";
document.getElementById("wpax_fast_option_Display").style.display="none";
document.getElementById("wpax_fast_provisioning_Display").style.display="none";
}
if(document.forms[0].elements["new_WLAN_Profile_Security.WPAx.IEEE_802_1X"].value=="EAP-TTLS")
{
document.getElementById("wpax_peap_option_Display").style.display="none";
document.getElementById("wpax_eap_ttls_option_Display").style.display="";
document.getElementById("wpax_fast_option_Display").style.display="none";
document.getElementById("wpax_fast_provisioning_Display").style.display="none";
}
if(document.forms[0].elements["new_WLAN_Profile_Security.WPAx.IEEE_802_1X"].value=="PEAP")
{
document.getElementById("wpax_peap_option_Display").style.display="";
document.getElementById("wpax_eap_ttls_option_Display").style.display="none";
document.getElementById("wpax_fast_option_Display").style.display="none";
document.getElementById("wpax_fast_provisioning_Display").style.display="none";
}
if(document.forms[0].elements["new_WLAN_Profile_Security.WPAx.IEEE_802_1X"].value=="FAST")
{
document.getElementById("wpax_peap_option_Display").style.display="none";
document.getElementById("wpax_eap_ttls_option_Display").style.display="none";
document.getElementById("wpax_fast_option_Display").style.display="";
document.getElementById("wpax_fast_provisioning_Display").style.display =
(document.forms[0].elements["new_WLAN_Profile_Security.WPAx.FAST_Option"].value=="MSCHAPV2" ? "" : "none");
}
}
function QuickSetup_UpdateWirelessNetwork(ssid,bssid,flags)
{
document.getElementById("wireless_network__Display").style.display="none";
document.getElementById("connectTo__Display").style.display="none";
var options=flags.split(" ");
document.forms[0].elements["new_WLAN_Profile_Basic.Network_Name"].disabled=(ssid!="");
document.forms[0].elements["new_WLAN_Profile_Security.WPAx.PMF"].value="Disabled";
document.getElementById("btn_security_pmf_disabled").checked=true;
document.getElementById("wpax_pmf_Display").style.display="none";
document.getElementById("wpax_ieee_802_1x_Display").style.display="none";
document.getElementById("wpax_eap_ttls_option_Display").style.display="none";
document.getElementById("wpax_peap_option_Display").style.display="none";
document.getElementById("eap_tls_Note").style.display="none";
document.getElementById("wpax_fast_option_Display").style.display="none";
document.getElementById("wpax_fast_provisioning_Display").style.display="none";
var isWPA=false;
for(var opt=0;opt<options.length;opt++)
{
var flag=options[opt];
document.forms[0].elements["new_WLAN_Profile_Basic.State"].value="Enabled"
document.getElementById("wireless_network__Display").style.display="";
document.getElementById("connectTo__Display").style.display="";
document.getElementById("connect_bssid").innerHTML=bssid;
document.forms[0].elements["new_WLAN_Profile_Basic.Network_Name"].value=ssid;
if(flag.indexOf("WPA2-")>-1 || flag.indexOf("WPA-")>-1)
{
isWPA=true;
document.getElementById("wpax_pmf_Display").style.display="";
if(flag.indexOf("WPA2-")>-1)
{
document.forms[0].elements["new_WLAN_Profile_Security.Suite"].value="WPA2-WPA Mixed"
}
if(flag.indexOf("WPA-")>-1)
{
document.forms[0].elements["new_WLAN_Profile_Security.Suite"].value="WPA2-WPA Mixed"
}
if(flag.indexOf("EAP")>-1)
{
document.forms[0].elements["new_WLAN_Profile_Security.WPAx.Authentication"].value="802.1X";
document.getElementById("passphrase_Display").style.display="none";
document.getElementById("wpax_username_Display").style.display="";
document.getElementById("wpax_password_Display").style.display="";
document.forms[0].elements["new_WLAN_Profile_Security.WPAx.IEEE_802_1X"].value="PEAP";
document.getElementById("wpax_ieee_802_1x_Display").style.display="";
document.getElementById("eap_tls_Note").style.display="";
QuickSetup_UpdateIEE8021X();
}
else
{
document.forms[0].elements["new_WLAN_Profile_Security.WPAx.Authentication"].value="PSK";
document.getElementById("passphrase_Display").style.display="";
document.getElementById("wpax_username_Display").style.display="none";
document.getElementById("wpax_password_Display").style.display="none";
}
}
if(flag.indexOf("None")==0 || flag.indexOf("WPS")==0)
{
if(isWPA)continue;
document.forms[0].elements["new_WLAN_Profile_Security.Suite"].value="None"
document.getElementById("passphrase_Display").style.display="none";
document.getElementById("wpax_username_Display").style.display="none";
document.getElementById("wpax_password_Display").style.display="none";
}
}
$('html, body').animate({
scrollTop: $("#connectTo__PlaceHolder").position().top
}, "fast");
Update();
}
function QuickSetup_SetWLANScanSSID(xml)
{
var d = document.getElementById('ssid');
if(d){ d.value = GetXmlData(xml, "value"); }
}
function QuickSetup_Rescan()
{
var d=document.getElementById('wlanScanQ');
if(d)
{
document.getElementById('wireless_network__Display').style.display='none';
document.getElementById('connectTo__Display').style.display='none';
document.getElementById('wlanScanResults').style.display='';
var nav3 = '3';
var netno = document.getElementById('hiddenwlanindex').innerHTML;
var nav2 = document.getElementById('hiddennetworkinterfacelink').innerHTML;
document.getElementById('hiddennetworkstatusconfig').innerHTML = nav3;
var bridge_num = 0;
bridge_num = document.getElementById('hiddenbridgenumber').innerHTML;
var e = document.getElementById('scan_progress');
e.innerHTML= GetMessage("net",259);
e.style.visibility='visible';
e.style.display = 'block';
ajax_QuickSetupPage([true, ajaxGetFormValuesWithoutClearingThem('quicksetupform') +
'&bridgeidentifier='+bridge_num+'&do_scan=true&netnumber=' + netno + '&2=' + nav2 + '&3=' + nav3]); }
}
function QuickSetup_UpdateRescan()
{
var d = document.getElementById('qsetup_autorefresh');
clearTimeout(scan_timer);
scan_timer=null;
if(d && d.checked)
{
scan_timer=setTimeout("QuickSetup_Rescan()",60*1000);
}
document.getElementById('hiddenqsetupscanautorefresh').innerHTML = d.checked.toString();
}
function QuickSetup_SetAutoRefresh(xml)
{
clearTimeout(scan_timer);
scan_timer=null;
var d = document.getElementById('qsetup_autorefresh');
if(d)
{
d.checked = document.getElementById('hiddenqsetupscanautorefresh').innerHTML=="true"?true:false;
if(d.checked)
{
scan_timer=setTimeout("QuickSetup_Rescan()",60*1000);
}
}
}
