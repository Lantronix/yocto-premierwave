function ProtocolChange(value)
{
SetFxDisplay("host_ssh_username_Display", value == "SSH" ? "" : "none");
document.getElementById("new_Host.Remote_Port").value = "";
Update();
}
function SetAdmin_HostDisplay()
{
var menu=document.getElementById('host_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('host_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function SetHostDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Host.Name');
var v = SetDisplaySelection('Host.Protocol');
SetDisplaySelection('Host.SSH_Username');
SetFxDisplay("host_ssh_username_Display", v == "SSH" ? "" : "none");
SetDisplaySelection('Host.Remote_Address');
SetDisplaySelection('Host.Remote_Port');
document.getElementById("hostdefform").style.display = "block";
}
function HostRender(xml)
{
var numHosts = GetXmlData(xml, "numHosts");
var hostNum = GetXmlData(xml, 'hostNum');
document.getElementById("hiddenhostnumber").innerHTML = hostNum;
document.getElementById("hostnumber").innerHTML = "Host " + (Number(hostNum)+1);
var d = document.getElementById("host_selection");
if(d)
{
var r = "";
r += '<table id="Nav1">';
r += "<tr>";
if(numHosts > 4)
{
r += "<td>";
r += "<table><tr><td><select class='form-control' name='navSelect' ";
r += "id='navSelect' ";
r += "onchange=\" ";
r += "var page = 'HostWebMgrConfigPage';";
r += "return ajax_AddToHistory(page, [true, 'hostnumber='+this.value]);";
r += " \" ";
r += ">";
for(var i = 0; i < numHosts; ++i)
{
var sel = (hostNum == i) ? " selected " : "";
r += "<option value='" + i + "' " + sel + ">";
r += "Host " + (i+1);
r += "</option>";
}
r += "</select></td></tr></table>";
r += "</td>";
}
else
{
for(var i = 0; i < numHosts; ++i)
{
r += "<td id='hostnav" + (i+1) + "'>";
r += "<a ";
r += "href='javascript:void(0)'";
r += "onclick=\"";
r += "var page = 'HostWebMgrConfigPage';";
r += "return ajax_AddToHistory(page, [true, 'hostnumber=" + i + "']);";
r += "\"";
r += ">";
r += "Host " + (i+1);
r += "</a>";
r += "</td>";
}
}
r += "</tr>";
r += "</table>";
d.innerHTML = r;
HighlightElementInTable("Nav1", "hostnav" + (Number(hostNum)+1));
}
}
