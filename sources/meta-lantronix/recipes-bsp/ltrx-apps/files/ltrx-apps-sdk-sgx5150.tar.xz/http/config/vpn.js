function UpdateKeyManagement(xml)
{
var vpn_mode = GetDisplayValue("new_vpn.Authentication_Mode");
SetFxDisplay("psk_display", "none", true);
SetFxDisplay("key_display", "none", true);
SetFxDisplay("remote_rsa_key_display", "none", true);
SetFxDisplay("local_key_display", "none", true);
SetFxDisplay("key_length_display", "none", true);
SetFxDisplay("xauth_user_display", "none", true);
SetFxDisplay("xauth_password_display", "none", true);
SetFxDisplay("remote_peer_type_display","none", true);
if(vpn_mode=="XAUTH")
{
SetFxDisplay("key_display", "", true);
SetFxDisplay("xauth_user_display", "", true);
SetFxDisplay("xauth_password_display", "", true);
SetFxDisplay("remote_peer_type_display","", true);
}
if(vpn_mode=="PSK")
{
SetFxDisplay("psk_display","", true);
}
if(vpn_mode=="RSA")
{
SetFxDisplay("remote_rsa_key_display","", true);
SetFxDisplay("local_key_display", "", true);
SetFxDisplay("key_length_display", "", true);
}
Update();
}
function UpdateVPNInterfaceSelection(xml)
{
var vpn_interface = GetDisplayValue("new_vpn.Interface");
var x=document.getElementById('vpn_interface');
for(var i=0;i<x.length;i++)
{
if(vpn_interface==x.options[i].value)
{
x.selectedIndex=i;
break;
}
}
Update();
}
function UpdateVPNInterface(xml)
{
var x=document.getElementById('vpn_interface');
var vpn_interface = x.options[x.selectedIndex].value
SetDisplayValue('new_vpn.Interface',vpn_interface);
Update();
}
function SetVPNDisplay(xml)
{
displayElementRootNames = new Array();
SetDisplaySelection('vpn.Connection_Name');
SetDisplaySelection('vpn.State');
SetDisplaySelection('vpn.Connection_Type');
SetDisplaySelection('vpn.IKEv2');
SetDisplaySelection('vpn.Unreachable_Host_Detection.Host');
SetDisplaySelection('vpn.Unreachable_Host_Detection.Ping_Interval');
SetDisplaySelection('vpn.Unreachable_Host_Detection.Max_Tries');
SetDisplaySelection('vpn.Authentication_Mode');
SetDisplaySelection('vpn.Type');
SetDisplaySelection('vpn.Mode_Configuration');
SetDisplaySelection('vpn.IKE_Encryption');
SetDisplaySelection('vpn.IKE_Authentication');
SetDisplaySelection('vpn.IKE_DH_Group');
SetDisplaySelection('vpn.IKE_Life_Time');
SetDisplaySelection('vpn.ESP_Encryption');
SetDisplaySelection('vpn.ESP_Authentication');
SetDisplaySelection('vpn.ESP_DH_Group');
SetDisplaySelection('vpn.SA_Life_Time');
SetDisplaySelection('vpn.Remote_EndPoint');
SetDisplaySelection('vpn.Remote_Subnet');
SetDisplaySelection('vpn.Remote_ID');
SetDisplaySelection('vpn.Remote_Next_Hop');
SetDisplaySelection('vpn.Local_Subnet');
SetDisplaySelection('vpn.Local_ID');
SetDisplaySelection('vpn.Local_Next_Hop');
SetDisplaySelection('vpn.PSK');
SetDisplaySelection('vpn.Remote_Key');
SetDisplaySelection('vpn.Local_Key_Length');
SetDisplaySelection('vpn.Remote_RSA_Key');
SetDisplaySelection('vpn.NAT_Traversal');
SetDisplaySelection('vpn.Aggressive_Mode');
SetDisplaySelection('vpn.Perfect_Forward_Secrecy');
SetDisplaySelection('vpn.Username');
SetDisplaySelection('vpn.Password');
SetDisplaySelection('vpn.Remote_Peer_Type');
UpdateKeyManagement();
SetDisplaySelection('vpn.Interface');
UpdateVPNInterfaceSelection();
SetSubmit(false);
document.getElementById("vpnform").style.display = "block";
}
