function uploadFile()
{
var _file=document.getElementById('fsuploadfile');
if(_file.files.length==0)
{
return;
}
var fname = _file.value.substring(_file.value.lastIndexOf('\\')+1);
var data=new FormData();
data.append("cwd",document.getElementById('uploadformcwd').value);
data.append("selectedfile",_file.files[0]);
var request=ajax.getRequestObject();
request.open("POST","/fs");
request.onreadystatechange = function(){
var responseStatus;
try
{
responseStatus = request.status;
}
catch(e)
{
responseStatus = 0;
}
if(request.readyState == 4)
{
if (responseStatus == 200)
{
var cdir=document.getElementById('uploadformcwd').value;
var param='dir='+(cdir);
var args = [fname];
var msg = GetMessage('fs',44,args);
var r = "";
r += "<div class='alert alert-success alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                        <span class=\"sr-only\">Close</span>                      </button>";
r += "<span class='glyphicon glyphicon-ok-sign' aria-hidden='true'></span>";
r += "<div id='trresult_info'>" + msg + "</div></div>";
document.getElementById('results').innerHTML=r;
setTimeout( function(){
ajax_FsBrowsePage([true, param]);
}, 3000
);
}
else
{
var args = [fname];
var msg = GetMessage('fs',43,args);
msg = msg.replace("ERROR:", "<strong>"+GetMessage("strings",48)+":</strong>");
if(responseStatus == 413)
{
msg += " File exceeds the maximum upload size of 10 MB.";
}
var r = "";
r += "<div class='alert alert-danger alert-dismissible' role='alert'>";
r += "<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span>                        <span class=\"sr-only\">Close</span>                      </button>";
r += "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span>";
r += "<div id='trresult_errors'>" + msg + "</div></div>";
document.getElementById('results').innerHTML=r;
}
}
}
request.send(data);
}
function FseUSBDisplay(xml)
{
var r='';
if (xml && xml.hasChildNodes())
{
var eUSB=xml.getElementsByTagName("eUSB");
if(eUSB && eUSB.length>0)
{
var present=eUSB[0].firstChild.nodeValue;
if(present=='yes')
{
r += '<table class="table table-striped table-condensed">';
r += '<thead><tr><td colspan="2"><h3>Internal Storage</h3></td></tr></thead>';
r += '<tbody><tr><td width="40%"><b>Filesystem Size:</b></td><td>'+xml.getElementsByTagName("eUSB_fssize")[0].firstChild.nodeValue+'</td></tr>';
r += '<tr><td width="40%"><b>Available Space:</b></td><td>'+xml.getElementsByTagName("eUSB_fsavail")[0].firstChild.nodeValue+'</td></tr>';
r += '<tr><td width="40%"><b>File & Dir Space Used:</b></td><td>'+xml.getElementsByTagName("eUSB_fsused")[0].firstChild.nodeValue+'</td></tr></tbody>';
r += '</table>'
}
}
}
document.getElementById('eUSB').innerHTML=r;
}
function FsDirCompare(a, b)
{
if (a > b) return 1;
if (a < b) return -1;
return 0;
}
function FsFileCompare(a, b)
{
if (a[0] > b[0]) return 1;
if (a[0] < b[0]) return -1;
return 0;
}
function FsBasename(path)
{
if (path == '/') return path;
var r = path.match(/[\/|\\]([^\\\/]+)$/);
if (!r) return '';
return r[1];
}
function FsDirname(path)
{
if (path == '/') return path;
var r = path.match(/(.*)[\/|\\][^\\\/]+$/);
if (!r) return '';
if (!r[1]) return '/';
return r[1];
}
function FsBrowseRender(xml)
{
GetMessageDisplay('filesystem_browser',"fs", 71);
GetMessageDisplay('create',"fs", 72);
GetMessageDisplay('directory',"strings", 63);
document.getElementById('create_directory_submit').value=GetMessage("fs",72);
GetMessageDisplay('upload_file',"fs", 74);
document.getElementById('upload').value=GetMessage("fs",110);
GetMessageDisplay('copy_file',"fs", 75);
GetMessageDisplay('copy_file_source',"fs", 76);
GetMessageDisplay('copy_file_destination',"strings", 128);
document.getElementById('copy').value=GetMessage("fs",112);
GetMessageDisplay('move',"fs", 77);
GetMessageDisplay('move_source',"fs", 76);
GetMessageDisplay('move_destination',"strings", 128);
document.getElementById('move_submit').value=GetMessage("fs",77);
GetMessageDisplay('action',"fs", 78);
GetMessageDisplay('get',"fs", 79);
GetMessageDisplay('put',"fs", 80);
GetMessageDisplay('local_file',"fs", 81);
GetMessageDisplay('remote_file',"fs", 82);
GetMessageDisplay('host',"strings", 45);
GetMessageDisplay('port',"strings", 64);
document.getElementById('transfer').value=GetMessage("fs",113);
if (!xml || !xml.hasChildNodes())
{
alert("ERROR: No Filesystem information available.");
return;
}
var cwd = xml.getElementsByTagName('cwd');
if (!cwd)
{
alert("ERROR: Unable to determine the current directory.");
return;
}
cwd = cwd[0].firstChild.nodeValue;
var i;
var j;
var r;
var b = document.getElementById('breadcrumbs');
b.innerHTML = '';
var d = document.getElementById('fsdata');
d.innerHTML = '';
r = '&nbsp;&nbsp;/';
if (cwd != '/')
{
var elems = cwd.split('/');
for (i = 0; i < elems.length; i++)
{
if (elems[i])
{
var ldir = '';
for (j = 0; j <= i; j++)
{
ldir += (elems[j].indexOf('/')==0?'':'/') + elems[j];
}
ldir = '/' + ldir.replace(/^\/+/g, '');
r += "&nbsp;<a href=\"javascript:void(0)\" onclick=\"return ajax_AddToHistory('FsBrowsePage', [true, `dir=" + (ldir) + "`]);\">" + elems[i] + "</a>&nbsp;/";
}
}
}
b.innerHTML = r;
var dirs = new Array();
var files = new Array();
var isUSB = xml.getElementsByTagName('isUSB');
if(isUSB && isUSB.length>0)
{
isUSB = isUSB[0].firstChild.nodeValue;
if(isUSB.toLowerCase()=="true")
{
var pathImage = document.getElementById('fsimage');
if(pathImage)
{
pathImage.src="usb-icon.png";
}
}
}
for (i = 0; i < xml.childNodes.length; i++)
{
var node = xml.childNodes[i];
if (node.nodeName.toLowerCase() == "d")
{
dirs.push(node.firstChild.nodeValue);
}
}
dirs.sort(FsDirCompare);
var mounts=new Array();
for (i = 0; i < xml.childNodes.length; i++)
{
var node = xml.childNodes[i];
if (node.nodeName.toLowerCase() == "u")
{
mounts.push(node.firstChild.nodeValue);
}
}
mounts.sort(FsDirCompare);
var eUSB=new Array();
for (i = 0; i < xml.childNodes.length; i++)
{
var node = xml.childNodes[i];
if (node.nodeName.toLowerCase() == "i")
{
eUSB.push(node.firstChild.nodeValue);
}
}
eUSB.sort(FsDirCompare);
for (var i = 0; i < xml.childNodes.length; i++)
{
var f = xml.getElementsByTagName("f" + i);
if (!f || !f.length)
{
break;
}
var fv = f[0].firstChild.nodeValue;
var fl = xml.getElementsByTagName("fl" + i);
var flv = fl[0].firstChild.nodeValue;
files.push(new Array(fv, flv));
}
files.sort(FsFileCompare);
var r = '';
r += "<table class='table table-striped table-condensed'>";
var root = false;
if (cwd == '/')
{
root = true;
}
if (!root)
{
r += "<tr><td width=\"128\">&nbsp;&nbsp;&nbsp;<img src=\"folder.gif\" /></td><td><a href=\"javascript:void(0)\" onclick=\"return ajax_AddToHistory('FsBrowsePage', [true, `dir=" + (FsDirname(cwd)) + "`]);\">&lt;up&gt;</a></td><td></td></tr>";
}
for (i = 0; i < eUSB.length; i++)
{
r += "<tr>";
r += "<td width=\"128\">&nbsp;&nbsp;&nbsp;<img width=\"20\" height=\"22\" src=\"usb-icon.png\" /></td>";
r += "<td><a href=\"javascript:void(0)\" onclick=\"return ajax_AddToHistory('FsBrowsePage', [true, `dir=";
r += (root) ? (cwd + eUSB[i]) : (cwd + (eUSB[i].indexOf('/')==0?'':'/') + eUSB[i]);
r += "`]);\">" + eUSB[i] + "</a></td><td></td>";
r += "</tr>";
}
for (i = 0; i < mounts.length; i++)
{
r += "<tr>";
r += "<td width=\"128\">&nbsp;&nbsp;&nbsp;<img width=\"20\" height=\"22\" src=\"usb-icon.png\" />&nbsp;&nbsp;<a href=\"javascript:void(0)\" onclick=\"if (confirm(`Are you SURE you want to unmount " + mounts[i] + "?`)) ajax_FsUnmount([true, `dir=" + (cwd) + "&amp;path=";
r += (root) ? (cwd + mounts[i]) : (cwd + '/' + mounts[i]);
r += "&amp;action=unmount`]); return false;\"><img width=\"18\" height=\"18\" src=\"eject-icon.png\" /></a></td>";
r += "<td><a href=\"javascript:void(0)\" onclick=\"return ajax_AddToHistory('FsBrowsePage', [true, `dir=";
r += (root) ? (cwd + mounts[i]) : (cwd + (mounts[i].indexOf('/')==0?'':'/') + mounts[i]);
r += "`]);\">" + mounts[i] + "</a></td><td></td>";
r += "</tr>";
}
for (i = 0; i < dirs.length; i++)
{
r += "<tr>";
r += "<td width=\"128\">&nbsp;&nbsp;&nbsp;<img src=\"folder.gif\" />&nbsp;&nbsp;<a href=\"javascript:void(0)\" onclick=\"if (confirm(`Are you SURE you want to delete the directory " + dirs[i] + "?`)) ajax_FsBrowseClean([true, `dir=" + (cwd) + "&amp;path=";
r += (root) ? (cwd + dirs[i]) : (cwd + '/' + dirs[i]);
r += "&amp;action=deletedir`]); return false;\"><img src=\"remove.gif\" /></a></td>";
r += "<td><a href=\"javascript:void(0)\" onclick=\"return ajax_AddToHistory('FsBrowsePage', [true, `dir=";
r += (root) ? (cwd + dirs[i]) : (cwd + '/' + dirs[i]);
r += "`]);\">" + dirs[i] + "</a></td><td></td>";
r += "</tr>";
}
for (i = 0; i < files.length; i++)
{
r += "<tr>";
r += "<td width=\"128\">&nbsp;&nbsp;&nbsp;<img src=\"file.gif\" />&nbsp;&nbsp;<a href=\"javascript:void(0)\" onclick=\"if (confirm(`Are you SURE you want to delete the file " + files[i][0] + "?`)) ajax_FsBrowseClean([true, `dir=" + (cwd) + "&amp;path=";
r += (root) ? (cwd + files[i][0]) : (cwd + '/' + files[i][0]);
r += "&amp;action=deletefile`]); return false;\"><img src=\"remove.gif\" /></a></td>";
r += "<td><a href=\"/fs?file=";
r += (root) ? (cwd + files[i][0]) : (cwd + '/' + files[i][0]);
r += "\" target=\"_blank\">" + files[i][0] + "</a></td><td>" + files[i][1] + "</td>";
r += "</tr>";
}
r += "</table>";
d.innerHTML = r;
}
function FsUploadClearForm(xml)
{
var p = document.getElementById('uploadform');
var oldInput = document.getElementById('fsuploadfile');
var newInput = document.createElement('input');
newInput.id = 'fsuploadfile';
newInput.name = 'selectedfile';
newInput.type = 'file';
newInput.size = '32';
newInput.maxlength = '255';
p.replaceChild(newInput, oldInput);
}
function SetFilesystemDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Filesystem.Mass_Storage.USB_Auto_Mount');
document.getElementById("usbautomountform").style.display = "block";
}
function FsNavigationDisplay(xml)
{
GetMessageDisplay('statistics',"strings", 36);
GetMessageDisplay('browse',"fs", 109);
if(xml && xml.hasChildNodes())
{
var fsuser = GetXmlData(xml,"fsuser");
if(fsuser != "true")
{
document.getElementById('fs_section').style.visibility='hidden';
document.getElementById('fs_section').style.display='none';
}
}
}
function FsStatsDisplay()
{
GetMessageDisplay('filesystem_statistics',"fs", 63);
GetMessageDisplay('filesysytem_size',"fs", 64);
GetMessageDisplay('available_space',"fs", 65);
GetMessageDisplay('file_dir_space_used',"fs", 66);
GetMessageDisplay('actions',"fs", 67);
GetMessageDisplay('format',"fs", 70);
GetMessageDisplay('rootfs_filesysytem_size',"fs", 64);
GetMessageDisplay('rootfs_available_space',"fs", 65);
GetMessageDisplay('rootfs_file_dir_space_used',"fs", 66);
}
