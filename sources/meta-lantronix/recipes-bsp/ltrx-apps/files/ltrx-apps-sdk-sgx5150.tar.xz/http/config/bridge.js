function SetBridgeDisplay(xml)
{
displayElementRootNames = new Array();
var menu=document.getElementById('networknav_br_menu');
if(menu)menu.style.display='block';
SetSubmit(false);
GetMessageDisplay('bridge_config',"strings",37);
GetMessageDisplay('bridge_state',"strings",46);
GetMessageDisplay('bridge_enabled',"strings",14);
GetMessageDisplay('bridge_disabled',"strings",15);
GetMessageDisplay('bridge_transparentmode',"bridge",22);
GetMessageDisplay('bridge_transparentmode_enabled',"strings",14);
GetMessageDisplay('bridge_transparentmode_disabled',"strings",15);
GetMessageDisplay('bridging_mac_address',"bridge",14);
GetMessageDisplay('bridging_ip_address',"bridge",20);
GetMessageDisplay('bridging_auto_ip',"bridge",23);
GetMessageDisplay('bridge_autoip_enabled',"strings",14);
GetMessageDisplay('bridge_autoip_disabled',"strings",15);
GetMessageDisplay('bridging_ipv6_address',"bridge",21);
GetMessageDisplay('bridging_auto_ip6',"bridge",24);
GetMessageDisplay('bridge_autoip6_enabled',"strings",14);
GetMessageDisplay('bridge_autoip6_disabled',"strings",15);
document.getElementById('submit_button').value=GetMessage("strings",7);
SetDisplaySelection('Bridge.State');
SetDisplaySelection('Bridge.Bridging_Mode');
document.getElementById('dhcpshortcut').style.display=(GetInputElementValue(document.forms[0].elements['new_Bridge.Bridging_Mode'])!='Network')?'none':'';
SetDisplaySelection('Bridge.Transparent_Mode');
SetDisplaySelection('Bridge.Network_Access_for_Gateway');
document.getElementById('bridge_networkaccess_Display').style.display=(GetInputElementValue(document.forms[0].elements['new_Bridge.Transparent_Mode'])=='Disabled')?'none':'';
SetDisplaySelection('Bridge.Ethernet_Interface');
SetDisplaySelection('Bridge.Bridging_MAC_Address');
SetDisplaySelection('Bridge.Bridging_Initial_Scan_Interval');
SetDisplaySelection('Bridge.Bridging_Scan_Interval');
SetDisplaySelection('Bridge.Bridging_IP_Address');
SetDisplaySelection('Bridge.Auto_Detect_IP_Address');
document.getElementById("configure_bridge_ipv4_address").style.display=(document.forms[0].elements["new_Bridge.Auto_Detect_IP_Address"].value=="Enabled")?"none":"";
SetDisplaySelection('Bridge.Bridging_IPv6_Address');
SetDisplaySelection('Bridge.Auto_Detect_IPv6_Address');
document.getElementById("configure_bridge_ipv6_address").style.display=(document.forms[0].elements["new_Bridge.Auto_Detect_IPv6_Address"].value=="Enabled")?"none":"";
document.getElementById("bridgedefform").style.display = "block";
}
function BridgeIPRender(xml)
{
var numEntries = GetXmlData(xml,"numEntries");
var d = document.getElementById("bridgebridgingip");
var rs = "<table class=\"table table-bordered table-condensed\" style=\"background:transparent\">";
rs += "<thead><tr><td><b>MAC Address</b></td><td><b>IP Address</b></td></tr></thead>";
var ip4="";
var ip6="";
for(var i=1; i<=numEntries; i++)
{
var mac = GetXmlData(xml,"mac_"+i);
var ip = GetXmlData(xml, "ip_"+i);
if(-1!=ip.indexOf(":"))
ip6 += "<tr><td width='40%'>"+mac+"</td><td>"+ip+"</td></tr>";
else
ip4 += "<tr><td width='40%'>"+mac+"</td><td>"+ip+"</td></tr>";
}
var re = "</table>";
if(d && ip4!="")
d.innerHTML = rs + ip4 + re;
d = document.getElementById("bridgebridgingip6");
if(d && ip6!="")
d.innerHTML = rs + ip6 + re;
}
function BridgeRender(xml)
{
var menu=document.getElementById('networknav_br_menu');
if(menu)menu.style.display='block';
var numBridges = GetXmlData(xml, "numBridges");
var bridgeNum = GetXmlData(xml, 'bridgeNum');
var bridgeString = GetMessage("net", 121);
document.getElementById("hiddenbridgenumber").innerHTML = bridgeNum;
document.getElementById("bridgeidentifier").innerHTML = bridgeString + (Number(bridgeNum)+1);
var d = document.getElementById("bridge_selection");
if(d)
{
var r = "";
r += '<table id="Nav1">';
r += "<tr>";
if(numBridges > 4)
{
r += "<";
r += "select name='navSelect' ";
r += "id='navSelect' ";
r += "onchange=\" ";
r += "var page = document.getElementById('hiddencurrentbridgepage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'bridgeidentifier='+this.value]);";
r += " \" ";
r += ">";
for(var i = 0; i < numBridges; ++i)
{
var sel = (bridgeNum == i) ? " selected " : "";
r += "<option value='" + i + "' " + sel + ">";
r += bridgeString + (i+1);
r += "</option>";
}
r += "</select>";
}
else
{
for(var i = 0; i < numBridges; ++i)
{
r += "<td id='bridgenav" + (i+1) + "'>";
r += "<a ";
r += "href='javascript:void(0)'";
r += "onclick=\"";
r += "var page = document.getElementById('hiddencurrentbridgepage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'bridgeidentifier=" + i + "']);";
r += "\"";
r += ">";
r += bridgeString + (i+1);
r += "</a>";
r += "</td>";
}
}
r += "</tr>";
r += "</table>";
d.innerHTML = r;
HighlightElementInTable("Nav1", "bridgenav" + (Number(bridgeNum)+1));
}
}
function BridgeStatusDisplay()
{
GetMessageDisplay('bridge_status',"strings",0);
GetMessageDisplay('enable_state',"bridge",6);
GetMessageDisplay('transparent_state',"bridge",22);
GetMessageDisplay('active_state',"bridge",7);
GetMessageDisplay('ethernet_link',"strings",58);
GetMessageDisplay('wlan_link',"bridge",8);
GetMessageDisplay('primary_interface',"bridge",9);
GetMessageDisplay('bridging_mac',"bridge",10);
GetMessageDisplay('ethernet_mac',"bridge",11);
GetMessageDisplay('bridging_ip',"bridge",20);
GetMessageDisplay('bridging_ip6',"bridge",21);
GetMessageDisplay('bridge_stats',"strings",36);
GetMessageDisplay('ethernet_to_wlan',"bridge",12);
GetMessageDisplay('wlan_to_ethernet',"bridge",13);
GetMessageDisplay('bridge_unicast',"strings",79);
GetMessageDisplay('bridge_nonunicast',"strings",80);
GetMessageDisplay('bridge_discards',"strings",81);
GetMessageDisplay('bridge_octets',"strings",78);
}
