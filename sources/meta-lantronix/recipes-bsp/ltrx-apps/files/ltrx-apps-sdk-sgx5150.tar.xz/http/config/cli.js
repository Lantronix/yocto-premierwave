function SetCliStatsDisplay(xml)
{
GetMessageDisplay('command_line_interface_stats',"cli",13);
GetMessageDisplay('cli_telnet',"cli",14);
GetMessageDisplay('cli_server_status',"cli",15);
GetMessageDisplay('cli_uptime',"strings",95);
GetMessageDisplay('cli_telnet_current_conn',"cli",16);
GetMessageDisplay('cli_ssh_server_status',"cli",15);
GetMessageDisplay('cli_ssh_uptime',"strings",95);
GetMessageDisplay('cli_ssh_current_connections',"cli",16);
var menu=document.getElementById('cli_menu');
if(menu)menu.style.display='block';
}
function CliConnectionsRender(xml, type)
{
var d = document.getElementById(type + "conn");
d.innerHTML = '';
var r = '';
var count = 0;
if(! xml || ! xml.hasChildNodes())
{
r += "<None>";
}
else
{
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "c")
{
r += GetXmlData(node, "s");
r += "&nbsp;<a class='btn btn-primary btn-sm' href=\"javascript:void(0)\" onclick=\"bootbox.confirm(GetConfirmationMessage('cli',26), function(result) {";
r += "if(result==true){ajax_CliStatsClean([true, 'action=kill" + type + "&amp;id=" + GetXmlData(node, "i");
r += "']);}});return false;\">"+GetMessage("cli",27)+"</a>";
r += "<br/>";
r += "&nbsp;&nbsp;&nbsp;&nbsp;";
r += ""+GetMessage("strings", 95)+": " + GetXmlData(node, "u");
r += "<br/>";
++count;
}
}
}
if(count > 1)
{
r += "[<a ";
r += 'href="javascript:void(0)"';
r += 'onclick="';
r += "if(";
r += "confirm('"+GetMessage("cli",30)+"')";
r += ")";
r += "{";
r += "ajax_CliStatsClean(";
r += "[true,'action=wipeout" + type + "']";
r += ");";
r += "}";
r += "return false;";
r += '"';
r += ">"+GetMessage("cli",28)+"</a>]";
}
d.innerHTML = r;
}
function CliTelnetRender(xml)
{
var menu=document.getElementById('cli_menu');
if(menu)menu.style.display='block';
CliConnectionsRender(xml, 'telnet');
}
function CliSshRender(xml)
{
var menu=document.getElementById('cli_menu');
if(menu)menu.style.display='block';
CliConnectionsRender(xml, 'ssh');
}
function UpdateCliDisplay(initial, optElement)
{
Update(optElement);
}
function UpdateTelnetDisplay(initial, optElement)
{
var telnetState = GetDisplayValue("new_CliTelnet.State");
SetFxDisplay(
"telnet_port_Display",
telnetState == "Enabled" ? "" : "none",
initial
);
SetFxDisplay(
"telnet_max_sessions_Display",
telnetState == "Enabled" ? "" : "none",
initial
);
SetFxDisplay(
"telnet_authentication_Display",
telnetState == "Enabled" ? "" : "none",
initial
);
Update(optElement);
}
function UpdateSshDisplay(initial, optElement)
{
var sshState = GetDisplayValue("new_CliSsh.State");
SetFxDisplay(
"ssh_port_Display",
sshState == "Enabled" ? "" : "none",
initial
);
SetFxDisplay(
"ssh_max_sessions_Display",
sshState == "Enabled" ? "" : "none",
initial
);
Update(optElement);
}
function SetCliDisplay(xml)
{
GetMessageDisplay('command_line_interface_config',"cli",17);
GetMessageDisplay('cli_enable_level_password',"strings",122);
GetMessageDisplay('cli_quit_connect_line',"cli",18);
GetMessageDisplay('cli_inactivity_timeout',"cli",19);
GetMessageDisplay('cli_inactivity_timeout_minutes',"strings",73);
document.getElementById('submit_button').value=GetMessage("strings",7);
var menu=document.getElementById('cli_menu');
if(menu)menu.style.display='block';
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Cli.Enable_Level_Password');
SetDisplaySelection('Cli.Quit_Connect_Line');
SetDisplaySelection('Cli.Inactivity_Timeout');
SetDisplaySelection('Cli.Line_Authentication');
UpdateCliDisplay(true);
document.getElementById("cliform").style.display = "block";
}
function SetTelnetDisplay(xml)
{
GetMessageDisplay('cli_telnet_state',"cli",20);
GetMessageDisplay('cli_telnet_enabled',"strings",14);
GetMessageDisplay('cli_telnet_disabled',"strings",15);
GetMessageDisplay('cli_telnet_port',"cli",21);
GetMessageDisplay('cli_telnet_max_sessions',"cli",22);
GetMessageDisplay('cli_telnet_authentication',"cli",23);
GetMessageDisplay('cli_telnet_auth_enabled',"strings",14);
GetMessageDisplay('cli_telnet_auth_disabled',"strings",15);
SetDisplaySelection('CliTelnet.State');
SetDisplaySelection('CliTelnet.Port');
SetDisplaySelection('CliTelnet.Max_Sessions');
SetDisplaySelection('CliTelnet.Authentication');
UpdateTelnetDisplay(true);
document.getElementById("cliform").style.display = "block";
}
function SetSshDisplay(xml)
{
GetMessageDisplay('cli_ssh_state',"cli",24);
GetMessageDisplay('cli_ssh_state_enabled',"strings",14);
GetMessageDisplay('cli_ssh_state_disabled',"strings",15);
GetMessageDisplay('cli_ssh_port',"cli",25);
GetMessageDisplay('cli_ssh_max_sessions',"cli",70);
SetDisplaySelection('CliSsh.State');
SetDisplaySelection('CliSsh.Port');
SetDisplaySelection('CliSsh.Max_Sessions');
UpdateSshDisplay(true);
document.getElementById("cliform").style.display = "block";
}
function CliConfigExportPostProcedure()
{
FileSystemMonitor();
return ajax_CliConfigPost(
[true, ajaxGetFormValuesWithoutClearingThem('cliform')]
);
}
function SetCliNavDisplay()
{
GetMessageDisplay('cli_statistics',"strings",36);
GetMessageDisplay('cli_configuration',"strings",37);
}
