function UpdateRoleType()
{
if(document.getElementById('newuser_role').value=='Custom')
{
document.getElementById("custom_role_name").style.display='';
}
else
{
document.getElementById("custom_role_name").style.display='none';
}
}
function htmlDecode(input)
{
var doc = new DOMParser().parseFromString(input, "text/html");
return doc.documentElement.textContent;
}
function EditUserDisplay(xml)
{
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve user.</p>";
var d = document.getElementById('results');
d.innerHTML=r;
return;
}
var identifier=GetXmlData(xml,"index");
var name=GetXmlData(xml,"name");
document.getElementById('newuser').reset();
document.getElementById('edit_user').value=identifier;
document.getElementById('newuser_name').value=name;
document.getElementById('newuser_password').value=htmlDecode(GetXmlData(xml,"password"));
var rolename=GetXmlData(xml,"rolename");
$("#newuser_rolename").empty();
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "roles")
{
var name=GetXmlData(node,"role_name");
$("#newuser_rolename").append(
$('<option></option>').val(name).html(name)
);
}
}
document.getElementById('newuser_rolename').value = rolename;
document.getElementById("newuser").style.display = "block";
}
function EditRoleDisplay(xml)
{
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve role.</p>";
var d = document.getElementById('results');
d.innerHTML=r;
return;
}
var identifier=GetXmlData(xml,"index");
var name=GetXmlData(xml,"name");
document.getElementById('newrole').reset();
document.getElementById('edit_role').value=identifier;
document.getElementById('newrole_name').value=name;
document.getElementById('newrole_writepermission').value=GetXmlData(xml,"write");
document.getElementById('newrole_executepermission').value=GetXmlData(xml,"execute");
var writes = document.getElementById('newrole_writepermission').value.split(",");
for(var i=0;i<writes.length; i++)
{
jQuery("input[name='newrolename_writegroupId[]']").each(
function()
{
if( this.value == writes[i].trim() )
{
this.checked=true;
}
}
)
}
var executes = document.getElementById('newrole_executepermission').value.split(",");
for(var i=0;i<executes.length; i++)
{
jQuery("input[name='execute_permission[]']").each(
function()
{
if( this.value == executes[i].trim() )
{
this.checked=true;
}
}
)
}
document.getElementById("newrole").style.display = "block";
}
function SetUserMangementDisplay(xml)
{
return;
}
function SetUserMangementData(xml)
{
displayElementRootNames = new Array();
GetMessageDisplay('user_mgmt', "usermgmt", 4);
if(! xml || ! xml.hasChildNodes())
{
r += "<p>Failed to retrieve user management settings.</p>";
var d = document.getElementById('results');
d.innerHTML=r;
return;
}
$("#roles").empty();
t_start = "<table class='table table-striped table-condensed'>";
a = "<thead><tr><td colspan='2'><b></b></td></tr><thead>";
document.getElementById('newuser').reset();
document.getElementById('newrole').reset();
u_count=0;
u = "<thead><tr><td width='10%'><b>Delete</b></td><td><b>Name</b></td><td><b>Role</b></td></tr></thead>";
r_count=0;
r = "<thead><tr><td width='10%'><b>Delete</b></td><td><b>Name</b></td><td><b>Configuration Groups</b></td><td><b>Actions</b></td></tr></thead>";
t_end = "</table>";
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "admin")
{
for(var j = 0; node && j < node.childNodes.length; ++j)
{
var node2 = node.childNodes[j];
if(node2.nodeName.toLowerCase() == "admin_username")
{
var admin_username=node2.firstChild.nodeValue;
a += "<tr><td width='40%'><b>Username:</b></td><td><input type='text' size='15' maxlength='15' name='admin_username' org_value='"+admin_username+"' value='"+admin_username+"' ";
a += "onkeyup='updateButtonVisibilities(\"admin_form\",\"submit_changes\",\"cancel_changes\");'/> </td></tr>";
}
if(node2.nodeName.toLowerCase() == "admin_password")
{
var admin_password=node2.firstChild.nodeValue;
a += "<tr><td><b>Password:</b></td><td><input type='password' size='15' maxlength='15' id='admin_password' name='admin_password' org_value='"+admin_password+"' value='"+admin_password+"' ";
a += "onkeyup='updateButtonVisibilities(\"admin_form\",\"submit_changes\",\"cancel_changes\");'/>";
a += "&nbsp;&nbsp;<input type=\"checkbox\" id=\"show_apass\" onclick=\"document.getElementById('admin_password').type=(document.getElementById('show_apass').checked?'text':'password');\">";
a += "<span id=\"str_show_apassw\">Show Password</span>";
a += "</td></tr>";
}
}
}
if(node.nodeName.toLowerCase() == "users")
{
var user_index=GetXmlData(node,"index");
var name=GetXmlData(node,"name");
var rolename=GetXmlData(node,"rolename");
u_count++;
u += "<tr>";
u += "<td width='10%'>"
u += "<input type='checkbox' ";
u += " onclick='updateButtonVisibilities(\"users_form\",\"submit_user_changes\",\"cancel_user_changes\");' ";
u += " name='user.state." + user_index +"' org_state='false'/>";
u += "</td>";
u += "<td width='30%'>";
u += "<a href=\"javascript:void(0)\" ";
u += " onclick=\"";
u += "ajax_AddToHistory(";
u += "'UserManagementPage',";
u += "[true, '&amp;edit_user=" + user_index + "']";
u += ");";
u += "return false;";
u += "\"";
u += ">";
u += "<img class='fsimage' src='edit-icon.gif' width='20' height='20'>&nbsp;";
u += name;
u += "</a>"
u += "</td>";
u += "<td>";
if(rolename!="")
{
u += rolename;
}
u += "</td>";
u += "</tr>";
}
if(node.nodeName.toLowerCase() == "roles")
{
var role_index=0;
if(GetXmlData(node,"index"))
role_index=GetXmlData(node,"index");
var name=GetXmlData(node,"name");
var write="";
if(GetXmlData(node,"write"))
write=GetXmlData(node,"write");
var execute="";
if(GetXmlData(node,"execute"))
execute=GetXmlData(node,"execute");
r_count++;
r += "<tr>";
r += "<td width='10%'>"
if(GetXmlData(node,"index"))
{
r += "<input type='checkbox' ";
r += " onclick='updateButtonVisibilities(\"roles_form\",\"submit_role_changes\",\"cancel_role_changes\");' ";
r += " name='role.state." + role_index +"' org_state='false'/>";
}
r += "</td>";
r += "<td width='30%'>";
if(GetXmlData(node,"index"))
{
r += "<a href=\"javascript:void(0)\" ";
r += " onclick=\"";
r += "ajax_AddToHistory(";
r += "'UserManagementPage',";
r += "[true, '&amp;edit_role=" + role_index + "']";
r += ");";
r += "return false;";
r += "\"";
r += ">";
r += "<img class='fsimage' src='edit-icon.gif' width='20' height='20'>&nbsp;";
r += name;
r += "</a>"
}
else
{
r += name;
}
$("#roles").append(
$('<option></option>').val(name).html(name)
);
r += "</td>";
r += "<td>";
r += write;
r += "</td>";
r += "<td>";
r += execute;
r += "</td>";
r += "</tr>";
}
}
var d = document.getElementById('admin_configuration');
if(d)
d.innerHTML=t_start+a+t_end;
updateButtonVisibilities('admin_form','submit_changes','cancel_changes');
document.getElementById("admin_form").style.display = "block";
if(u_count==0)
{
u += "<tr><td colspan='3'><i>No users are defined</i></td></tr>";
}
var d = document.getElementById('user_list');
if(d)
d.innerHTML=t_start+u+t_end;
updateButtonVisibilities('users_form','submit_user_changes','cancel_user_changes');
document.getElementById("users_form").style.display = "block";
document.getElementById("newuser").style.display = "block";
if(r_count==0)
{
r += "<tr><td colspan='4'><i>No roles are defined</i></td></tr>";
}
var d = document.getElementById('roles_list');
if(d)
d.innerHTML=t_start+r+t_end;
updateButtonVisibilities('roles_form','submit_role_changes','cancel_role_changes');
document.getElementById("roles_form").style.display = "block";
document.getElementById("newrole").style.display = "block";
}
function UpdateRolePermissionsToText()
{
var checkboxes = document.getElementsByName('newrolename_writegroupId[]');
var vals = "";
for (var i=0, n=checkboxes.length;i<n;i++)
{
if (checkboxes[i].checked)
{
vals += ","+checkboxes[i].value;
}
}
if (vals) vals = vals.substring(1);
document.getElementById("newrole_writepermission").value= vals;
}
function XmlGroupsListRender(xml)
{
var d = document.getElementById('xmlgroupslist');
if(d)
{
d.innerHTML = '';
var r = '';
if(! xml || ! xml.hasChildNodes())
{
r += GetMessage("xml",62);
}
else
{
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead><tr>                  <td width = '40%'><b>Configuration Groups:</b></td>";
r += "<td><b>Write</b></td>                  </tr></thead>";
var i;
for(i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
var groupId = node.nodeName.toLowerCase();
var group = node.firstChild.nodeValue;
var localizedGroup=group;
localizedGroup = LocalizeGroupName(localizedGroup);
r += "<tr>";
r += "<td width='40%'>"+localizedGroup+"</td>";
r += "<td><input type=\"checkbox\" name=\"newrolename_writegroupId[]\" value=\"" + group + "\"></td>";
r += "</tr>";
}
r += "</table>";
}
d.innerHTML = r;
}
UpdateRolePermissionsToText();
}
function UpdateExecuteValues()
{
var checkboxes = document.getElementsByName('execute_permission[]');
var vals = "";
for (var i=0, n=checkboxes.length;i<n;i++)
{
if (checkboxes[i].checked)
{
vals += ","+checkboxes[i].value;
}
}
if (vals) vals = vals.substring(1);
document.getElementById('newrole_executepermission').value = vals;
}
