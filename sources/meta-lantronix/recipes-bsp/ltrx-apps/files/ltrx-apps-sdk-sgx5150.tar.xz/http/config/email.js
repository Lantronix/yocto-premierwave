function UpdateEmailDisplay(initial, optElement)
{
Update(optElement);
}
function SetAdmin_EMAILDisplay()
{
var menu=document.getElementById('email_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('email_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function SetEmailDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Email.To');
SetDisplaySelection('Email.CC');
SetDisplaySelection('Email.Reply_To');
SetDisplaySelection('Email.Subject');
SetDisplaySelection('Email.Message_File');
SetDisplaySelection('Email.Priority');
UpdateEmailDisplay(true);
document.getElementById("emailform").style.display = "block";
}
function EmailLogRender(xml)
{
var d = document.getElementById('emaillog');
d.innerHTML = '';
var numLogs = 0;
var c = '';
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "l")
{
numLogs++;
c += unescape(node.firstChild.nodeValue) + "<br/>";
}
}
var r = '';
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead>";
r += "<tr>";
r += "<td>";
r += "<b>Log</b>";
if(numLogs > 0)
{
r += " [<a href=\"javascript:void(0)\" ";
r += "onclick=\"if(";
r += "confirm('Are you SURE you want to clear this information?')";
r += "){";
r += "FileSystemMonitor();";
r += "ajax_EmailStatsClean(";
r += "[false, document.getElementById('hiddenemail').innerHTML, 'clearlog']";
r += ");";
r += "}";
r += "return false;";
r += "\">Clear</a>]";
}
r += "</td>";
r += "</tr>";
r += "</thead>";
r += "<tbody>";
r += "<tr><td>";
r += numLogs > 0 ? c : "No log data available."
r += "</td></tr>";
r += "</tbody>";
r += "</table>";
d.innerHTML = r;
}
function EmailRender(xml)
{
var d = document.getElementById("multiemaildropdown");
if(d)
{
var sel="";
var i;
var curLine = Number(document.getElementById("hiddenemail").innerHTML);
var r = "<table><tr><td>";
r += "<select class='form-control' name='navSelect' ";
r += "id='navSelect' ";
r += "onchange=\" ";
r += "var page = document.getElementById('hiddencurrentemailpage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'index='+this.value]);";
r += " \" ";
r += ">";
for(i = 0; i < 16; i++)
{
if(curLine == i)
{
sel = " SELECTED ";
}
else
{
sel = "";
}
r += "<option value='" + i + "' " + sel + ">Email " + (i+1) + " </option>";
}
r += "</select>";
r += "</td></tr></table>";
d.innerHTML = "";
d.innerHTML = r;
}
return r;
}
