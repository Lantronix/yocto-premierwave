function DiagnosticLogOutputSelection(xml)
{
var numSerialPorts = GetXmlData(xml, "numSerialPorts");
var numLines = document.getElementById('numSerialPorts').innerHTML;
var d = document.getElementById("diagnosticlogoutput_selection");
if(d)
{
var r = "";
r+="<select class='form-control' name=\"new_Log.Output\" onchange=\"UpdateDiagnosticsLogDisplay(false);\">";
r+="<option value=\"Disable\">"+GetMessage("diagnostics_log",8)+"</option>";
r+="<option value=\"Filesystem\">"+GetMessage("strings",16)+"</option>";
numSerialPorts=Math.min(4,numSerialPorts);
for(var i = 0;i<numSerialPorts;++i)
{
if(i<numLines)
r += "<option value='Line " + (i+1) + "' " + ">"+GetMessage("strings",124)+" " + (i+1) +" </option>";
else
r += "<option value='USB " + (i-Number(numLines)+1) + "' " + ">"+"USB " + (i-Number(numLines)+1) +" </option>";
}
r+="</select>";
d.innerHTML = r;
}
}
function UpdateDiagnosticsLogDisplay(initialize)
{
var output = GetDisplayValue("new_Log.Output");
SetFxDisplay(
"diagnostics_log_max_length_Display",
output == "Filesystem" ? "" : "none"
);
Update();
}
function SetDiagnosticsLogDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Log.Output');
SetDisplaySelection('Log.Max_Length');
UpdateDiagnosticsLogDisplay(true);
document.getElementById("logform").style.display = "block";
}
function SetLogDisplay()
{
GetMessageDisplay('diag_log',"diagnostics_log",7);
GetMessageDisplay('diag_log_config',"strings",37);
GetMessageDisplay('diag_log_output',"diagnostics_log",3);
GetMessageDisplay('diag_log_max_length',"diagnostics_log",4);
GetMessageDisplay('diag_log_kbytes',"diagnostics_log",5);
document.getElementById('submit_button').value=GetMessage("strings",7);
}
