function validate_uri(element)
{
element.value=element.value.replace("\\","/");
}
function SetAdmin_HTTPDisplay()
{
var menu=document.getElementById('http_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('http_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
function HttpAuthRender(xml)
{
GetMessageDisplay('http_auth',"http",111);
GetMessageDisplay('auth_type',"http",89);
GetMessageDisplay('auth_none',"strings",47);
GetMessageDisplay('auth_basic',"http",90);
GetMessageDisplay('auth_digest',"http",91);
GetMessageDisplay('ssl_auth_basic',"http",92);
GetMessageDisplay('ssl_auth_digest',"http",93);
document.getElementById('submit_button').value = GetMessage("strings",7);
GetMessageDisplay('current_config',"strings",40);
SetAdmin_HTTPDisplay();
var d = document.getElementById('httpdata');
d.innerHTML = '';
var r = '';
var numAuth = 0;
for(var i = 0; xml && i < xml.childNodes.length; i++)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "a")
{
numAuth++;
var uri = GetXmlData(node, "p");
var realm = GetXmlData(node, "r");
var type = GetXmlData(node, "t");
type = type.replace("Basic",GetMessage("http",90)).replace("Digest",GetMessage("http",91));
r += "<table class=\"table table-striped table-condensed\">";
r += "<tr><td width='40%'><b>URI:</b></td><td>";
r += uri;
r += "&nbsp;<a href='javascript:void(0)' class='btn btn-primary btn-sm'";
r += " onclick=\"";
r += "bootbox.confirm('"+GetConfirmationMessage("strings",41)+"',function(result){if(result==true){";
r += "ajax_HttpAuthClean([true, 'action=";
r += "deleteuri&amp;uri=";
r += uri;
r += "']);}});return false;\"";
r += ">"+GetMessage("strings",42)+"</a>";
r += "</td></tr>";
r += "<tr><td><b>"+GetMessage("http",89)+":</b></td><td>" + type + "</td></tr>";
r += "<tr><td><b>"+GetMessage("http",94)+":</b></td><td>";
var numUsers = 0;
var users = node.getElementsByTagName('u');
for(var j = 0; j < users.length; j++)
{
numUsers++;
r += users[j].firstChild.nodeValue +
"<br/>";
}
if(! numUsers)
{
r += GetMessage("strings",47);
}
r += "</td></tr>";
r += "</table>";
}
}
if(! numAuth)
{
d.innerHTML = GetMessage("http",95);
}
else
{
d.innerHTML = r;
}
}
function BuildHttpHtml(xml)
{
GetMessageDisplay('http_conf',"http",112);
GetMessageDisplay('server_state',"strings",46);
GetMessageDisplay('state_enable',"strings",14);
GetMessageDisplay('state_disable',"strings",15);
GetMessageDisplay('port',"strings",64);
GetMessageDisplay('max_timeout',"strings",38);
GetMessageDisplay('timeout_sec',"strings",39);
GetMessageDisplay('max_bytes',"http",84);
GetMessageDisplay('logging_state',"http",85);
GetMessageDisplay('logging_enabled',"strings",14);
GetMessageDisplay('logging_disabled',"strings",15);
GetMessageDisplay('max_log_entries',"http",86);
GetMessageDisplay('log_format',"http",87);
GetMessageDisplay('auth_timeout',"http",88);
GetMessageDisplay('timeout_min',"strings",73);
document.getElementById('submit_button').value = GetMessage("strings",7);
SetAdmin_HTTPDisplay();
GetMessageDisplay('conf_https_state',"http",114);
GetMessageDisplay('conf_https_state_enable',"strings",14);
GetMessageDisplay('conf_https_state_disable',"strings",15);
GetMessageDisplay('secure_port',"http",81);
GetMessageDisplay('secure_protocols',"http",82);
GetMessageDisplay('secure_credential',"http",83);
var d = document.getElementById('select_secure_credential');
d.options.length = 0;
var unlistedStr="<"+GetMessage("strings",163)+">";
d.options[0] = new Option(unlistedStr, "", true);
d.options[1] = new Option("device-certificate", "device-certificate", true);
for(var i = 0; xml && xml.hasChildNodes() && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "ssl_credential")
{
var name = GetXmlData(node, "name");
d.options[d.options.length] = new Option(name, name);
}
}
SetFxDisplay(
"select_credential_Display",
d.options.length > 1 ? "" : "none",
true
);
}
function UpdateHttpServerDisplay(initial, optElement)
{
var securePort = GetDisplayValue("new_HTTP_Server.Secure_Port");
SetFxDisplay(
"secure_protocols_Display",
securePort != "<None>" ? "" : "none",
initial
);
SetFxDisplay(
"secure_credentials_Display",
securePort != "<None>" ? "" : "none",
initial
);
var credential = GetDisplayValue("new_HTTP_Server.Selected_Credential");
SetFxDisplay(
"secure_credentials_selection_Display",
credential == "" ? "" : "none",
initial
);
Update(optElement);
}
function SetHttpServerDisplay()
{
SetAdmin_HTTPDisplay();
displayElementRootNames = new Array();
SetDisplaySelection('HTTP_Server.State');
SetDisplaySelection('HTTP_Server.Port');
SetDisplaySelection('HTTP_Server.HTTPS_State');
SetDisplaySelection('HTTP_Server.Secure_Port');
var v = SetDisplaySelection('HTTP_Server.Secure_Protocols');
var maxSecureProtocols=3;
maxSecureProtocols+=1;
for(var n = 0; n < maxSecureProtocols; ++n)
{
var bit = 1 << n;
var e = document.forms[0].elements[
'new_HTTP_Server.Secure_Protocols_' + n
];
e.checked = (( v & bit) != 0);
}
var credentialName = SetDisplaySelection('HTTP_Server.Secure_Credentials');
SetDisplayValue('new_HTTP_Server.Selected_Credential', credentialName);
SetDisplaySelection('HTTP_Server.Max_Timeout');
SetDisplaySelection('HTTP_Server.Max_Bytes');
SetDisplaySelection('HTTP_Server.Logging_State');
SetDisplaySelection('HTTP_Server.Max_Log_Entries');
SetDisplaySelection('HTTP_Server.Log_Format');
SetDisplaySelection('HTTP_Server.Authentication_Timeout');
SetSubmit(false);
UpdateHttpServerDisplay(true);
document.getElementById("httpServerForm").style.display = "block";
}
function HttpServerSecureProtocolsDisplayUpdate(optElement)
{
var vEncryption = 0;
var maxSecureProtocols=3;
maxSecureProtocols+=1;
for(var n = 0; n < maxSecureProtocols; ++n)
{
var bit = 1 << n;
var e = document.forms[0].elements[
'new_HTTP_Server.Secure_Protocols_' + n
];
vEncryption = vEncryption | (e.checked ? bit : 0);
}
document.forms[0].elements[
'new_HTTP_Server.Secure_Protocols'
].value = vEncryption;
Update(optElement);
}
function HttpNavigationDisplay()
{
GetMessageDisplay('httpstats', "strings", 36);
GetMessageDisplay('httpconfig', "strings", 37);
GetMessageDisplay('httpauth', "strings", 56);
}
function HttpStatsDisplay()
{
GetMessageDisplay('http_stats', "http", 110);
GetMessageDisplay('rx_bytes', "http", 66);
GetMessageDisplay('tx_bytes', "http", 67);
GetMessageDisplay('ok', "http", 68);
GetMessageDisplay('movedpermenent', "http", 69);
GetMessageDisplay('badrequest', "http", 70);
GetMessageDisplay('authrequired', "http", 71);
GetMessageDisplay('notfound', "http", 72);
GetMessageDisplay('requesttimeout', "http", 73);
GetMessageDisplay('requesttoolarge', "http", 74);
GetMessageDisplay('internalerror', "http", 75);
GetMessageDisplay('notimplemented', "http", 76);
GetMessageDisplay('status_unknown', "http", 77);
GetMessageDisplay('workqueuefull', "http", 78);
GetMessageDisplay('socketerror', "strings", 100);
GetMessageDisplay('memoryerror', "http", 108);
GetMessageDisplay('http_log', "http", 109);
GetMessageDisplay('http_log_view',"http",79);
GetMessageDisplay('http_log_clear',"strings",120);
}
