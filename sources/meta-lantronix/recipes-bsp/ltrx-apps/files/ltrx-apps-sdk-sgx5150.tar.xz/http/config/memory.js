function SetMemoryDisplay()
{
GetMessageDisplay('diag_memory',"memory",0);
GetMessageDisplay('diag_mem_main_heap',"memory",1);
GetMessageDisplay('diag_mem_total_mem',"memory",2);
GetMessageDisplay('diag_mem_available_mem',"memory",3);
}
