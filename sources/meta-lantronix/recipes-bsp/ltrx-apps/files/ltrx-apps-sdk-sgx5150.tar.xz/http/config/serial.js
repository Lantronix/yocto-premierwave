function SetAdmin_USB1Display()
{
var menu=document.getElementById('usb_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('usb_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
var menu1=document.getElementById('usb1_menu');
if(menu1)menu1.style.display='block';
var icon1=document.getElementById('usb1_icon');
if(icon1)icon1.className='glyphicon glyphicon-chevron-left';
var menu2=document.getElementById('usb2_menu');
if(menu2)menu2.style.display='none';
var icon2=document.getElementById('usb2_icon');
if(icon2)icon2.className='glyphicon glyphicon-chevron-right';
var menu3=document.getElementById('usb3_menu');
if(menu3)menu3.style.display='none';
var icon3=document.getElementById('usb3_icon');
if(icon3)icon3.className='glyphicon glyphicon-chevron-right';
}
function SetAdmin_Bluetooth1Display()
{
var menu=document.getElementById('bluetooth_serial_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('bluetooth_serial_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
var menu1=document.getElementById('bluetooth1_serial_menu');
if(menu1)menu1.style.display='block';
var icon1=document.getElementById('bluetooth1_serial_icon');
if(icon1)icon1.className='glyphicon glyphicon-chevron-left';
var menu2=document.getElementById('bluetooth2_serial_menu');
if(menu2)menu2.style.display='none';
var icon2=document.getElementById('bluetooth2_serial_icon');
if(icon2)icon2.className='glyphicon glyphicon-chevron-right';
var menu3=document.getElementById('bluetooth3_serial_menu');
if(menu3)menu3.style.display='none';
var icon3=document.getElementById('bluetooth3_serial_icon');
if(icon3)icon3.className='glyphicon glyphicon-chevron-right';
}
function SetAdmin_LineDisplay(xml)
{
var menu=document.getElementById('lines_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('lines_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
var numberofports = document.getElementById('numSerialPorts').innerText;
if(numberofports < 4)
{
if(! xml || ! xml.hasChildNodes())
{
return;
}
var thisPort = Number(GetXmlData(xml,"port"))+1;
for(var p=1;p<=numberofports;p++)
{
if(p==thisPort)
{
var menu=document.getElementById('line'+p+'_menu');
if(menu)menu.style.display='block';
var icon=document.getElementById('line'+p+'_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-left';
}
else
{
var menu=document.getElementById('line'+p+'_menu');
if(menu)menu.style.display='none';
var icon=document.getElementById('line'+p+'_icon');
if(icon)icon.className='glyphicon glyphicon-chevron-right';
}
}
}
}
function UpdateLineCmDisplay(initialize, optElement)
{
var mode = GetDisplayValue("new_LineCmdMode.Mode");
var useSerial = (
mode == "Use Serial String" ||
mode == "Use both Serial String and CP Group"
);
SetFxDisplay("wait_time_Display", useSerial ? "" : "none", initialize);
SetFxDisplay("serial_string_Display", useSerial ? "" : "none", initialize);
SetFxDisplay("echo_serial_string_Display", useSerial ? "" : "none", initialize);
Update(optElement);
}
function SetLineCmDisplay(xml)
{
{
var mode = document.getElementById('cmmode').innerHTML;
document.getElementById('cmmodeD').style.display =
mode.match(/Inactive/) ? 'none' : '';
}
displayElementRootNames = new Array();
SetDisplaySelection('LineCmdMode.Mode');
SetDisplaySelection('LineCmdMode.Wait_Time');
SetDisplaySelection('LineCmdMode.Serial_String');
SetDisplaySelection('LineCmdMode.Echo_Serial_String');
SetDisplaySelection('LineCmdMode.Signon_Message');
SetSubmit(false);
UpdateLineCmDisplay(true);
document.getElementById("cmform").style.display = "block";
}
function UpdateLineDisplay(initialize, optElement)
{
var isCDCACM = (
GetDisplayValue("new_Line.Interface").substring(0,11) == 'USB-CDC-ACM' || GetDisplayValue("new_Line.Interface").substring(0,15) == 'Bluetooth-RFCOMM'
);
SetFxDisplay("baudRate_Display", ! isCDCACM ? "" : "none", initialize);
SetFxDisplay("parity_Display", ! isCDCACM ? "" : "none", initialize);
SetFxDisplay("dataBits_Display", ! isCDCACM ? "" : "none", initialize);
SetFxDisplay("stopBits_Display", ! isCDCACM ? "" : "none", initialize);
var baud = GetDisplayValue("new_Line.Baud_Rate");
SetDisplayValue("Selected_Baud_Rate", baud);
document.getElementById("line_baud_rate_D").style.display = (
GetDisplayValue("Selected_Baud_Rate") == "Custom" ? '' : 'none'
);
var isModbus = (
GetDisplayValue("new_Line.Protocol").substring(0,6) == 'Modbus'
);
var show_flow = (
! isModbus &&
GetDisplayValue("new_Line.Interface").substring(0,10) != 'RS485 Half' &&
! isCDCACM
);
if(! show_flow)
{
SetDisplayValue("new_Line.Flow_Control","None");
}
SetFxDisplay("flowControl_Display", show_flow ? "" : "none", initialize);
var flow = document.forms[0].elements["new_Line.Flow_Control"];
var isRs485 = (
GetDisplayValue("new_Line.Interface").substring(0,5) == 'RS485'
);
if(isRs485)
{
flow.options[2] = null;
}
else
if(! flow.options[2])
{
flow.options[2] = new Option("Hardware","Hardware",false,false);
}
var isSoftwareFlowControl = (
GetDisplayValue("new_Line.Flow_Control") == "Software"
);
SetFxDisplay(
"XON_Display",
show_flow && isSoftwareFlowControl ? "" : "none",
initialize
);
SetFxDisplay(
"XOFF_Display",
show_flow && isSoftwareFlowControl ? "" : "none",
initialize
);
SetFxDisplay("gap_timer_Display", ! isModbus ? "" : "none", initialize);
SetFxDisplay("threshold_Display", ! isModbus ? "" : "none", initialize);
var show_termination = (
isRs485 &&
GetDisplayValue("new_Line.Interface").substring(0,10) == 'RS485 Half'
);
var show_4w_termination = (
isRs485 &&
GetDisplayValue("new_Line.Interface").substring(0,10) == 'RS485 Full'
);
SetFxDisplay(
"termination_4w_Display", show_4w_termination ? "" : "none", initialize
);
if(! show_4w_termination)
{
SetDisplayValue("new_Line.Full_Duplex_Termination","Disabled");
}
SetFxDisplay(
"termination_Display", show_termination ? "" : "none", initialize
);
if(! show_termination)
{
SetDisplayValue("new_Line.Termination","Disabled");
}
Update(optElement);
}
function SetLineDisplay(xml)
{
{
var serform = document.getElementById('serform');
serform.Selected_Baud_Rate.length = 0;
var i = 0;
if(xml)
{
var baud = xml.getElementsByTagName("baud");
for(i = 0; baud && i < baud.length; ++i)
{
var bv = baud[i].firstChild.nodeValue;
serform.Selected_Baud_Rate.options[i] = new Option(
bv, bv, false, false
);
}
}
serform.Selected_Baud_Rate.options[i] = new Option(
"Custom", "Custom", false, true
);
}
{
var ie = document.forms[0].elements["new_Line.Interface"];
ie.length = 0;
if(xml)
{
var i;
var ifc = xml.getElementsByTagName("interface");
for(i = 0; ifc && i < ifc.length; ++i)
{
var ifcv = ifc[i].firstChild.nodeValue;
ie.options[i] = new Option(
ifcv, ifcv, false, false
);
}
ie.disabled = (i <= 1);
}
}
displayElementRootNames = new Array();
SetDisplaySelection('Line.Name');
SetDisplaySelection('Line.Interface');
SetDisplaySelection('Line.Termination');
SetDisplaySelection('Line.Full_Duplex_Termination');
SetDisplaySelection('Line.State');
SetDisplaySelection('Line.Protocol');
SetDisplaySelection('Line.Baud_Rate');
SetDisplaySelection('Line.Parity');
SetDisplaySelection('Line.Data_Bits');
SetDisplaySelection('Line.Stop_Bits');
SetDisplaySelection('Line.Flow_Control');
SetDisplaySelection('Line.Xon_Char');
SetDisplaySelection('Line.Xoff_Char');
SetDisplaySelection('Line.Gap_Timer');
SetDisplaySelection('Line.Threshold');
SetDisplaySelection('Line.Early_Initialization');
SetSubmit(false);
UpdateLineDisplay(true);
document.getElementById("serform").style.display = "block";
}
function SetDisplaySelection1(name)
{
displayElementRootNames.push(name);
var cvalue = GetDivValueById("current_" + name);
var s = document.getElementById("status_" + name);
if(s)
s.innerHTML = "N/A";
SetDisplayValue("new_" + name, cvalue);
return cvalue;
}
function UpdateUSBDisplay(initialize, optElement)
{
var baud = GetDisplayValue("new_Line.Baud_Rate");
SetDisplayValue("Selected_Baud_Rate", baud);
document.getElementById("line_baud_rate_D").style.display = (
GetDisplayValue("Selected_Baud_Rate") == "Custom" ? '' : 'none'
);
var mode = GetDisplayValue("new_Line.Line_Mode");
document.getElementById('baudRate_Display').style.display = (mode=='Host')?'':'none';
var flowcontrol = GetDisplayValue("new_Line.Flow_Control");
document.getElementById('parity_Display').style.display = (mode=='Host')?'':'none';
document.getElementById('dataBits_Display').style.display = (mode=='Host')?'':'none';
document.getElementById('stopBits_Display').style.display = (mode=='Host')?'':'none';
document.getElementById('flowControl_Display').style.display = (mode=='Host')?'':'none';
document.getElementById('XON_Display').style.display = (mode=='Host' && flowcontrol=='Software')?'':'none';
document.getElementById('XOFF_Display').style.display = (mode=='Host' && flowcontrol=='Software')?'':'none';
Update(optElement);
}
function UpdateBluetoothLineDisplay(initialize, optElement)
{
var mode = GetDisplayValue("new_Line.Line_Mode");
Update(optElement);
}
function SetUSBDisplay(xml)
{
{
var serform = document.getElementById('serform');
serform.Selected_Baud_Rate.length = 0;
var i = 0;
if(xml)
{
var baud = xml.getElementsByTagName("baud");
for(i = 0; baud && i < baud.length; ++i)
{
var bv = baud[i].firstChild.nodeValue;
serform.Selected_Baud_Rate.options[i] = new Option(
bv, bv, false, false
);
}
}
}
var isSerial = GetXmlData(xml, 'isSerial');
{
var ie = document.forms[0].elements["new_Line.Interface"];
ie.length = 0;
if(xml)
{
var i;
var ifc = xml.getElementsByTagName("interface");
for(i = 0; ifc && i < ifc.length; ++i)
{
var ifcv = ifc[i].firstChild.nodeValue;
ie.options[i] = new Option(
ifcv, ifcv, false, false
);
}
ie.disabled = (i <= 1);
}
}
displayElementRootNames = new Array();
SetDisplaySelection('Line.Name');
SetDisplaySelection('Line.Interface');
if(Number(isSerial))
{
SetDisplaySelection('Line.State');
SetDisplaySelection('Line.Protocol');
}
else
{
SetDisplaySelection1('Line.State');
SetDisplaySelection1('Line.Protocol');
}
SetDisplaySelection('Line.Baud_Rate');
SetDisplaySelection('Line.Parity');
SetDisplaySelection('Line.Data_Bits');
SetDisplaySelection('Line.Stop_Bits');
SetDisplaySelection('Line.Flow_Control');
SetDisplaySelection('Line.Xon_Char');
SetDisplaySelection('Line.Xoff_Char');
SetDisplaySelection('Line.Line_Mode');
SetDisplaySelection('Line.Gap_Timer');
SetDisplaySelection('Line.Threshold');
SetSubmit(false);
UpdateUSBDisplay(true);
if(!(Number(isSerial)))
document.getElementById("reassert_button").style.display = "none";
document.getElementById("serform").style.display = "block";
}
function SetBluetoothSerialDisplay(xml)
{
var isSerial = GetXmlData(xml, 'isSerial');
{
var ie = document.forms[0].elements["new_Line.Interface"];
ie.length = 0;
if(xml)
{
var i;
var ifc = xml.getElementsByTagName("interface");
for(i = 0; ifc && i < ifc.length; ++i)
{
var ifcv = ifc[i].firstChild.nodeValue;
ie.options[i] = new Option(
ifcv, ifcv, false, false
);
}
ie.disabled = (i <= 1);
}
}
displayElementRootNames = new Array();
SetDisplaySelection('Line.Name');
SetDisplaySelection('Line.Interface');
if(Number(isSerial))
{
SetDisplaySelection('Line.State');
SetDisplaySelection('Line.Protocol');
}
else
{
SetDisplaySelection1('Line.State');
SetDisplaySelection1('Line.Protocol');
}
SetDisplaySelection('Line.Line_Mode');
SetDisplaySelection('Line.Gap_Timer');
SetDisplaySelection('Line.Threshold');
SetSubmit(false);
UpdateBluetoothLineDisplay(true);
if(!(Number(isSerial)))
document.getElementById("reassert_button").style.display = "none";
document.getElementById("serform").style.display = "block";
}
function LineRender(xml)
{
var numSerialPorts = GetXmlData(xml, "numSerialPorts");
var port = GetXmlData(xml, 'port');
var name = GetXmlData(xml, 'name');
document.getElementById("hiddenport").innerHTML = port;
var ref = "Line " + (Number(port) + 1);
document.getElementById("line_text_header_name").innerHTML = (
name.length > 0 ? name + ' (' + ref + ')' : ref
);
if(numSerialPorts > 4)
{
var d = document.getElementById("line_selection");
if(d)
{
var r = "";
r += '<table id="Nav1" class="table table-striped table-condensed">';
r += "<tr>";
r += "<td align='right'><b>Select Line: </b></td>";
r += "<td align='left'>";
r += "<";
r += "select name='navSelect' class='form-control' style='width: 28%;'";
r += "id='navSelect' ";
r += "onchange=\" ";
r += "var page = document.getElementById('hiddencurrentserialpage').innerHTML;";
r += "return ajax_AddToHistory(page, [true, 'portnumber='+this.value]);";
r += " \" ";
r += ">"
for(
var i = 0;
i < (
numSerialPorts
);
++i
)
{
var sel = (port == i) ? " selected" : "";
r += "<option value='" + i + "' " + sel + ">Line " + (i+1) +" </option>";
}
r += "</select>";
r += "</td>";
}
r += "</tr>";
r += "</table>";
d.innerHTML = r;
HighlightElementInTable("Nav1", "sernav" + (Number(port)+1));
}
}
function LineRenderName(xml)
{
var numSerialPorts = GetXmlData(xml, "numSerialPorts");
var port = GetXmlData(xml, 'port');
var name = GetXmlData(xml, 'name');
document.getElementById("hiddenport").innerHTML = port;
var ref = "Line " + (Number(port) + 1);
document.getElementById("line_text_header_name").innerHTML = (
name.length > 0 ? name + ' (' + ref + ')' : ref
);
}
function USBRenderName(xml)
{
var numSerialPorts = GetXmlData(xml, "numSerialPorts");
var port = GetXmlData(xml, 'port');
var name = GetXmlData(xml, 'name');
document.getElementById("hiddenusbport").innerHTML = port;
var ref = "USB " + (Number(port) + 1);
document.getElementById("line_text_header_name").innerHTML = (
name.length > 0 ? name + ' (' + ref + ')' : ref
);
}
function BluetoothSerialRenderName(xml)
{
var numSerialPorts = GetXmlData(xml, "numSerialPorts");
var port = GetXmlData(xml, 'port');
var name = GetXmlData(xml, 'name');
document.getElementById("hiddenbluetoothport").innerHTML = port;
var ref = "Bluetooth " + (Number(port) + 1);
document.getElementById("line_text_header_name").innerHTML = (
name.length > 0 ? name + ' (' + ref + ')' : ref
);
}
function LineStatsFillDescriptions()
{
GetMessageDisplay('line_text_header_separator', "serial", 85);
GetMessageDisplay('line_text_header_statistics', "strings", 36);
GetMessageDisplay('line_text_receiver', "serial", 98);
GetMessageDisplay('line_text_transmitter', "serial", 99);
GetMessageDisplay('line_text_bytes', "serial", 86);
GetMessageDisplay('line_text_queued_bytes', "serial", 87);
GetMessageDisplay('line_text_breaks', "serial", 88);
GetMessageDisplay('line_text_flow_control', "serial", 89);
GetMessageDisplay('line_text_parity_errors', "serial", 90);
GetMessageDisplay('line_text_framing_errors', "serial", 91);
GetMessageDisplay('line_text_overrun_errors', "serial", 92);
GetMessageDisplay('line_text_no_rx_buffer_errors', "serial", 93);
GetMessageDisplay('line_text_cts_input', "serial", 94);
GetMessageDisplay('line_text_rts_output', "serial", 95);
GetMessageDisplay('line_text_dsr_input', "serial", 96);
GetMessageDisplay('line_text_dtr_output', "serial", 97);
}
function LineConfFillDescriptions()
{
GetMessageDisplay('line_text_header_separator', "serial", 85);
GetMessageDisplay('line_text_header_configuration', "strings", 37);
GetMessageDisplay('line_text_configuration', "strings", 37);
GetMessageDisplay('line_text_status', "strings", 0);
GetMessageDisplay('line_text_name', "serial", 100);
GetMessageDisplay('line_text_interface', "serial", 101);
}
function LineCMFillDescriptions()
{
GetMessageDisplay('line_text_header_separator', "serial", 85);
GetMessageDisplay('line_text_header_command_mode', "serial", 102);
GetMessageDisplay('line_text_configuration', "strings", 37);
}
