function SetBluetoothStatusDisplay(xml)
{
GetMessageDisplay('bluetooth_stats',"bluetooth",1);
GetMessageDisplay('bluetooth_state',"bluetooth",2);
GetMessageDisplay('device_name',"bluetooth",5);
GetMessageDisplay('mac_address',"bluetooth",3);
GetMessageDisplay('connected_device',"bluetooth",4);
var menu=document.getElementById('bluetooth_menu');
if(menu)menu.style.display='block';
}
function SetBluetoothDisplay(xml)
{
displayElementRootNames = new Array();
SetSubmit(false);
SetDisplaySelection('Bluetooth.State');
document.getElementById("bluetoothform").style.display = "block";
document.getElementById('bluetooth_menu').style.display='block';
}
function SetBluetoothNavDisplay()
{
GetMessageDisplay('bluetooth_statistics',"strings",36);
GetMessageDisplay('bluetooth_configuration',"strings",37);
}
