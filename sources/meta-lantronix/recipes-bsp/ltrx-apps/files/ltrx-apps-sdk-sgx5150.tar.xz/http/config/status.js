function scrollDevice()
{
$('html, body').animate({
scrollTop: 0
}, "fast");
}
function scrollNetwork()
{
$('html, body').animate({
scrollTop: $("#Network").position().top
}, "fast");
}
function scrollVPN()
{
$('html, body').animate({
scrollTop: $("#VPN").position().top
}, "fast");
}
function scrollMach10()
{
$('html, body').animate({
scrollTop: $("#Mach10").position().top
}, "fast");
}
function scrollBluetooth()
{
$('html, body').animate({
scrollTop: $("#Bluetooth").position().top
}, "fast");
}
function scrollLines()
{
$('html, body').animate({
scrollTop: $("#Lines").position().top
}, "fast");
}
function scrollTunnels()
{
$('html, body').animate({
scrollTop: $("#Tunnels").position().top
}, "fast");
}
function MainStatusRender(xml)
{
Localize();
IndexDisplayElement(document.getElementById('status_Index'));
document.getElementById('subnavData').innerHTML = '';
var subnavData='<ul class="nav">';
subnavData += '<li><a onclick=\"scrollDevice();\" href=\"javascript:void(0)\" ">'+GetMessage("status",1)+'</a></li>';
subnavData += '<li><a onclick=\"scrollNetwork();\" href=\"javascript:void(0)\" >'+GetMessage("strings",1)+'</a></li>';
var numLinePorts = GetXmlData(xml, "numSerialPorts");
document.getElementById("numSerialPorts").innerHTML = numLinePorts;
var numUSBPorts = GetXmlData(xml, "numUSBPorts");
document.getElementById("numUSBPorts").innerHTML = numUSBPorts;
var numBluetoothPorts = GetXmlData(xml, "numBluetoothPorts");
document.getElementById("numBluetoothPorts").innerHTML = numBluetoothPorts;
var numSerialPorts=parseInt(numLinePorts)+parseInt(numUSBPorts)+parseInt(numBluetoothPorts);
if(numSerialPorts > 0)
{
subnavData += '<li><a onclick=\"scrollLines();\" href=\"javascript:void(0)\" >Lines</a></li>';
}
var numTunnelPorts = GetXmlData(xml, "numTunnelPorts");
document.getElementById("numTunnels").innerHTML = numTunnelPorts;
if(numTunnelPorts>0)
{
subnavData += '<li><a onclick=\"scrollTunnels();\" href=\"javascript:void(0)\" >Tunnels</a></li>';
}
subnavData += '<li><a onclick=\"scrollVPN();\" href=\"javascript:void(0)\" >VPN</a></li>';
subnavData += '<li><a onclick=\"scrollMach10();\" href=\"javascript:void(0)\" >Percepxion</a></li>';
subnavData += '<li><a onclick=\"scrollBluetooth();\" href=\"javascript:void(0)\" >Bluetooth</a></li>';
subnavData += '</ul>';
document.getElementById('subnavData').innerHTML = subnavData;
var d = document.getElementById('contentData');
d.innerHTML = '';
var r = "";
if(! xml || ! xml.hasChildNodes())
{
r += "No MIB data is available.";
}
else
{
r += "<div class='table-responsive'>";
r += "<div id=\"results\"></div>";
r += "<div id='Device' style='display:block'></div>";
r += "<h2 class='sub-header'>"+GetMessage("status",1)+"</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead><tr><td colspan=\"3\"><b>"+GetMessage("status",0)+"</b></td></tr></thead>";
r += "<tbody><tr><td width='40%'><b>"+GetMessage("status",2)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "pn") + "</td></tr>";
r += "<tr><td><b>Secure Boot:</b></td><td colspan=\"2\">" + GetXmlData(xml, "secure_boot") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("strings",51)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "fv");
document.getElementById('hiddenversion').innerHTML=GetXmlData(xml,"fv");
if(GetXmlData(xml, "fv_state"))
{
r += "<img height='16' width='16' src='activity.gif'/>";
}
r += "</td></tr>";
if(GetXmlData(xml, "bootstrapv"))
{
r += "<tr><td><b>"+GetMessage("strings",184)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "bootstrapv") +"</td></tr>";
}
if(GetXmlData(xml, "cfgv"))
{
r += "<tr><td><b>"+GetMessage("strings",175)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "cfgv") +"</td></tr>";
}
r += "<tr><td><b>"+GetMessage("strings",166)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "iotv") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("status",4)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "rfv") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("status",5)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "fbd") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("strings",104)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "sn") + "</td></tr>";
r += "<tr><td><b>Device ID:</b></td><td colspan=\"2\">" + GetXmlData(xml, "device_id") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("strings",95)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "up") + "</td></tr>";
r += "<tr><td><b>"+GetMessage("status",6)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "date") + "</td></tr>";
var configState=GetXmlData(xml, "pc");
var requiresReboot=GetXmlData(xml, "requiresReboot");
var firmwareRequiresReboot=GetXmlData(xml, "firmwareRequiresReboot");
var allowedReboot=GetXmlData(xml, "allowedReboot");
r += "<tr><td><b>"+GetMessage("status",7)+":</b></td><td colspan=\"2\">" + ((configState=='Saved')?GetMessage("status",11):GetMessage("status",12));
if(configState=="Unsaved")
{
r += ".";
r += "&nbsp;&nbsp;";
r += "<a href=\"javascript:void(0)\" class=\"btn btn-primary btn-sm\"";
r += "onclick=\"";
r += "ajax_AddToHistory(";
r += "'StatusPage',";
r += "[true, 'cfgsave=true']";
r += ");";
r += "return false;";
r += "\"";
r += ">";
r += "<b>"+GetMessage("strings",5)+"</b>";
r += "</a>";
}
if(requiresReboot=="yes" || firmwareRequiresReboot=="yes")
{
r += "<br>";
r += "<form id=\"frmReboot\" name=\"frmReboot\" class='form-horizontal' method=\"post\" autocomplete=\"off\" action=\"/reboot\">";
if(requiresReboot=="yes")
{
r += "<span>"+GetMessage("strings",11)+"</span>"
if(firmwareRequiresReboot=="yes")
{
r += "<br>";
}
}
if(firmwareRequiresReboot=="yes")
{
r += "<span>"+GetMessage("strings",183)+"</span>"
}
if(allowedReboot == "true")
{
r += "<input name=\"reboot\" type=\"text\" style=\"display:none;\" value=\"Reboot\"/>";
r += "&nbsp;&nbsp;";
r += "<a href=\"javascript:void(0)\" class=\"btn btn-primary btn-sm\"";
r += "onclick=\"";
r += "bootbox.confirm('"+GetConfirmationMessage("strings",12)+"";
if(configState=="Unsaved")
{
r += "\\r\\n"+GetConfirmationMessage("strings",13)+"";
}
r += "',function(result) {";
r += "if(result==true) { "
r += "FileSystemMonitorDisable();document.forms['frmReboot'].submit();";
r += "}";
r += "});";
r += "return false;\"";
r += ">";
r += GetMessage("strings",6);
r += "</a>";
}
r += "</form>";
}
r += "</td></tr>";
var region = GetXmlData(xml, "region");
if(region=="United States")region=GetMessage("strings",17);
if(region=="Europian Union")region=GetMessage("strings",18);
if(region=="Japan")region=GetMessage("strings",19);
if(region=="Worldwide")region=GetMessage("strings",20);
r += "<tr><td><b>"+GetMessage("status",8)+":</b></td><td colspan=\"2\">" + region + "</td></tr>";
r += "<tr><td><b>"+GetMessage("softap",0)+":</b></td><td colspan=\"2\">" + ((GetXmlData(xml, "softap")=="Enabled")?GetMessage("strings",14):GetMessage("strings",15)) + "</td></tr>";
r += "<tr><td><b>"+GetMessage("net",235)+":</b></td><td colspan=\"2\">" + ((GetXmlData(xml, "wifi_direct_go_mode")=="Enabled")?GetMessage("strings",14):GetMessage("strings",15)) + "</td></tr>";
r += "<tr><td><b>"+GetMessage("bluetooth",0)+":</b></td><td colspan=\"2\">" + ((GetXmlData(xml, "bluetooth")=="Enabled")?GetMessage("strings",14):GetMessage("strings",15)) + "</td></tr>";
r += "</tbody></table>";
var numAlarms = GetXmlData(xml, "active_alarms");
if(numAlarms!=0)
{
r += "<h2 class='sub-header'>Alarms</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead><tr><td colspan=\"3\"><b>Alerts</b></td></tr></thead><tbody>";
for(var alarm=0;alarm<numAlarms;alarm++)
{
var name=GetXmlData(xml, "alarm_name_"+alarm);
var duration=GetXmlData(xml, "alarm_duration_"+alarm);
r += "<tr><td colspan='3'><b>Alarm (" + name + ")</b></td></tr>";
r += "<tr><td width='40%'><b>Duration:</b></td><td colspan=\"2\">" + duration + "</td></tr>";
}
r += "</tbody></table>";
}
r += "<div id='Network' style='display:block'></div>";
r += "<h2 class='sub-header'>"+GetMessage("strings",1)+"</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead><tr><td colspan=\"3\"><b>"+GetMessage("status",9)+"</b></td></tr></thead>";
r += "<tbody>";
r += "<tr><td width='40%'><b>"+GetMessage("strings",61)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "pdns") + "</td></tr>"
r += "<tr><td><b>"+GetMessage("strings",62)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "sdns")+ "</td></tr>"
r += "</tbody></table>";
var numInterfaces = GetXmlData(xml, "numInterfaces");
for(var interface = 0; interface < numInterfaces; ++interface)
{
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead><tr><td colspan=\"3\"><b>"+GetMessage("strings",54)+" "+GetXmlData(xml, "intfc"+interface) + "</b></td></tr></thead>";
r += "<tbody>";
var interfaceState=GetXmlData(xml, "intfc_state"+interface);
if(interfaceState=="Enabled")
{
if(GetXmlData(xml, "link"+interface))
{
if (GetXmlData(xml, "intfc"+interface).indexOf("wwan") != -1)
{
r += "<tr><td width='40%'><b>"+GetMessage("strings",113)+":</b></td><td colspan=\"2\">";
}
else
r += "<tr><td width='40%'><b>"+GetMessage("strings",77)+":</b></td><td colspan=\"2\">";
r += GetXmlData(xml, "link"+interface) + "</td></tr>";
}
else r += "<tr><td width='40%'><b>"+GetMessage("strings",46)+":</b></td><td colspan=\"2\">" + (interfaceState=='Enabled'?GetMessage("strings",14):GetMessage("strings",15)) + "</td></tr>";
if(GetXmlData(xml, "ssid"+interface))r += "<tr><td><b>"+GetMessage("net",152)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "ssid"+interface) + "</td></tr>";
if(GetXmlData(xml, "sec_suite"+interface))r += "<tr><td><b>"+GetMessage("net",153)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "sec_suite"+interface) + "</td></tr>";
if(GetXmlData(xml, "mac"+interface))r += "<tr><td><b>"+GetMessage("strings",121)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "mac"+interface) + "</td></tr>";
if(GetXmlData(xml, "host"+interface))r += "<tr><td><b>"+GetMessage("strings",103)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "host"+interface) + "</td></tr>";
if(GetXmlData(xml, "mtu"+interface))r += "<tr><td><b>MTU:</b></td><td colspan=\"2\">" + GetXmlData(xml, "mtu"+interface) + "</td></tr>";
if(GetXmlData(xml, "intfc_ipv4_state"+interface))
{
var ipv4_state=GetXmlData(xml, "intfc_ipv4_state"+interface);
if(ipv4_state!="Enabled")
{
r += "<tr><td width='40%'><b>IPv4 "+GetMessage("strings",46)+":</b></td><td colspan=\"2\">" + (ipv4_state=='Enabled'?GetMessage("strings",14):GetMessage("strings",15)) + "</td></tr>";
}
else
{
if(GetXmlData(xml, "ip"+interface))r += "<tr><td><b>"+GetMessage("strings",101)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "ip"+interface) + "</td></tr>";
if(GetXmlData(xml, "netmask"+interface))r += "<tr><td><b>"+GetMessage("strings",102)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "netmask"+interface) + "</td></tr>";
if(GetXmlData(xml, "rtr"+interface))r += "<tr><td><b>"+GetMessage("strings",99)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "rtr"+interface) + "</td></tr>";
if(GetXmlData(xml, "dom"+interface))r += "<tr><td><b>"+GetMessage("strings",75)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "dom"+interface) + "</td></tr>";
}
}
if(GetXmlData(xml, "intfc_ipv6_state"+interface))
{
var ipv6_state=GetXmlData(xml, "intfc_ipv6_state"+interface);
if(ipv6_state=="Enabled")
{
var num_v6_global = GetXmlData(xml, "num"+interface+"global_addresses");
for(var ipv6 = 0; ipv6 < num_v6_global; ++ipv6)
{
if(GetXmlData(xml, "ipv6"+interface+"_"+ipv6+"global"))r += "<tr><td><b>"+GetMessage("strings",129)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "ipv6"+interface+"_"+ipv6+"global") + "</td></tr>";
}
var num_v6_link = GetXmlData(xml, "num"+interface+"link_addresses");
for(var ipv6 = 0; ipv6 < num_v6_link; ++ipv6)
{
if(GetXmlData(xml, "ipv6"+interface+"_"+ipv6+"link"))r += "<tr><td><b>"+GetMessage("strings",130)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "ipv6"+interface+"_"+ipv6+"link") + "</td></tr>";
}
if( num_v6_global+num_v6_link > 0 )
{
var num_v6_rtr = GetXmlData(xml, "num_v6_"+interface+"_rtr");
for(var ipv6 = 0; ipv6 < num_v6_rtr; ++ipv6)
{
if(GetXmlData(xml, "ipv6"+interface+"_rtr"+ipv6))r += "<tr><td><b>IPv6 "+GetMessage("strings",99)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "ipv6"+interface+"_rtr"+ipv6) + "</td></tr>";
}
if(GetXmlData(xml, "dom6"+interface))r += "<tr><td><b> IPv6 "+GetMessage("strings",75)+":</b></td><td colspan=\"2\">" + GetXmlData(xml, "dom6"+interface) + "</td></tr>";
}
}
else
{
r += "<tr><td width='40%'><b>IPv6 "+GetMessage("strings",46)+":</b></td><td colspan=\"2\">" + (ipv6_state=='Enabled'?GetMessage("strings",14):GetMessage("strings",15)) + "</td></tr>";
}
}
}
else
{
r += "<tr><td width='40%'><b>"+GetMessage("strings",46)+":</b></td><td colspan=\"2\">" + (interfaceState=='Enabled'?GetMessage("strings",14):GetMessage("strings",15)) + "</td></tr>";
}
r += "</tbody></table>";
}
if(numSerialPorts > 0)
{
r += "<div id='Lines' style='display:block'></div>";
r += "<h2 class='sub-header'>Lines</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead><tr><td colspan=\"3\"><b>Line Settings</b></td></tr></thead>";
r += "<tbody>";
for(var line = 1; line <= numLinePorts; ++line)
{
var name = GetXmlData(xml, "line" + line + "name");
r += "<tr>";
r += "<td width='40%'><b>";
r += (
name.length > 0 ? name :
"Line " + line
);
r += ":</b></td>";
r += "<td colspan=\"2\">";
r += GetXmlData(xml, "line" + line + "set");
r += "</td>";
r += "</tr>";
}
for(var line = 1 + parseInt(numLinePorts); line <= parseInt(numLinePorts) + parseInt(numUSBPorts); ++line)
{
var name = GetXmlData(xml, "line" + line + "name");
r += "<tr>";
r += "<td width='40%'><b>";
r += (
name.length > 0 ? name :
"USB " + (line-parseInt(numLinePorts))
);
r += ":</b></td>";
r += "<td colspan=\"2\">";
r += GetXmlData(xml, "line" + line + "set");
r += "</td>";
r += "</tr>";
}
for(var line = 1 + parseInt(numLinePorts)+ parseInt(numUSBPorts); line <= numSerialPorts; ++line)
{
var name = GetXmlData(xml, "line" + line + "name");
r += "<tr>";
r += "<td width='40%'><b>";
r += (
name.length > 0 ? name :
"Bluetooth Serial " + (line-(parseInt(numLinePorts)+ parseInt(numUSBPorts)))
);
r += ":</b></td>";
r += "<td colspan=\"2\">";
r += GetXmlData(xml, "line" + line + "set");
r += "</td>";
r += "</tr>";
}
r += "</tbody></table>";
}
if(numTunnelPorts > 0)
{
r += "<div id='Tunnels' style='display:block'></div>";
r += "<h2 class='sub-header'>Tunnels</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<thead><tr>";
r += "<td width='40%'><b>Tunneling</b></td>";
r += "<td><b>Connect<br>Mode</b></td>";
r += "<td><b>Accept<br>Mode</b></td>";
r += "</tr></thead><tbody>"
for(var line = 1; line <= numTunnelPorts; ++line)
{
r += "<tr>";
r += "<td><b>Tunnel " + line + ":" + "</b></td>";
r += "<td>" + GetXmlData(xml, "tun" + line + "con") + "</td>";
r += "<td>" + GetXmlData(xml, "tun" + line + "acc") + "</td>";
r += "</tr>";
}
r += "</tbody></table>";
}
r += "<div id='VPN' style='display:block'></div>";
r += "<h2 class='sub-header'>VPN</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<tbody><tr><td width='40%'><b>Status:</b></td><td colspan=\"2\">" + GetXmlData(xml, "vpn_status") + "</td></tr>";
r += "<tr><td><b>IP Address:</b></td><td colspan=\"2\">" + GetXmlData(xml, "vpn_src_ip") + "</td></tr>";
r += "</tbody></table>";
r += "<div id='Mach10' style='display:block'></div>";
r += "<h2 class='sub-header'>Percepxion</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<tbody><tr><td width='40%'><b>Status:</b></td><td colspan=\"2\">" + GetXmlData(xml, "mach10_status");
var mach10_error=GetXmlData(xml,"mach10_error");
if(mach10_error!="")
{
var formatted = mach10_error.replace(/\n/g, "<br/>");
r += "<br><font color='red'>" + formatted + "</font>";
}
r + "</td></tr>";
r += "</tbody></table>";
r += "<div id='Bluetooth' style='display:block'></div>";
r += "<h2 class='sub-header'>Bluetooth</h2>";
r += "<table class=\"table table-striped table-condensed\">";
r += "<tbody><tr><td width='40%'><b>Status:</b></td><td colspan=\"2\">" + GetXmlData(xml, "bluetooth_status");
r + "</td></tr>";
r += "</tbody></table>";
r += "</div>";
}
d.innerHTML = r;
}
