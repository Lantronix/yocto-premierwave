function TracerouteRender(xml)
{
var d = document.getElementById('trresults');
if(d)
{
d.innerHTML = '';
var r = '';
r += "<div>";
r += "<h3 class='sub-header'>"+GetMessage("tr",7)+"</h3>";
r += "<table class=\"table table-striped table-condensed\">";
if(! xml || ! xml.hasChildNodes())
{
r += "<tr><td><b>"+GetMessage("strings",53)+"</b></td></tr>";
}
else
{
for(var i = 0; xml && i < xml.childNodes.length; ++i)
{
var node = xml.childNodes[i];
if(node.nodeName.toLowerCase() == "t")
{
r += "<tr>";
r += "<td>" + GetXmlData(node, "n") + "</td>";
r += "<td>" + GetXmlData(node, "i") + "</td>";
r += "<td>" + GetXmlData(node, "m") + " ms</td>";
r += "</tr>";
}
}
}
r += "</table>";
r += "</div>";
d.innerHTML = r;
}
}
function SetTracerouteDisplay()
{
GetMessageDisplay('diag_traceroute',"tr",6);
GetMessageDisplay('diag_traceroute_host',"strings",45);
GetMessageDisplay('diag_traceroute_protocol',"strings",125);
document.getElementById('submit_button').value=GetMessage("tr",8);
}
